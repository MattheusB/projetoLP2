package funcionario;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
/**
 * Classe que tem a funcao de criar um funcionario;
 */
public class FuncionarioFactory {
	public FuncionarioFactory(){}
	
	/**
	 * Metodo que tem a funcao de cadastar um funcionario a partir do cargo por ele excido;
	 * @param nome Nome do funcionario;
	 * @param cargo Cargo do funcionario;
	 * @param dataNascimento Data de nascimento;
	 * @return Retorna o tipo de funcionario encontrado a partir do cargo;
	 */
	public Funcionario cadastraFuncionario(String nome, String cargo, String dataNascimento){
		
		//Falta os exceptions
		Funcionario funcionario = null;
		if (cargo.equalsIgnoreCase("Diretor Geral")){
			funcionario = criaDiretor(nome, dataNascimento);
		}
		if (cargo.equalsIgnoreCase("Medico")){
			funcionario = criaMedico(nome, dataNascimento);
		}
		
		if (cargo.equalsIgnoreCase("Tecnico Administrativo")){
			funcionario = criaTecnico(nome, dataNascimento);
		}
		
		return funcionario;
	}
	
	/**
	 * Metodo que tem a funcao de criar diretor;
	 * @param nome Nome do diretor;
	 * @param dataNascimento Data de nascimento;
	 * @return Retorna o diretor;
	 */
	public Funcionario criaDiretor(String nome, String dataNascimento){
		Funcionario diretor = new DiretorGeral(nome, dataNascimento);
		DateTimeFormatter formatador = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate data = LocalDate.parse(dataNascimento, formatador);
		return diretor;
	}
	
	/**
	 * Metodo que tem a funcao de criar medico;
	 * @param nome Nome do medico;
	 * @param dataNascimento Data de nascimento;
	 * @return Retorna o medico;
	 */
	public Funcionario criaMedico(String nome, String dataNascimento){
		Funcionario medico = new Medico(nome, dataNascimento);
		DateTimeFormatter formatador = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate data = LocalDate.parse(dataNascimento, formatador);
		return medico;
	}
	
	/**
	 * Metodo que tem a funcao de criar um tecnico administrativo;
	 * @param nome Nome do tecnico;
	 * @param dataNascimento Data de nascimento;
	 * @return Retorna o tecnico;
	 */
	public Funcionario criaTecnico(String nome, String dataNascimento){
		Funcionario tecnico = new TecnicoAdministrativo(nome, dataNascimento);
		DateTimeFormatter formatador = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate data = LocalDate.parse(dataNascimento, formatador);
		return tecnico;
	}
}
