package funcionario;

import java.time.LocalDate;
/**
 * Classe que tem a funcao de "construir" funcionario;
 */
public class Funcionario {
	private String nome;
	private String datanascimento;
	private String matricula;
	private String senha;
	
	/**
	 * Construtor de Funcionario;
	 * @param nome Nome do funcionario;
	 * @param datanascimento Data de nascimento do funcionario;
	 */
	public Funcionario (String nome, String datanascimento) {
		this.nome = nome;
		this.datanascimento = datanascimento;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDatanascimento() {
		return datanascimento;
	}

	public void setDatanascimento(String datanascimento) {
		this.datanascimento = datanascimento;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}
	
}