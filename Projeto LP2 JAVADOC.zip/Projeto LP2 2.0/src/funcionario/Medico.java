package funcionario;

public class Medico extends Funcionario{
	/**
	 * Classe que herda os metodos da classe Funcionario;
	 * @param nome Nome do usuario;
	 * @param datanascimento Data de nascimento;
	 */
	public Medico(String nome, String datanascimento) {
		super(nome, datanascimento);
	}

}
