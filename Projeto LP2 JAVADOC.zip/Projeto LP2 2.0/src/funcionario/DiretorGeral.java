package funcionario;

import java.time.LocalDate;

public class DiretorGeral extends Funcionario{
	/**
	 * Classe que herda os metodos da classe Funcionario;
	 * @param nome Nome do usuario;
	 * @param datanascimento Data de nascimento;
	 */
	public DiretorGeral(String nome, String datanascimento) {
		super(nome, datanascimento);
	}

}
