package funcionario;

public class TecnicoAdministrativo extends Funcionario{
	/**
	 * Classe que herda os metodos da classe Funcionario;
	 * @param nome Nome do usuario;
	 * @param datanascimento Data de nascimento;
	 */
	public TecnicoAdministrativo(String nome, String datanascimento) {
		super(nome, datanascimento);
	}

}