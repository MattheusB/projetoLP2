package pacientes;

import java.util.ArrayList;
import java.util.Collections;
import java.util.UUID;

/**
 * Classe que tem a funcao de criar um prontuario para os pacientes;
 */
public class Prontuario {
	
	private ArrayList<Paciente> prontuarios;
	private int qntdpacientes = 0;
	public Prontuario(){
	prontuarios  = new ArrayList<Paciente>();
	}
	/**
	 * Metodo que tem a funcao de criar paciente;
	 * @param nome Nome do paciente;
	 * @param dataDeNacimento Data de nascimento;
	 * @param peso Massa do paciente;
	 * @param tipoSanguineo Tipo sanguineo do paciente;
	 * @param sexo Sexo do paciente;
	 * @param genero Genero do paciente;
	 */
	public void criarPaciente(String nome, String dataDeNacimento, double peso, String tipoSanguineo, String sexo, String genero){
		this.qntdpacientes += 1;
		UUID id = UUID.randomUUID();
		Paciente novo = new Paciente(nome, dataDeNacimento, peso, tipoSanguineo, sexo, genero,id);
		
		prontuarios.add(novo);
		Collections.sort(prontuarios);
	}
	
	/**
	 * Metodo que tem a funcao de verificar o ID do paciente;
	 * @param id ID do paciente;
	 * @return Retorna o id;
	 */
	private Paciente verificaPaciente(UUID id){
		for(Paciente novo : prontuarios){
			if(novo.getId().equals(id)){
				return novo;
			}
		}
		
		return null;
	}
	

}
