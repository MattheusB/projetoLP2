package controller;

import java.util.HashSet;
import exceptions.chaveIncorretaException;
import exceptions.sistemaLiberadoException;
import funcionario.Funcionario;
import funcionario.FuncionarioFactory;
/**
 * Classe controller que tem a duncao de administrar todo o codigo por tras da facade;
 */
public class Controller {
	int numeroFuncionarios = 000;
	FuncionarioFactory factory = new FuncionarioFactory();
	HashSet<Funcionario> funcionarios = new HashSet<Funcionario>();
	boolean liberacao = false;
	
	/**
	 * Metodo que tem a funcao de liberar o sistema para os usuarios. Primeiro acesso feito
	 * apenas pelo diretor;
	 * @param chave Chave que abre o sistema;
	 * @param nome Nome do Usuario;
	 * @param dataNascimento Data de Nascimento do Usuario;
	 * @return Retorna a matricula do usuario;
	 * @throws Exception Se a chave estiver incorreta irá lancar um exception;
	 */
	public String liberaSistema(String chave, String nome, String dataNascimento) throws Exception{
		Funcionario funcionario = null;
		if (liberacao){
			throw new sistemaLiberadoException();
		}
		else if (chave.equalsIgnoreCase("c041ebf8")){
			liberacao = true;
			cadastraFuncionario(nome, "Diretor Geral", dataNascimento);
			return funcionario.getMatricula();
		}
		else{
			throw new chaveIncorretaException();
		}
	}
	
	/**
	 * Metodo que realiza login dos usuarios;
	 * @param matricula Recebe a matricula dos usuario;
	 * @return Retorna boolean;
	 */
	public boolean realizaLogin(String matricula){
		//N�o entendi muito bem essa parada de logout e fecha sistema. Vou perguntar a Gerson
		return true;
	}
	
	/**
	 * Metodo que tem a funcao de cadastrar um funcionario a partir do cargo por ele exercido;
	 * @param nome Nome do funcionario;
	 * @param cargo Cargo que o usuario exerce;
	 * @param dataNascimento Data de nascimento do usuario;
	 * @return Retorna adicionando um funcionario a lista de funcionarios;
	 */
	public boolean cadastraFuncionario(String nome, String cargo, String dataNascimento){
		Funcionario funcionario = null;
		if (cargo.equalsIgnoreCase("Diretor")){
			funcionario = factory.criaDiretor(nome, dataNascimento);
			funcionario.setMatricula(geraMatricula(cargo));
			funcionario.setSenha(dataNascimento.substring(6,9) + funcionario.getMatricula().substring(0, 3));
		}
		else if (cargo.equalsIgnoreCase("Medico")){
			funcionario = factory.criaMedico(nome, dataNascimento);
			funcionario.setMatricula(geraMatricula(cargo));
			funcionario.setSenha(dataNascimento.substring(6,9) + funcionario.getMatricula().substring(0, 3));
		}
		else if (cargo.equalsIgnoreCase("Tecnico Administrativo")){
			funcionario = factory.criaTecnico(nome, dataNascimento);
			funcionario.setMatricula(geraMatricula(cargo));
			funcionario.setSenha(dataNascimento.substring(6,9) + funcionario.getMatricula().substring(0, 3));
			
		}
		return funcionarios.add(funcionario);
	}
	
	/**
	 * Metodo que tem a funcao de gerar a matricula automaticamente de um usuario;
	 * @param cargo Cargo excercido pelo usuario;
	 * @return Retorna a matricula gerada;
	 */
	public String geraMatricula(String cargo){
		String matricula = "";
		if (cargo.equalsIgnoreCase("Diretor")){
			matricula += "12016";
			numeroFuncionarios += 1;
			matricula += numeroFuncionarios;
		}
		else if (cargo.equalsIgnoreCase("Medico")){
			matricula += "22016";
			numeroFuncionarios += 1;
			matricula += numeroFuncionarios;
		}
		else if (cargo.equalsIgnoreCase("Tecnico Administrativo")){
			matricula += "32016";
			numeroFuncionarios += 1;
			matricula += numeroFuncionarios;
		}
		return matricula;
	}
	
	/**
	 * Metodo que tem a funcao de verificar se existe um funcionario na lista a partir da
	 * matricula;
	 * @param matricula Matricula do usuario;
	 * @return Retorna o usuario encontrado ou nao;
	 */
	public Funcionario verificaFuncionario(String matricula){
		for (Funcionario novoFuncionario: funcionarios){
			if(novoFuncionario.getMatricula().equalsIgnoreCase(matricula)){
				return novoFuncionario;
			}
		}
		return null;
	}
	
	/**
	 * Metodo que altera a senha do usuario, verificando primeiramente se a senha é igual a 
	 * anterior e caso seja libera o sistema para alterar a senha;
	 * @param senha Antiga senha do usuario;
	 * @param matricula Matricula do usuario;
	 * @param novaSenha Nova senha digitada pelo usuario;
	 * @throws Exception Lanca excecao por causa do metodo verificaFuncionario;
	 */
	public void alteraSenha(String senha, String matricula, String novaSenha) throws Exception{
		Funcionario funcionario = verificaFuncionario(matricula);
		if(funcionario.getSenha().equalsIgnoreCase(senha)){
			if(verificaSenha(novaSenha)){
				funcionario.setSenha(novaSenha);
			}
		}
	}
	
	/**
	 * Metodo que permite que o usuario altere o seu nome;
	 * @param novoNome Novo nome do usuario;
	 * @param matricula Matricula do usuario;
	 */
	public void alteraNome(String novoNome, String matricula){
		Funcionario funcionario = verificaFuncionario(matricula);
		funcionario.setNome(novoNome);
	}
	
	
	/**
	 * Metodo que altera a data de nascimento do usuario;
	 * @param data Data de nascimento;
	 * @param matricula Matricula do usuario;
	 */
	public void alteraData(String data, String matricula){
		Funcionario funcionario = verificaFuncionario(matricula);
		funcionario.setDatanascimento(data);
	}

	/**
	 * Metodo que exclui funcionarios, apenas o diretor pode excluir um funcionario, por isso
	 * precisa conferir se a senha digitada e a mesma colocada pelo diretor anteriormente;
	 * @param matricula Matricula do usuario;
	 * @param senhaDiretor Senha do diretor;
	 */
	public void excluiFuncionario(String matricula, String senhaDiretor){
		Funcionario funcionario = verificaFuncionario(matricula);
		if(funcionario.getSenha().equalsIgnoreCase(senhaDiretor)){
			funcionarios.remove(funcionario);
		}
	}
	
	/**
	 * Metodo que verifica se a nova senha colocada pelo usuario e valida;
	 * @param senha Nova senha que sera utilizada;
	 * @return Retorna um boolean
	 * @throws Exception Lanca excecao caso a senha seja menor que 8 caracteres e maior que 12;
	 */
	public boolean verificaSenha(String senha)throws Exception{
		if (senha.length() < 8 || senha.length() > 12) {
			throw new Exception("Tamanho da senha deve estar entre 8 - 12 caracteres.");
		}
		return true;
	}
	
	/**
	 * Metodo que verifica se o novo nome escolhido pelo usuario e valido;
	 * @param nome Nome do usuario;
	 * @return Retorna um boolean;
	 * @throws Exception Lanca excecao caso o nome tenha mais de 12 caracteres;
	 */
	public boolean verificaNome(String nome)throws Exception{
		if (nome.length() > 16){
			throw new Exception("Tamanho maximo e 16 caracteres.");
		}
		return true;
	}
}
