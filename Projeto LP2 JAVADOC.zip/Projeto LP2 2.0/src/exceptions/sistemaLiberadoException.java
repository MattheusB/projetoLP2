package exceptions;

public class sistemaLiberadoException extends Exception{
	
	/**
	 * Classe Excecao que e lancada caso o usuario nao consiga acessar o sistema pois o sistema ja havia sido liberado
	 * anteriormente;
	 * @param mensagem Mensagem lancada para o usuario;
	 */
	public sistemaLiberadoException (String mensagem){
		super("Erro ao liberar o sistema. " + mensagem);
	}
	
	public sistemaLiberadoException(){
		super("Erro ao liberar o sistema. Sistema liberado anteriormente.");
	}

}
