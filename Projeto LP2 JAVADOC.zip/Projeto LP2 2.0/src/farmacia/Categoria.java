package farmacia;

/**
 * Classe enum criada para enumerar todas as categorias de remedios;
 */
public enum Categoria {
	ANALGESICO, ANTIBIOTICO, ANTIEMETICO,
	ANTIINFLAMATORIO, ANTITERMICO, HORMONAL;
}