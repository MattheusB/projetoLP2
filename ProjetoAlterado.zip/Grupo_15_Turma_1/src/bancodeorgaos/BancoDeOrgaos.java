package bancodeorgaos;

import java.util.ArrayList;

public class BancoDeOrgaos {

	private ArrayList<Orgao> bancodeorgaos;

	public BancoDeOrgaos() {
		bancodeorgaos = new ArrayList<Orgao>();
	}

	/**
	 * Metodo que tem por objetivo criar um orgao.
	 * 
	 * @param nome
	 *            Nome do orgao.
	 * @param tipoSanguineo
	 *            Tipo sanguineo do orgao.
	 * @return Retorna o orgao criado.
	 * @throws Exception
	 */
	public String cadastraOrgao(String nome, String tipoSanguineo) throws Exception {
		this.verificaTipoSanguineo(tipoSanguineo);

		Orgao novo = new Orgao(nome, tipoSanguineo);
		bancodeorgaos.add(novo);
		return novo.getNome();
	}

	/**
	 * Metodo que tem funcao de criar um orgao.
	 * 
	 * @param nome
	 *            Nome do orgao.
	 * @return Retorna o orgao.
	 * @throws Exception
	 */
	private boolean buscaOrgaos(String nome) throws Exception {
		for (Orgao novo : bancodeorgaos) {
			if (novo.getNome().equalsIgnoreCase(nome)) {
				return true;
			}
		}
		throw new Exception(" Orgao nao cadastrado.");
	}

	/**
	 * Metodo que tem a funcao de buscar um orgao compativel com o paciente.
	 * 
	 * @param nome
	 *            Nome do orgao.
	 * @param tipoSanguineo
	 *            Tipo sanguineo do orgao.
	 * @return Retorna o orgao.
	 * @throws Exception
	 */
	public boolean buscaOrgaosCompativel(String nome, String tipoSanguineo) throws Exception {
		Orgao novo = busca(nome, tipoSanguineo);
		if (novo == null) {
			throw new Exception(" Banco nao possui o orgao especificado.");
		}
		return true;
	}

	/**
	 * Metodo que busca orgao.
	 * 
	 * @param nome
	 *            Nome do orgao.
	 * @param tipoSanguneo
	 *            Tipo sanguineo do orgao.
	 * @return
	 */
	private Orgao busca(String nome, String tipoSanguneo) {
		for (Orgao novo : bancodeorgaos) {
			if (novo.getNome().equalsIgnoreCase(nome) && novo.getTipoSanguineo().equalsIgnoreCase(tipoSanguneo)) {
				return novo;
			}
		}
		return null;
	}

	/**
	 * Metodo que retorna a quantidade de orgaos.
	 * 
	 * @param nome
	 *            Nome do orgao.
	 * @return Retorna a quantidade de orgaos.
	 * @throws Exception
	 */
	public String quantidaOrgao(String nome) throws Exception {
		int quantidade = 0;
		this.buscaOrgaos(nome);
		for (Orgao novo : bancodeorgaos) {
			if (novo.getNome().equalsIgnoreCase(nome)) {
				quantidade += 1;
			}
		}
		return String.valueOf(quantidade);
	}

	/**
	 * Metodo que retorna o orgao pelo nome.
	 * 
	 * @param nome
	 *            Nome do orgao.
	 * @return Retorna o orgao buscado pelo nome.
	 * @throws Exception
	 */
	public String bucarOrgaoPeloNome(String nome) throws Exception {
		this.buscaOrgaos(nome);
		String saida = "";
		for (Orgao novo : bancodeorgaos) {
			if (novo.getNome().equalsIgnoreCase(nome)) {
				saida += novo.getTipoSanguineo() + ",";
			}
		}
		return saida.substring(0, saida.length() - 1);
	}

	/**
	 * Metodo que busca o orgao pelo tipo sanguineo.
	 * 
	 * @param tipoSanguineo
	 *            Tipo sanguineo.
	 * @return Retorna o orgao.
	 * @throws Exception
	 */
	public String buscarOrgaoTipoSanguineo(String tipoSanguineo) throws Exception {
		this.verificaTipoSanguineo(tipoSanguineo);
		String saida = "";
		ArrayList<String> novos = new ArrayList<String>();
		for (Orgao novo : bancodeorgaos) {
			if (novo.getTipoSanguineo().equalsIgnoreCase(tipoSanguineo)) {
				if (!(novos.contains(novo.getNome()))) {
					novos.add(novo.getNome());
				}
			}
		}

		for (String novonome : novos) {
			saida += novonome + ",";
		}

		if (saida.length() == 0) {
			throw new Exception(" Nao ha orgaos cadastrados para esse tipo sanguineo.");
		}

		return saida.substring(0, saida.length() - 1);
	}

	/**
	 * Metodo que busca o orgao pelo tipo sanguineo.
	 * 
	 * @param nome
	 *            Nome do orgao.
	 * @param tipoSanguineo
	 *            Tipo sanguineo do orgao.
	 * @return Retorna o orgao.
	 * @throws Exception
	 */
	public String buscarOrgaoNomeTipoSang(String nome, String tipoSanguineo) throws Exception {

		this.verificaTipoSanguineo(tipoSanguineo);

		for (Orgao novo : bancodeorgaos) {
			if (novo.getNome().equalsIgnoreCase(nome) && novo.getTipoSanguineo().equalsIgnoreCase(tipoSanguineo)) {
				return String.valueOf(true);
			}
		}

		return String.valueOf(false);
	}

	/**
	 * Metodo que verifica a quantidade de orgaos.
	 * 
	 * @param nome
	 *            Nome do orgao.
	 * @return Retorna a quantidade de orgaos.
	 * @throws Exception
	 */
	public String quantidadeDeOrgao(String nome) throws Exception {
		this.buscaOrgaos(nome);
		int quantidade = 0;
		for (Orgao novo : bancodeorgaos) {
			if (novo.getNome().equalsIgnoreCase(nome)) {
				quantidade += 1;
			}
		}

		return String.valueOf(quantidade);
	}

	/**
	 * Metodo que retorna a quantidade total de orgaos.
	 * 
	 * @return Retorna a quantidade total de orgaos.
	 */
	public String quantidadeTotalDeOrgaosDisponiveis() {
		return String.valueOf(bancodeorgaos.size());
	}

	/**
	 * Metodo que remove orgao.
	 * 
	 * @param nome
	 *            Nome do orgao.
	 * @param tipoSanguineo
	 *            Tipo sanguineo do orgao.
	 * @throws Exception
	 */
	public void remove(String nome, String tipoSanguineo) throws Exception {
		if (this.buscarOrgaoNomeTipoSang(nome, tipoSanguineo) == "false") {
			throw new Exception(" Orgao nao cadastrado.");

		}
		;
		this.verificaTipoSanguineo(tipoSanguineo);
		Orgao novo = busca(nome, tipoSanguineo);
		bancodeorgaos.remove(novo);
	}

	/**
	 * Metodo que verifica o tipo sanguineo.
	 * 
	 * @param tipo
	 *            Tipo sanguineo.
	 * @return Retorna o tipo sanguineo.
	 * @throws Exception
	 */
	private boolean verificaTipoSanguineo(String tipo) throws Exception {
		String[] tipos = { "A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-" };

		for (String s : tipos) {
			if (s.equals(tipo))
				return true;
		}
		throw new Exception(" Tipo sanguineo invalido.");
	}
}
