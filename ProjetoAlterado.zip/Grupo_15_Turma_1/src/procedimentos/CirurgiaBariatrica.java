package procedimentos;

import java.time.LocalDate;

import pacientes.Paciente;


/**
 * Classe que tem por objetivo realizar uma cirurgia Bariatrica.
 */
public class CirurgiaBariatrica extends Procedimentos {
	public CirurgiaBariatrica(Paciente paciente, double valormedicamento,String nomeMedico,LocalDate data) {
		
		super(7600,paciente,100,nomeMedico,data);
		realizaCirurgia(valormedicamento);
		
	}

	@Override
	public void realizaCirurgia(double valormedicamento) {
	
		Double novopeso = this.getPaciente().getPeso();

		novopeso -= novopeso * 0.10;
		this.getPaciente().setPeso(novopeso);
		
		this.getPaciente().descontoServico(this.getValor() + valormedicamento);
		this.getPaciente().ceditobonus(this.getPontos());

	}
	
	public String toString(){
		return "--> Cirurgia Bariatrica:\n" +
				"....... " +"Data: "+this.getData()+" Medico: "+this.getNomeMedico();
	}

}
