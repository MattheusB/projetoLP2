package procedimentos;


import java.time.LocalDate;

import pacientes.Paciente;

/**
 * Classe que tem por funcao principal realizar cirurgia.
 */

public abstract class Procedimentos {
	private double valor;
	private Paciente paciente;
	private int pontos;
	private String nomeMedico;
	private LocalDate data;
	
	public Procedimentos(double valor,Paciente paciente,int pontos,String nomeMedico,LocalDate data){
		this.valor = valor;
		this.paciente = paciente;
		this.pontos = pontos;
		this.nomeMedico = nomeMedico;
		this.data = data;
	}
	
	public abstract void  realizaCirurgia(double valormedicamento);
	
	public abstract String toString();
	
	public void setValor(double valor){
		this.valor = valor;
	}
	
	public double getValor(){
		return this.valor;
	}
	
	public void setPontos(int pontos){
		this.pontos = pontos;
	}
	
	public int getPontos(){
		return this.pontos;
	}
	
	public Paciente getPaciente(){
		return this.paciente;
	}
	
	public void setPaciente(Paciente paciente){
		this.paciente = paciente;
	}

	public String getNomeMedico() {
		return nomeMedico;
	}

	public void setNomeMedico(String nomeMedico) {
		this.nomeMedico = nomeMedico;
	}

	public LocalDate getData() {
		return data;
	}

	public void setData(LocalDate data) {
		this.data = data;
	}
}
