package procedimentos;

import java.time.LocalDate;

import pacientes.Paciente;


/**
 * Classe que tem por objetivo realizar uma consulta clinica.
 */
public class ConsultaClinica extends Procedimentos {

	public ConsultaClinica(Paciente paciente, double valormedicamento,String nomeMedico,LocalDate data) {
		super(350,paciente,50,nomeMedico,data);
		realizaCirurgia(valormedicamento);
	}

	@Override
	public void realizaCirurgia(double valormedicamento) {
		
		

		
		this.getPaciente().descontoServico(this.getValor() + valormedicamento);
		this.getPaciente().ceditobonus(this.getPontos());

	}
	
	public String toString(){
		return "--> Consulta clinica:\n" +
				"....... " +"Data: "+this.getData()+" Medico: "+this.getNomeMedico();
	}

}
