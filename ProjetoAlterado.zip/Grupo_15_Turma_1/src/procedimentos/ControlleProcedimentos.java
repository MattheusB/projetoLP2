package procedimentos;

import java.time.LocalDate;



import pacientes.Paciente;
import pacientes.Prontuario;
/**
 * Classe que tem por objetivo administrar os procedimentos a serem realizados.
 */
public class ControlleProcedimentos {

	

	
	/**
	 * Metodo que realiza o procedimento.
	 * @param prontuario Prontuario.
	 * @param procedimento Procedimento.
	 * @param valor Valor do procedimento.
	 * @throws Exception
	 */
	public void procedimentos(Prontuario prontuario, String procedimento, Double valor,String nomeMedico,LocalDate data) throws Exception {

	
		procedimento(procedimento, prontuario,valor,nomeMedico,data);
	}

	/**
	 * Metodo que realiza procediemento.
	 * @param procedimento Procedimento.
	 * @param prontuario Um novo prontuario.
	 * @return Retorna Verdade caso os procedimentos tenham sido realizados.
	 * @throws Exception
	 */
	private boolean procedimento(String procedimento, Prontuario prontuario,double valormedicamento,String nomeMedico,LocalDate data) throws Exception {
		
		Paciente paciente = prontuario.getPaciente();
		
		switch (procedimento) {
		case "Consulta clinica":
			
			ConsultaClinica consultaClinica = new ConsultaClinica(paciente,valormedicamento,nomeMedico,data);
			prontuario.addProcedimento(consultaClinica);
			
			return true;

		case "Cirurgia bariatrica":
			
			CirurgiaBariatrica cirurgiabariatrica = new CirurgiaBariatrica(paciente,valormedicamento,nomeMedico,data);
			prontuario.addProcedimento(cirurgiabariatrica);
			return true;
		
		case "Redesignacao sexual":
			RedesiguinacaoSexual operacaosexual = new RedesiguinacaoSexual(paciente,valormedicamento,nomeMedico,data);
			prontuario.addProcedimento(operacaosexual);
			return true;
		default:
			throw new Exception(" Procedimento invalido.");
		}
	}
	
	/**
	 * Metodo que realiza o transplante de orgaos.
	 * @param prontuario
	 * @param valor
	 * @throws Exception
	 */
	public void trasnplantedeOrgaos(Prontuario prontuario, Double valor,String nomeMedico,LocalDate data,String orgao) throws Exception {
		
		Paciente paciente = prontuario.getPaciente();

		TransplantedeOrgao transplante = new TransplantedeOrgao(paciente,valor,nomeMedico,data,orgao);
		prontuario.addProcedimento(transplante);

	}

}
