package cartaofidelidade;

/**
 * Classe que da desconto no servico e da credito bonus caso o paciente seja vip.
 */
public class CartaoVip implements CartaoFidelidade{

	@Override
	public double descontoservico(double valor) {
		Double novovalor = valor;
		novovalor -= valor * 0.3;
		return novovalor;
		
	}

	@Override
	public int creditobonus(int pontos) {
		int novoponto = pontos;
		novoponto += pontos * 0.1;
		return (int) novoponto;
		
	}

}
