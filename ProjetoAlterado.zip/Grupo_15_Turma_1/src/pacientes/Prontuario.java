package pacientes;

import java.util.ArrayList;
import java.util.UUID;


import procedimentos.Procedimentos;

/**
 * Classe que tem a funcao de criar um prontuario de pacientes, armazenando todas as suas informacoes.
 */
public class Prontuario implements Comparable<Prontuario> {
	private ArrayList<Procedimentos> procedimentos;
	private Paciente paciente;
	
	/**
	 * Metodo que cria o prontuario.
	 * @param nome Nome do paciente.
	 * @param dataNacimento Data de nascimento do paciente.
	 * @param peso Massa do paciente.
	 * @param sexo Sexo do paciente.
	 * @param genero Genero do paciente.
	 * @param tipoSanguineo Tipo sanguineo do paciente.
	 * @param id ID do paciente.
	 * @throws Exception
	 */
	public Prontuario(String nome, String dataNacimento, double peso, String sexo, String genero, String tipoSanguineo,
			UUID id) throws Exception {
		paciente = new Paciente(nome, dataNacimento, peso, sexo, genero, tipoSanguineo, id);
		this.procedimentos = new ArrayList<Procedimentos>();
	}
	
	/**
	 * Metodo que adiciona procedimento.
	 * @param novo Procedimento.
	 */
	public void addProcedimento(Procedimentos novo) {
		this.procedimentos.add(novo);
	}
	
	/**
	 * Metodo que busca a quantidade de procedimentos.
	 * @return Retorna o tamanho de procedimentos.
	 */
	public String getQuantidadeProcedimentos() {

		return String.valueOf(procedimentos.size());
	}
	
	private String fichaProcedimentos(){
		String saida = "";
		for(Procedimentos novoProcedimento : procedimentos){
			saida += novoProcedimento.toString() + "\n";
		}
		
		return saida;
	}
	
	public String fichaPaciente(){
		String saida = "";
		saida += this.paciente.toString()+ "\n" + fichaProcedimentos();
		return saida;
	}
	
	/**
	 * Metodo que busca informacoes do paciente.
	 * @param atributo Atributo.
	 * @return Retorna o nome do paciente.
	 */
	public String getInfoPaciente(String atributo) {

		if (atributo.equalsIgnoreCase("Nome")) {

			return paciente.getNome();
		}

		if (atributo.equalsIgnoreCase("Data")) {

			return String.valueOf(paciente.getDataDeNascimento());
		}

		if (atributo.equalsIgnoreCase("TipoSanguineo")) {

			return paciente.getTipoSanguineo();
		}

		if (atributo.equalsIgnoreCase("Sexo")) {

			return paciente.getSexo();
		}

		if (atributo.equalsIgnoreCase("Idade")) {

			return String.valueOf(paciente.getIdade());
		}

		if (atributo.equalsIgnoreCase("Peso")) {

			return String.valueOf(paciente.getPeso());
		}

		if (atributo.equalsIgnoreCase("Genero")) {

			return paciente.getGenero();
		}

		return null;
	}

	public Paciente getPaciente() {
		return this.paciente;
	}

	@Override
	public int compareTo(Prontuario novo) {

		return this.paciente.getNome().compareTo(novo.getPaciente().getNome());
	}
}
