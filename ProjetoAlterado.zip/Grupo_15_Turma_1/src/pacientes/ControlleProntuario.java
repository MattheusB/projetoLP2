package pacientes;

import java.util.ArrayList;

import java.util.Collections;

import java.util.UUID;

/**
 * Classe que tem a funcao de controlar o prontuario.
 */
public class ControlleProntuario {
	private ArrayList<Prontuario> prontuarios;
	private int qntdpacientes = 0;
	
	public ControlleProntuario(){
		prontuarios  = new ArrayList<Prontuario>();
	}
	
	/**
	 * Metodo que tem a funcao de criar um paciente.
	 * 
	 * @param nome
	 *            Nome do paciente.
	 * @param dataDeNacimento
	 *            Data de nascimento do paciente.
	 * @param peso
	 *            Massa do paciente.
	 * @param sexo
	 *            Sexo do paciente.
	 * @param genero
	 *            Genero do paciente.
	 * @param tipoSanguineo
	 *            Tipo Sanguineo do paciente.
	 * @return Retorna um paciente.
	 * @throws Exception
	 */
	public String criarPaciente(String nome, String dataDeNacimento, double peso,String sexo,String genero,String tipoSanguineo)throws Exception{
		this.qntdpacientes += 1;
		UUID id = UUID.randomUUID();
		Prontuario novo = new Prontuario(nome, dataDeNacimento, peso,sexo,genero, tipoSanguineo,id);
		
		if(verifica(novo)){
			throw new Exception("Nao foi possivel cadastrar o paciente. Paciente ja cadastrado."); 
		}
		
		prontuarios.add(novo);
		
		Collections.sort(prontuarios);
		
		return novo.getPaciente().getId().toString();
	}

	/**
	 * Metodo que verifica em prontuario se possui o paciente procurado.
	 * 
	 * @param prontuario Prontuario.
	 * @return retorna verdade se achar o paciente.
	 */
	private boolean verifica(Prontuario prontuario){
		for(Prontuario novo : prontuarios){
			if(novo.getPaciente().getNome().equals(prontuario.getPaciente().getNome())){
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Busca gastos do paciente
	 * @param id ID do paciente.
	 * @return Total de gastos.
	 */
	public String getGastosPaciente(String id){
		Prontuario novo = verificaProntuario(id);
		String resultado = String.format("%.2f", novo.getPaciente().getValorprocedimentos()).replace(",", ".");
		return resultado;
	}
	
	/**
	 * Busca porntos do paciente.
	 * @param id ID do paciente.
	 * @return Retorna os pontos.
	 */
	public String getPontosFidelidade(String id){
		Prontuario novo = verificaProntuario(id);
		
		return String.valueOf(novo.getPaciente().getPontos());
	}
	
	public String fichaPaciente(String id){
		Prontuario prontuario = verificaProntuario(id);
		return prontuario.fichaPaciente();
	}
	
	/**
	 * Metodo que busca um paciente no prontuario pelo nome.
	 * @param nome
	 * @return
	 */
	public Prontuario verificaProntuario(String nome){
		UUID id = UUID.fromString(nome);
		for(Prontuario novo : prontuarios){
			
			if(novo.getPaciente().getId().equals(id)){
				
				return novo;
			}
		}
		
		return null;
	}
	
	/**
	 * Metodo que verifica em prontuario se possui o paciente procurado.
	 * 
	 * @param nome
	 *            Nome do paciente.
	 * @param tipoSanguineo
	 *            Tipo sanguineo.
	 * @return retorna verdade se achar o paciente.
	 */
	private Prontuario verifica(String nome){
	for(Prontuario novo : prontuarios){
			
			if(novo.getPaciente().getNome().equalsIgnoreCase(nome)){
				
				return novo;
			}
		}
		return null;
	}
	
	/**
	 * Busca o ID do paciente.
	 * @param nome Nome do paciente.
	 * @return Retorna o ID do paciente.
	 */
	public String getIdPaciente(String nome){
		
		Prontuario novo = this.verifica(nome);
		
		return String.valueOf(novo.getPaciente().getId());
	}
	
	/**
	 * Metodo que recupera informacoes do paciente. 
	 * @param nome Nome do paciente.
	 * @param atributo Atributo do paciente.
	 * @return Retorna o atributo do paciente.
	 */
	public String getInfoPaciente(String nome ,String atributo){
		Prontuario prontuario = verificaProntuario(nome);
		
		return prontuario.getInfoPaciente(atributo);
	}
	
	/**
	 * Busca o total de procedimento.
	 * @param nome Nome do paciente.
	 * @return Retorna a quantidade de procedimentos.
	 */
	public String getTotalProcedimento(String nome){
		Prontuario novo = verificaProntuario(nome);
		return novo.getQuantidadeProcedimentos();
	}
	
	/**
	 * Metodo que busca prontuario.
	 * @param posicao Posicao que deseja buscar no prontuario.
	 * @return Retorna a posicao em que o paciente esta.
	 * @throws Exception
	 */
	public String getProntuario(int posicao)throws Exception{
		if(posicao > prontuarios.size()-1){
			throw new Exception("Erro ao consultar prontuario. Nao ha prontuarios suficientes (max = "+prontuarios.size()+").");
		}
		if(posicao < 0){
			throw new Exception("Erro ao consultar prontuario. Indice do prontuario nao pode ser negativo.");
			
		}
		return prontuarios.get(posicao).getPaciente().getId().toString();
	}
	
	

	public int getQntdpacientes() {
		return qntdpacientes;
	}

	public void setQntdpacientes(int qntdpacientes) {
		this.qntdpacientes = qntdpacientes;
	}

}
