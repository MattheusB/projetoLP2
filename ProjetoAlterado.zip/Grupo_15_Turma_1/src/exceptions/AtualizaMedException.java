package exceptions;

public class AtualizaMedException extends Exception {
	public AtualizaMedException(String mensagem) {
		super("Erro ao atualizar medicamento. " + mensagem);
	}

	public AtualizaMedException() {
		super("Erro ao atualizar medicamento.");
	}

}
