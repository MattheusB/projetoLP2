package exceptions;

public class CargoInexistenteException extends Exception{
	public CargoInexistenteException(String mensagem){
		super ("Erro no cadastro de funcionario. " + mensagem);
	}
	
	public CargoInexistenteException(){
		super ("Erro no cadastro de funcionario. Cargo invalido.");
	}

}
