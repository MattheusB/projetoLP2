package exceptions;

/**
 * Excecao "Cadastra Paciente Incorreto"
 * A exception eh chamada quando ocorre um erro ao cadastrar pacientes pelo fato do usuario logado n�o 
 * ter permissoes para cadastrar um paciente (medico).
 */

public class CadastraPacienteIncorretoException extends Exception {

	public CadastraPacienteIncorretoException(String mensagem) {
		super("Nao foi possivel cadastrar o paciente. O funcionario " + mensagem
				+ " nao tem permissao para cadastrar pacientes.");
	}

	public CadastraPacienteIncorretoException() {
		super("Nao foi possivel cadastrar o paciente.");
	}

}
