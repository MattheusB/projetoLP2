package exceptions;

public class CadastraMedicamentoIncorretoException extends Exception {
	public CadastraMedicamentoIncorretoException(String mensagem) {
		super("Erro no cadastro de medicamento. O funcionario " + mensagem
				+ " nao tem permissao para cadastrar medicamentos.");
	}

	public CadastraMedicamentoIncorretoException() {
		super("Erro no cadastro de medicamento.");
	}
}
