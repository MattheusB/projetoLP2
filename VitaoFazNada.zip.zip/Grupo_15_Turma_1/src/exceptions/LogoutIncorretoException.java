package exceptions;

public class LogoutIncorretoException extends Exception{
	public LogoutIncorretoException(String mensagem){
		super("Nao foi possivel realizar o logout. " + mensagem);
	}
	
	public LogoutIncorretoException(){
		super("Nao foi possivel realizar o logout. Nao ha um funcionario logado.");
	}
}
