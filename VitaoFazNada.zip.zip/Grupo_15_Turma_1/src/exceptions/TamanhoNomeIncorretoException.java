package exceptions;

public class TamanhoNomeIncorretoException extends Exception{
	public TamanhoNomeIncorretoException(String mensagem){
		super("Tamanho maximo e 16 caracteres.");
	}
	
	public TamanhoNomeIncorretoException(){
		super("Tamanho maximo e ");
	}

}
