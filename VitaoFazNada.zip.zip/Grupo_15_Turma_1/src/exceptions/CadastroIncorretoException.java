package exceptions;

public class CadastroIncorretoException extends Exception{
	public CadastroIncorretoException(String mensagem){
		super("Erro no cadastro de funcionario. " + mensagem);
	}
	
	public CadastroIncorretoException(){
		super("Erro no cadastro de funcionario.");
	}
}
