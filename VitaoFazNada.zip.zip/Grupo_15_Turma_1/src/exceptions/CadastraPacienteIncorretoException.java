package exceptions;

public class CadastraPacienteIncorretoException extends Exception {

	public CadastraPacienteIncorretoException(String mensagem) {
		super("Nao foi possivel cadastrar o paciente. O funcionario " + mensagem
				+ " nao tem permissao para cadastrar pacientes.");
	}

	public CadastraPacienteIncorretoException() {
		super("Nao foi possivel cadastrar o paciente.");
	}

}
