package exceptions;

public class ExcluiIncorretoException extends Exception{
	
	public ExcluiIncorretoException(String mensagem) {
		super("Erro ao excluir funcionario. " + mensagem);
	}
	
	public ExcluiIncorretoException(){
		super("Erro ao excluir funcionario.");
	}

}
