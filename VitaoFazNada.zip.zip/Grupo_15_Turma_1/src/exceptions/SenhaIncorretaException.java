package exceptions;

public class SenhaIncorretaException extends Exception{
	public SenhaIncorretaException(String mensagem){
		super("Tamanho da senha deve estar entre " + mensagem);
	}
	
	public SenhaIncorretaException(){
		super("Tamanho da senha deve estar entre 8 - 12 caracteres.");
	}

}
