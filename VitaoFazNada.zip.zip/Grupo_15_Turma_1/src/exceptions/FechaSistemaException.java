package exceptions;

public class FechaSistemaException extends Exception {
	public FechaSistemaException(String mensagem) {
		super("Nao foi possivel fechar o sistema. Um funcionario ainda esta logado: " + mensagem + ".");
	}

	public FechaSistemaException() {
		super("Nao foi possivel fechar o sistema. Um funcionario ainda esta logado.");
	}

}
