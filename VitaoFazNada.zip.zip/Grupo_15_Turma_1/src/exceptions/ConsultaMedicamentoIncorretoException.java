package exceptions;

public class ConsultaMedicamentoIncorretoException extends Exception{
	public ConsultaMedicamentoIncorretoException(String mensagem){
		super("Erro na consulta de medicamentos. " + mensagem);
	}
	
	public ConsultaMedicamentoIncorretoException(){
		super("Erro na consulta de medicamentos. Tipo de ordenacao invalida.");
	}
}
