package exceptions;

public class NomeInvalidoException extends Exception{
	public NomeInvalidoException(String mensagem){
		super("Erro no cadastro de funcionario." + mensagem);
		
	}
	
	public NomeInvalidoException(){
		super("Erro no cadastro de funcionario. Nome do funcionario nao pode ser vazio.");
	}

}
