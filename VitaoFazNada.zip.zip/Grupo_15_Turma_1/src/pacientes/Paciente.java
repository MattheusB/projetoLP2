package pacientes;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.UUID;

public class Paciente {
	
	private String nome;
	private LocalDate dataDeNascimento;
	private double peso;
	private String tipoSanguineo;
	private String sexo;
	private String genero;
	private UUID id;
	private int idade;
	
	
	public Paciente(String nome, String dataNacimento, double peso,String sexo, String genero,String tipoSanguineo, UUID id)throws Exception{
		if(nome.trim().isEmpty() || nome == null){
			throw new Exception("Nao foi possivel cadastrar o paciente. Nome do paciente nao pode ser vazio.");
		}
		verificaData(dataNacimento);
		if(peso < 0){
			throw new Exception("Nao foi possivel cadastrar o paciente. Peso do paciente nao pode ser negativo.");
		}
		
		if(!(verificaTipoSanguineo(tipoSanguineo))){
			throw new Exception("Nao foi possivel cadastrar o paciente. Tipo sanguineo invalido.");
		}
		
		String datas = dataNacimento;
		DateTimeFormatter formatador = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate dataa= LocalDate.parse(datas, formatador);
		LocalDate hoje = LocalDate.now();
		long diferencaEmAnos = ChronoUnit.YEARS.between(dataa,hoje);
		this.nome = nome;
		this.dataDeNascimento = dataa;
		this.peso = peso;
		this.tipoSanguineo = tipoSanguineo;
		this.sexo = sexo;
		this.genero = genero;
		this.id = id;
		this.idade = (int) diferencaEmAnos;
		
		
	}
	
	private void verificaData(String dataNascimento) throws Exception {
		try {
			// parse nao aceita datas de dia e mes invalidas
			// relancando entao, propria exception
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			@SuppressWarnings("unused")
			LocalDate data = LocalDate.parse(dataNascimento, formatter);
			
		} catch (Exception e) {
			throw new Exception("Nao foi possivel cadastrar o paciente. Data invalida.");
		}
		
		
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dataDeNascimento == null) ? 0 : dataDeNascimento.hashCode());
		result = prime * result + ((genero == null) ? 0 : genero.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((nome == null) ? 0 : nome.hashCode());
		long temp;
		temp = Double.doubleToLongBits(peso);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((sexo == null) ? 0 : sexo.hashCode());
		result = prime * result + ((tipoSanguineo == null) ? 0 : tipoSanguineo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Paciente other = (Paciente) obj;
		if (dataDeNascimento == null) {
			if (other.dataDeNascimento != null)
				return false;
		} else if (!dataDeNascimento.equals(other.dataDeNascimento))
			return false;
		if (genero == null) {
			if (other.genero != null)
				return false;
		} else if (!genero.equals(other.genero))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (nome == null) {
			if (other.nome != null)
				return false;
		} else if (!nome.equals(other.nome))
			return false;
		if (Double.doubleToLongBits(peso) != Double.doubleToLongBits(other.peso))
			return false;
		if (sexo == null) {
			if (other.sexo != null)
				return false;
		} else if (!sexo.equals(other.sexo))
			return false;
		if (tipoSanguineo == null) {
			if (other.tipoSanguineo != null)
				return false;
		} else if (!tipoSanguineo.equals(other.tipoSanguineo))
			return false;
		return true;
	}

	private boolean verificaTipoSanguineo(String tipo) {
		String[] tipos = { "A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-" };

		for (String s : tipos) {
			if (s.equals(tipo))
				return true;
		}
		return false;
	}
	
	public String toString(){
		return "Nome: " + this.nome + "\nData de Nascimento: " + this.dataDeNascimento + "\nPeso: " + this.peso 
				+ "\nTipo Sanguineo: " + this.tipoSanguineo + "\nSexo: " + this.sexo + "\nGenero: " + this.genero + "\nID: " + this.id;
	}


	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}


	public LocalDate getDataDeNascimento() {
		return dataDeNascimento;
	}


	public void setDataDeNascimento(LocalDate dataDeNascimento) {
		this.dataDeNascimento = dataDeNascimento;
	}


	public double getPeso() {
		return peso;
	}


	public void setPeso(double peso) {
		this.peso = peso;
	}


	public String getTipoSanguineo() {
		return tipoSanguineo;
	}


	public void setTipoSanguineo(String tipoSanguineo) {
		this.tipoSanguineo = tipoSanguineo;
	}


	public String getSexo() {
		return sexo;
	}


	public void setSexo(String sexo) {
		this.sexo = sexo;
	}


	public String getGenero() {
		return genero;
	}


	public void setGenero(String genero) {
		this.genero = genero;
	}


	public UUID getId() {
		return id;
	}


	public void setId(UUID id) {
		this.id = id;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}







}
