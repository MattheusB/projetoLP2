package pacientes;

import java.util.ArrayList;

import java.util.Collections;

import java.util.UUID;

public class ControlleProntuario {
	private ArrayList<Prontuario> prontuarios;
	private int qntdpacientes = 0;
	
	public ControlleProntuario(){
		prontuarios  = new ArrayList<Prontuario>();
	}
	
	public String criarPaciente(String nome, String dataDeNacimento, double peso,String sexo,String genero,String tipoSanguineo)throws Exception{
		this.qntdpacientes += 1;
		UUID id = UUID.randomUUID();
		Prontuario novo = new Prontuario(nome, dataDeNacimento, peso,sexo,genero, tipoSanguineo,id);
		
		if(verifica(novo)){
			throw new Exception("Nao foi possivel cadastrar o paciente. Paciente ja cadastrado."); 
		}
		
		prontuarios.add(novo);
		
		Collections.sort(prontuarios);
		
		return novo.getPaciente().getNome();
	}
	
	private boolean verifica(Prontuario prontuario){
		for(Prontuario novo : prontuarios){
			if(novo.getPaciente().getNome().equals(prontuario.getPaciente().getNome())){
				return true;
			}
			
		}
		
		return false;
	}
	
	private Prontuario verificaProntuario(String nome){
		
		for(Prontuario novo : prontuarios){
			
			if(novo.getPaciente().getNome().equalsIgnoreCase(nome)){
				
				return novo;
			}
		}
		
		return null;
	}
	
	public String getInfoPaciente(String nome ,String atributo){
		Prontuario prontuario = verificaProntuario(nome);
		
		return prontuario.getInfoPaciente(atributo);
		
		
	}
	
	public String getProntuario(int posicao)throws Exception{
		if(posicao > prontuarios.size()-1){
			throw new Exception("Erro ao consultar prontuario. Nao ha prontuarios suficientes (max = "+prontuarios.size()+").");
		}
		if(posicao < 0){
			throw new Exception("Erro ao consultar prontuario. Indice do prontuario nao pode ser negativo.");
			
		}
		return prontuarios.get(posicao).getPaciente().getNome();
	}

	public int getQntdpacientes() {
		return qntdpacientes;
	}

	public void setQntdpacientes(int qntdpacientes) {
		this.qntdpacientes = qntdpacientes;
	}

}
