package controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;

import exceptions.AtualizaIncorretoException;
import exceptions.CadastraMedicamentoIncorretoException;
import exceptions.CadastraPacienteIncorretoException;
import exceptions.CadastroIncorretoException;
import exceptions.ConsultaIncorretaException;
import exceptions.ConsultaMedicamentoIncorretoException;
import exceptions.ExcluiIncorretoException;
import exceptions.FechaSistemaException;
import exceptions.LoginIncorretoException;
import exceptions.LogoutIncorretoException;
import exceptions.SenhaIncorretaException;
import exceptions.TamanhoNomeIncorretoException;
import exceptions.LiberaSistemaException;
import farmacia.Farmacia;
import farmacia.Medicamento;
import funcionario.Funcionario;
import funcionario.FuncionarioFactory;
import funcionario.Funcoes;
import pacientes.ControlleProntuario;

/**
 * Classe controller que tem a duncao de administrar todo o codigo por tras da
 * facade;
 */
public class Controller {
	FuncionarioFactory factory = new FuncionarioFactory();
	HashMap<String, Funcionario> funcionarios = new HashMap<String, Funcionario>();
	boolean liberacao = false;
	private Funcionario funcionarioAtual = null;
	private ControlleProntuario prontuario = new ControlleProntuario();
	private Farmacia farmacia = new Farmacia();

	/**
	 * Metodo que tem a funcao de liberar o sistema para os usuarios. Primeiro
	 * acesso feito apenas pelo diretor;
	 * 
	 * @param chave
	 *            Chave que abre o sistema;
	 * @param nome
	 *            Nome do Usuario;
	 * @param dataNascimento
	 *            Data de Nascimento do Usuario;
	 * @return Retorna a matricula do usuario;
	 * @throws Exception
	 *             Se a chave estiver incorreta ir� lancar um exception;
	 */
	public String liberaSistema(String chave, String nome, String dataNascimento) throws Exception {
		if (liberacao) {
			throw new LiberaSistemaException("Sistema liberado anteriormente.");
		}
		if (!(chave.equalsIgnoreCase("c041ebf8"))) {
			throw new LiberaSistemaException("Chave invalida.");
		} else {
			liberacao = true;
			Funcionario diretor = factory.cadastraFuncionario(nome, "Diretor Geral", dataNascimento);
			funcionarios.put(diretor.getMatricula(), diretor);
			return diretor.getMatricula();
		}

	}

	/**
	 * Metodo que realiza login dos usuarios;
	 * 
	 * @param matricula
	 *            Recebe a matricula dos usuario;
	 * @return Retorna boolean;
	 */
	public String login(String matricula, String senha) throws Exception {
		if (funcionarioAtual != null) {
			throw new LoginIncorretoException("Um funcionario ainda esta logado: " + funcionarioAtual.getNome() + ".");
		}

		if (senha.length() < 8 || senha.length() > 12) {
			throw new LoginIncorretoException("Senha incorreta.");
		}

		Funcionario funcionario = funcionarios.get(matricula);

		if ((funcionario == null)) {
			throw new LoginIncorretoException("Funcionario nao cadastrado.");
		}
		if (funcionario.getSenha().equalsIgnoreCase(senha)) {
			funcionarioAtual = funcionario;
			return funcionario.getMatricula();
		}

		throw new LoginIncorretoException("Senha incorreta.");

	}

	/**
	 * Metodo que tem a funcao de cadastrar um funcionario a partir do cargo por
	 * ele exercido;
	 * 
	 * @param nome
	 *            Nome do funcionario;
	 * @param cargo
	 *            Cargo que o usuario exerce;
	 * @param dataNascimento
	 *            Data de nascimento do usuario;
	 * @return Retorna adicionando um funcionario a lista de funcionarios;
	 */
	public String cadastraFuncionario(String nome, String cargo, String dataNascimento) throws Exception {
		if (!(funcionarioAtual.verificaFuncao(Funcoes.CADASTRAR))) {
			throw new CadastroIncorretoException(
					"O funcionario " + funcionarioAtual.getNome() + " nao tem permissao para cadastrar funcionarios.");

		}
		String[] data = dataNascimento.split("/");
		if (Integer.parseInt(data[0]) > 31 || Integer.parseInt(data[1]) > 12) {
			throw new CadastroIncorretoException("Data invalida.");
		}
		Funcionario funcionario = factory.cadastraFuncionario(nome, cargo, dataNascimento);
		funcionarios.put(funcionario.getMatricula(), funcionario);
		return funcionario.getMatricula();
	}

	/**
	 * Metodo que tem a funcao de gerar a matricula automaticamente de um
	 * usuario;
	 * 
	 * @param cargo
	 *            Cargo excercido pelo usuario;
	 * @return Retorna a matricula gerada;
	 */
	public String getInfoFuncionario(String matricula, String atributo) throws Exception {
		String string = "";
		if (matricula.length() < 7) {
			throw new ConsultaIncorretaException("A matricula nao segue o padrao.");
		}

		if (atributo.equalsIgnoreCase("senha"))
			throw new ConsultaIncorretaException("A senha do funcionario eh protegida.");

		Funcionario funcionario = funcionarios.get(matricula);
		if (funcionario == null) {
			throw new ConsultaIncorretaException("Funcionario nao cadastrado.");
		}

		if (atributo.equalsIgnoreCase("Nome")) {
			string += funcionario.getNome();
		}
		if (atributo.equalsIgnoreCase("Cargo")) {
			string += funcionario.getCargo();
		}
		if (atributo.equalsIgnoreCase("Data")) {
			string += funcionario.getDatanascimento();
		}

		return string;

	}

	/**
	 * Metodo que altera a senha do usuario, verificando primeiramente se a
	 * senha � igual a anterior e caso seja libera o sistema para alterar a
	 * senha;
	 * 
	 * @param senha
	 *            Antiga senha do usuario;
	 * @param matricula
	 *            Matricula do usuario;
	 * @param novaSenha
	 *            Nova senha digitada pelo usuario;
	 * @throws Exception
	 *             Lanca excecao por causa do metodo verificaFuncionario;
	 */
	public boolean atualizaSenha(String senha, String novaSenha) throws Exception {
		if (funcionarioAtual.getSenha().equalsIgnoreCase(senha)) {

			if (novaSenha.length() < 8 || novaSenha.length() > 12) {
				throw new AtualizaIncorretoException("A nova senha deve ter entre 8 - 12 caracteres alfanumericos.");
			}

			funcionarioAtual.setSenha(novaSenha);
			return true;

		}

		throw new AtualizaIncorretoException("Senha invalida.");
	}

	/**
	 * Metodo que permite que o usuario altere o seu nome;
	 * 
	 * @param novoNome
	 *            Novo nome do usuario;
	 * @param matricula
	 *            Matricula do usuario;
	 */
	public void alteraNome(String novoNome, String matricula) throws Exception {
		Funcionario funcionario = funcionarios.get(matricula);
		funcionario.setNome(novoNome);
	}

	/**
	 * Metodo que altera a data de nascimento do usuario;
	 * 
	 * @param data
	 *            Data de nascimento;
	 * @param matricula
	 *            Matricula do usuario;
	 */
	public void alteraData(String data, String matricula) throws Exception {
		Funcionario funcionario = funcionarios.get(matricula);
		DateTimeFormatter formatador = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate date = LocalDate.parse(data, formatador);
		funcionario.setDatanascimento(date);
	}

	/**
	 * Metodo que exclui funcionarios, apenas o diretor pode excluir um
	 * funcionario, por isso precisa conferir se a senha digitada e a mesma
	 * colocada pelo diretor anteriormente;
	 * 
	 * @param matricula
	 *            Matricula do usuario;
	 * @param senhaDiretor
	 *            Senha do diretor;
	 */
	public boolean excluiFuncionario(String matricula, String senhaDiretor) throws Exception {

		if (!(this.funcionarioAtual.verificaFuncao(Funcoes.EXCLUIFUNCIONARIO))) {
			throw new ExcluiIncorretoException("O funcionario " + this.funcionarioAtual.getNome()
					+ " nao tem permissao para excluir funcionarios.");
		}
		if (!(matricula.matches("^[0-9]*$"))) {
			throw new ExcluiIncorretoException("A matricula nao segue o padrao.");
		}
		Funcionario funcionario = funcionarios.get(matricula);

		if (funcionario == null) {
			throw new ExcluiIncorretoException("Funcionario nao cadastrado.");
		}
		if (this.funcionarioAtual.getSenha().equalsIgnoreCase(senhaDiretor)) {
			funcionarios.remove(funcionario.getMatricula());
			return true;
		}

		throw new ExcluiIncorretoException("Senha invalida.");
	}

	/**
	 * Metodo que verifica se a nova senha colocada pelo usuario e valida;
	 * 
	 * @param senha
	 *            Nova senha que sera utilizada;
	 * @return Retorna um boolean
	 * @throws Exception
	 *             Lanca excecao caso a senha seja menor que 8 caracteres e
	 *             maior que 12;
	 */
	public boolean verificaSenha(String senha) throws Exception {
		if (senha.length() < 8 || senha.length() > 12) {
			throw new SenhaIncorretaException();
		}
		return true;
	}

	/**
	 * Metodo que verifica se o novo nome escolhido pelo usuario e valido;
	 * 
	 * @param nome
	 *            Nome do usuario;
	 * @return Retorna um boolean;
	 * @throws Exception
	 *             Lanca excecao caso o nome tenha mais de 12 caracteres;
	 */
	public boolean verificaNome(String nome) throws Exception {
		if (nome.length() > 16) {
			throw new TamanhoNomeIncorretoException();
		}
		return true;
	}

	public void fechaSistema() throws Exception {
		if (funcionarioAtual == null) {
		} else {
			throw new FechaSistemaException(funcionarioAtual.getNome());
		}
	}

	public void logout() throws Exception {
		if (funcionarioAtual != null) {
			funcionarioAtual = null;
		}

		else {
			throw new LogoutIncorretoException();
		}
	}

	public void atualizaInfoFuncionario(String atributo, String novoValor) throws Exception {

		switch (atributo.toLowerCase()) {

		case "nome":
			if (novoValor.isEmpty())
				throw new AtualizaIncorretoException("Nome do funcionario nao pode ser vazio.");

			funcionarioAtual.setNome(novoValor);
			break;

		case "data":

			verificaData(novoValor);
			DateTimeFormatter formatador = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate data = LocalDate.parse(novoValor, formatador);
			this.funcionarioAtual.setDatanascimento(data);
		}
	}

	public void atualizaInfoFuncionario(String matricula, String atributo, String novoValor) throws Exception {

		Funcionario funcionario = funcionarios.get(matricula);

		switch (atributo.toUpperCase()) {

		case "NOME":

			if (novoValor.isEmpty())
				throw new AtualizaIncorretoException("Nome do funcionario nao pode ser vazio.");

			funcionario.setNome(novoValor);
			break;

		case "DATA":
			verificaData(novoValor);
			DateTimeFormatter formatador = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate data = LocalDate.parse(novoValor, formatador);
			funcionario.setDatanascimento(data);
		}
	}

	private void verificaData(String dataNascimento) throws Exception {
		try {

			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			@SuppressWarnings("unused")
			LocalDate data = LocalDate.parse(dataNascimento, formatter);

		} catch (Exception e) {
			throw new AtualizaIncorretoException("Data invalida.");
		}

	}

	public String cadastraPaciente(String nome, String dataNacimento, double peso, String sexo, String genero,
			String tipoSanguineo) throws Exception {
		if (!(this.funcionarioAtual.verificaFuncao(Funcoes.CADASTRAPACIENTE))) {
			throw new CadastraPacienteIncorretoException(this.funcionarioAtual.getNome());
		}
		return this.prontuario.criarPaciente(nome, dataNacimento, peso, sexo, genero, tipoSanguineo);

	}

	public String getInfoPaciente(String nome, String atributo) throws Exception {
		return this.prontuario.getInfoPaciente(nome, atributo);

	}

	public String getProntuario(int posicao) throws Exception {
		return this.prontuario.getProntuario(posicao);
	}

	public String cadastraMedicamento(String nome, String tipo, double preco, int quantidade, String categorias)
			throws Exception {
		if (!(this.funcionarioAtual.verificaFuncao(Funcoes.CADASTRARMEDICAMENTOS))) {
			throw new CadastraMedicamentoIncorretoException(this.funcionarioAtual.getNome());
		}
		return this.farmacia.criaMedicamento(nome, tipo, preco, quantidade, categorias);
	}

	public String getInfoMedicamento(String atributo, String medica) throws Exception {
		return this.farmacia.getInfoMedicamento(atributo, medica);
	}

	public void atualizaMedicamento(String nome, String atributo, String novovalor) throws Exception {
		this.farmacia.atualizaMedicamento(nome, atributo, novovalor);
	}

	public String buscaPorCategoria(String categoria) throws Exception {
		ArrayList<Medicamento> nova = this.farmacia.buscaPorCategoria(categoria);
		String saida = "";

		for (Medicamento novo : nova) {
			saida += novo.getNome();
		}

		return saida.substring(0, saida.length() - 2);

	}

	public String getEstoqueFarmacia(String ordenacao) throws Exception {
		String saida = "";
		if (ordenacao.equalsIgnoreCase("preco")) {
			ArrayList<Medicamento> novo = this.farmacia.verificaRemediosPorPreco();
			for (Medicamento nova : novo) {
				saida += nova.getNome() + ",";
			}
			return saida.substring(0, saida.length() - 1);
		}

		if (ordenacao.equalsIgnoreCase("alfabetica")) {
			ArrayList<Medicamento> novo = this.farmacia.ordenaPorNome();
			for (Medicamento nova : novo) {
				saida += nova.getNome() + ",";
			}

			return saida.substring(0, saida.length() - 1);
		}

		throw new ConsultaMedicamentoIncorretoException();

	}

	public String consultaMedNome(String nome) throws Exception {
		return this.farmacia.buscaPorNome(nome);
	}

	public String consultaMedCategoria(String categoria) throws Exception {
		ArrayList<Medicamento> novo = this.farmacia.buscaPorCategoria(categoria);
		String saida = "";

		for (Medicamento nova : novo) {
			saida += nova.getNome() + ",";
		}
		return saida.substring(0, saida.length() - 1);
	}

}
