package funcionario;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.LinkedList;

import exceptions.CargoInexistenteException;

/**
 * Classe que tem a funcao de criar um funcionario;
 */
public class FuncionarioFactory {
	int numeroFuncionarios = 1;
	private int numeroDiretor = 0;
	private LinkedList<Funcoes> funcoes;

	public FuncionarioFactory() {
		funcoes = new LinkedList<Funcoes>();
	}

	public Funcionario cadastraFuncionario(String nome, String cargo, String dataNascimento) throws Exception {
		if (nome.equalsIgnoreCase("")){
			throw new Exception("Erro no cadastro de funcionario. Nome do funcionario nao pode ser vazio.");
		}
		if(cargo.equalsIgnoreCase("")){
			throw new Exception("Erro no cadastro de funcionario. Nome do cargo nao pode ser vazio.");
		}
		
		switch (cargo.toLowerCase()) {
		case "diretor geral":
			return criaDiretor(nome, cargo, dataNascimento);
		case "medico":
			return criaMedico(nome, cargo, dataNascimento);
		case "tecnico":
			return criaTecnico(nome, cargo, dataNascimento);
		case "tecnico administrativo":
			return criaTecnico(nome, cargo, dataNascimento);
		default:
			throw new CargoInexistenteException();

		}

	}

	public Funcionario criaDiretor(String nome, String cargo, String dataNascimento) throws Exception {

		if (numeroDiretor == 1) {
			throw new Exception("Erro no cadastro de funcionario. Nao eh possivel criar mais de um Diretor Geral.");
		}
		funcoes = new LinkedList<Funcoes>();
		DateTimeFormatter formatador = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate data = LocalDate.parse(dataNascimento, formatador);
		String matricula = geraMatricula(cargo);
		String senha = (data.getYear() + matricula.substring(0, 4));
		funcoes.add(Funcoes.EXCLUIFUNCIONARIO);
		funcoes.add(Funcoes.CADASTRAR);
		funcoes.add(Funcoes.ALTERAR);
		Funcionario diretor = new DiretorGeral(nome, data, cargo, matricula, senha, funcoes);
		numeroDiretor += 1;
		
		return diretor;
	}

	public Funcionario criaMedico(String nome, String cargo, String dataNascimento) throws Exception {
		funcoes = new LinkedList<Funcoes>();
		DateTimeFormatter formatador = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate data = LocalDate.parse(dataNascimento, formatador);
		String matricula = geraMatricula(cargo);
		String senha = (data.getYear() + matricula.substring(0, 4));
		funcoes.add(Funcoes.ALTERAR);
		funcoes.add(Funcoes.CADASTRARORGAOS);
		funcoes.add(Funcoes.REALIZARPROCEDIMENTOS);
		
		Funcionario medico = new Medico(nome, data, cargo, matricula, senha, funcoes);
		return medico;
	}

	public Funcionario criaTecnico(String nome, String cargo, String dataNascimento) throws Exception {
		funcoes = new LinkedList<Funcoes>();
		DateTimeFormatter formatador = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate data = LocalDate.parse(dataNascimento, formatador);
		String matricula = geraMatricula(cargo);
		String senha = (data.getYear() + matricula.substring(0, 4));
		funcoes.add(Funcoes.ALTERAR);
		funcoes.add(Funcoes.CADASTRAPACIENTE);
		funcoes.add(Funcoes.CADASTRARMEDICAMENTOS);
		
		Funcionario tecnico = new TecnicoAdministrativo(nome, data, cargo, matricula, senha, funcoes);
		return tecnico;
	}

	public String geraMatricula(String cargo) {
		String matricula = "";
		if (cargo.equalsIgnoreCase("Diretor Geral")) {
			matricula += "1";
			matricula += LocalDate.now().getYear();
			matricula += String.format("%03d", numeroFuncionarios);
			numeroFuncionarios += 1;
			
		}

		else if (cargo.equalsIgnoreCase("Medico")) {
			matricula += "2";
			matricula += LocalDate.now().getYear();
			matricula += String.format("%03d", numeroFuncionarios);
			numeroFuncionarios += 1;
		}

		else if (cargo.equalsIgnoreCase("Tecnico Administrativo")) {
			matricula += "3";
			matricula += LocalDate.now().getYear();
			matricula += String.format("%03d", numeroFuncionarios);
			numeroFuncionarios += 1;
		}
		
		return matricula;
		
	}

}
