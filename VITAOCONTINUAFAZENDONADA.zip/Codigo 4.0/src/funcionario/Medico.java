package funcionario;

import java.time.LocalDate;
import java.util.LinkedList;

/**
 * Classe "Medico";
 * A classe servira apenas para identificar quando um funcionario sera medico.
 */
public class Medico extends Funcionario{

	public Medico(String nome, LocalDate dataNascimento, String cargo, String matricula, String senha, LinkedList<Funcoes> funcoes) throws Exception {
		super(nome, dataNascimento, cargo, matricula, senha, funcoes);
	}

}
