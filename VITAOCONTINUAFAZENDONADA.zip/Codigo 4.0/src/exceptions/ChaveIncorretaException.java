package exceptions;

public class ChaveIncorretaException  extends Exception{
	/**
	 * Classe Excecao que e lancada caso o usuario nao consiga acessar o sistema pois a chave digitada foi invalida;
	 * @param mensagem Mensagem lancada para o usuario;
	 */
	public ChaveIncorretaException(String mensagem){
		super ("Erro ao liberar o sistema. " + mensagem);
	}

	public ChaveIncorretaException(){
		super("Erro ao liberar o sistema. Chave invalida.");
	}

}
