package exceptions;

public class DiretorJaExisteException extends Exception{
	public DiretorJaExisteException(String mensagem){
		super("Erro no cadastro de funcionario." + mensagem);
	}
	
	public DiretorJaExisteException(){
		super("Erro no cadastro de funcionario. Nao eh possivel criar mais de um Diretor Geral.");
	}

}
