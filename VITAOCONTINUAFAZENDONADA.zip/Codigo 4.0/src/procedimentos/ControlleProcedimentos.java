package procedimentos;

import bancodeorgaos.BancoDeOrgaos;

import pacientes.Paciente;
import pacientes.Prontuario;
/**
 * Classe que tem por objetivo administrar os procedimentos a serem realizados.
 */
public class ControlleProcedimentos {

	private Paciente novopaciente;

	private BancoDeOrgaos novobanco = new BancoDeOrgaos();
	
	/**
	 * Metodo que realiza o procedimento.
	 * @param prontuario Prontuario.
	 * @param procedimento Procedimento.
	 * @param valor Valor do procedimento.
	 * @throws Exception
	 */
	public void procedimentos(Prontuario prontuario, String procedimento, Double valor) throws Exception {

		this.novopaciente = prontuario.getPaciente();
		Double novovalor = this.novopaciente.getValorprocedimentos() + valor;
		this.novopaciente.setValorprocedimentos(novovalor);
		procedimento(procedimento, prontuario);
	}

	/**
	 * Metodo que realiza procediemento.
	 * @param procedimento Procedimento.
	 * @param novo Um novo prontuario.
	 * @return Retorna Verdade caso os procedimentos tenham sido realizados.
	 * @throws Exception
	 */
	private boolean procedimento(String procedimento, Prontuario novo) throws Exception {

		switch (procedimento) {
		case "Consulta clinica":
			ConsultaClinica nova = new ConsultaClinica();
			nova.realizaCirurgia(novo);
			return true;

		case "Cirurgia bariatrica":
			CirurgiaBariatrica cirurgiabariatrica = new CirurgiaBariatrica();
			cirurgiabariatrica.realizaCirurgia(novo);
			return true;
		case "Redesignacao sexual":
			RedesiguinacaoSexual operacaosexual = new RedesiguinacaoSexual();
			operacaosexual.realizaCirurgia(novo);
			return true;
		default:
			throw new Exception(" Procedimento invalido.");
		}
	}
	
	/**
	 * Metodo que realiza o transplante de orgaos.
	 * @param prontuario
	 * @param valor
	 * @throws Exception
	 */
	public void trasnplantedeOrgaos(Prontuario prontuario, Double valor) throws Exception {
		Paciente novo = prontuario.getPaciente();
		novo.setValorprocedimentos(novo.getValorprocedimentos() + valor);

		TransplantedeOrgao transplante = new TransplantedeOrgao();
		transplante.realizaCirurgia(prontuario);

	}

}
