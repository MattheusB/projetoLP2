package farmacia;


import java.util.LinkedList;
/**
 * Classe "Medicamento"
 * @author victor
 * 
 * A classe Medicamento será responsável por originar medicamentos com os atributos nome, preço,
 * quantidade e categorias. Cada medicamento poderá ter diversas categorias (vide o Enum Categoria)
 * e podem ser do tipo Medicamento de Rerefência e Medicamento Genérico, formados por outras duas
 * classes que herdam desta classe-mãe.
 */

public class Medicamento implements Comparable<Medicamento>{
	private String nome;
	private double preco;
	private int quantidade;
	private LinkedList<Categoria> categorias;
	private String tipo;
	
	public Medicamento (String nome, double preco, int quantidade, LinkedList<Categoria> categorias,String tipo) throws Exception{
		if(nome.equalsIgnoreCase("") || nome == null){
			throw new Exception("Erro no cadastro de medicamento. Nome do medicamento nao pode ser vazio.");
			
		}
		
		if(preco < 0){
			throw new Exception("Erro no cadastro de medicamento.Preco do medicamento nao pode ser negativo.");
		}
		
		if(quantidade < 0){
			throw new Exception("Erro no cadastro de medicamento. Quantidade do medicamento nao pode ser negativo.");
		}
		this.setNome(nome);
		this.setPreco(preco);
		this.setQuantidade(quantidade);
		this.categorias = categorias;
		this.setTipo(tipo);
	}
	
	public boolean verificaCategoria(Categoria categoria){
		return this.categorias.contains(categoria);
		
	}
	
	public String categoria(){
		String saida = "";
		
		if(verificaCategoria(Categoria.ANALGESICO)){
			saida+= "analgesico,";
		}
		
		if(verificaCategoria(Categoria.ANTIBIOTICO)){
			saida += "antibiotico,";
		}
		
		if(verificaCategoria(Categoria.ANTIEMETICO)){
			saida += "antiemetico,";
		}
		
		if(verificaCategoria(Categoria.ANTIINFLAMATORIO)){
			saida += "antiinflamatorio,";
		}
		
		if(verificaCategoria(Categoria.ANTITERMICO)){
			saida += "antitermico,";
		}
		
		if(verificaCategoria(Categoria.HORMONAL)){
			saida += "hormonal,";
		}
		saida.substring(0, saida.length() - 2);
		
		return saida;
	}
	
	public void alterPreco(double preco){
		this.setPreco(preco);
	}
	
	public void addCategoria(Categoria categoria){
		this.categorias.add(categoria);
	}
	
	public String toString(){
		return "Nome: " + this.nome + "\nPreco: "+  this.preco + "\nQuantidade: " + this.quantidade;
	}
	
	

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public double getPreco() {
		return preco;
	}

	public void setPreco(double preco) {
		this.preco = preco;
	}

	public int getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}
	
	public int comparaNome(Medicamento novo){
		return this.nome.compareTo(novo.getNome());
	}

	@Override
	public int compareTo(Medicamento novo) {
		if(this.preco > novo.getPreco()){
			return 1;
		}
		if(this.preco < novo.getPreco()){
			return -1;
		}
		return 0;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	

	
}
