package farmacia;
	
/**
 * Enum "Categoria"
 * 
 * Existem seis categorias de medicamento organizadas pelo Enum: Analgesico, Antibiotico, Antiemetico,
 * Anti-inflamatorio, Antitermico e Hormonal.
 */

public enum Categoria {
	ANALGESICO, ANTIBIOTICO, ANTIEMETICO,
	ANTIINFLAMATORIO, ANTITERMICO, HORMONAL;
}