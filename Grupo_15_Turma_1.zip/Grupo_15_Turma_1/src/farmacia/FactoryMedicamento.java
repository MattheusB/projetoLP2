package farmacia;

import java.util.LinkedList;
/**
 * Classe que tem a funcao de criar um medicamento;
 */
public class FactoryMedicamento {
	
	public FactoryMedicamento(){
		
	}
	
	/**
	 * Metodo que tem a funcao de criar um medicamento;
	 * @param tipo Tipo do medicamento;
	 * @param nome Nome do medicamento;
	 * @param preco Preco do medicamento;
	 * @param quantidade Quantidade do Medicamento;
	 * @param categorias Categoria do Medicamento;
	 * @return Retorna nada;
	 */
	public Medicamento criaMedicamento(String nome,String tipo, double preco, int quantidade, LinkedList<Categoria> categorias)throws Exception{
		if(tipo.equalsIgnoreCase("Generico")){
			String tipos = "Generico";
			Medicamento medicamento = new MedicamentoGenerico(nome,preco,quantidade,categorias,tipos);
			
			return medicamento;
		}
		
		if(tipo.equalsIgnoreCase("Referencia")){
			String tipos = "de Referencia";
			Medicamento medicamento = new MedicamentoDeReferencia(nome,preco,quantidade,categorias,tipos);
			
			return medicamento;
		}
		
		return null;
	}

}
