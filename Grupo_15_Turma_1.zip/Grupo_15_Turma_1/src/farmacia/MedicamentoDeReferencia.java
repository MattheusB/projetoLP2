package farmacia;

import java.util.LinkedList;

/**
 * Classe "MedicamentoDeRerefencia"
 * 
 * A classe Medicamento de Refer�ncia servir� apenas para saber quando um
 * medicamento ser� de refer�ncia ou gen�rico atrav�s de sua inst�ncia. Caso o
 * medicamento seja de refer�ncia, ele receber� o pre�o integral (100%).
 */

public class MedicamentoDeReferencia extends Medicamento {
	private static final long serialVersionUID = 461181061431956100L;

	public MedicamentoDeReferencia(String nome, double preco, int quantidade, LinkedList<Categoria> categorias,
			String tipo) throws Exception {
		super(nome, preco, quantidade, categorias, tipo);
	}

	String resultado = String.format("%.2f", this.getPreco());

	@Override
	public String toString() {
		return "Medicamento de Referencia: " + this.getNome() + " - Preco: R$ " + resultado + " - Disponivel: "
				+ this.getQuantidade() + " - Categorias: " + categoria();
	}

}