package bancodeorgaos;

import java.io.Serializable;

/**
 * Classe que tem por Objetivo principal criar um orgao.
 */
public class Orgao implements Serializable {
	private static final long serialVersionUID = 7601877500927551334L;
	private String nome;
	private String tipoSanguineo;

	/**
	 * Metodo que cria um orgao.
	 * 
	 * @param nome
	 *            Nome do orgao.
	 * @param tipoSanguineo
	 *            Tipo sanguineo do orgao.
	 * @throws Exception
	 */
	public Orgao(String nome, String tipoSanguineo) throws Exception {
		if (nome.trim().isEmpty()) {
			throw new Exception(" Nome do orgao nao pode ser vazio.");
		}
		this.setNome(nome);
		this.setTipoSanguineo(tipoSanguineo);
	}

	public String toString() {
		return "Nome: " + this.nome + "Tipo Sanguineo: " + this.getTipoSanguineo();
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getTipoSanguineo() {
		return tipoSanguineo;
	}

	public void setTipoSanguineo(String tipoSanguineo) {
		this.tipoSanguineo = tipoSanguineo;
	}

}
