package cartaofidelidade;

/**
 * Classe que nao da desconto ao paciente pq ele � recem criado.
 */

public class CartaoPadrao implements CartaoFidelidade {
	private static final long serialVersionUID = -3796722752689970573L;

	@Override
	public double descontoservico(double valor) {

		return valor;
	}

	@Override
	public int creditobonus(int pontos) {

		return pontos;
	}

}
