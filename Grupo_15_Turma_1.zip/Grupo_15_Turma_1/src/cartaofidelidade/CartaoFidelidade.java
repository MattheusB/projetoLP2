package cartaofidelidade;

/**
 * Interface de cartao fidelidade.
 */
public interface CartaoFidelidade {
	
	double descontoservico(double valor);
	int creditobonus(int pontos);

}
