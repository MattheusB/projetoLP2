package cartaofidelidade;

import java.io.Serializable;

/**
 * Interface de cartao fidelidade.
 */
public interface CartaoFidelidade extends Serializable {

	double descontoservico(double valor);

	int creditobonus(int pontos);

}
