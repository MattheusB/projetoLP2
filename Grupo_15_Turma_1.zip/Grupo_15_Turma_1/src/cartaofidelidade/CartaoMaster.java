package cartaofidelidade;

/**
 * Classe que da desconto no servico e da credito bonus caso o paciente seja master.
 */
public class CartaoMaster implements CartaoFidelidade{

	@Override
	public double descontoservico(double valor) {
		
		Double novovalor = valor;
		novovalor -= (valor * 0.15);
		return novovalor;
		
	}

	@Override
	public int creditobonus(int pontos) {
		int novoponto = pontos;
		novoponto += pontos * 0.05;
		return (int) novoponto;
		
	}

}
