package controller;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import bancodeorgaos.BancoDeOrgaos;
import exceptions.AtualizaIncorretoException;
import exceptions.CadastraMedicamentoIncorretoException;
import exceptions.CadastraPacienteIncorretoException;
import exceptions.ConsultaMedicamentoIncorretoException;
import exceptions.FechaSistemaException;
import exceptions.LogoutIncorretoException;
import exceptions.SenhaIncorretaException;
import exceptions.TamanhoNomeIncorretoException;
import farmacia.Farmacia;
import farmacia.Medicamento;
import funcionario.Funcionario;
import funcionario.FuncionarioFactory;
import funcionario.Funcoes;
import pacientes.ControlleProntuario;
import pacientes.Paciente;
import pacientes.Prontuario;
import procedimentos.ControlleProcedimentos;

/**
 * Classe controller que tem a funcao de administrar todo o codigo por tras da
 * facade;
 */
public class Controller implements Serializable{
	private static final long serialVersionUID = -2713806438487512915L;
	
	FuncionarioFactory factory = new FuncionarioFactory();
	HashMap<String, Funcionario> funcionarios = new HashMap<String, Funcionario>();
	boolean liberacao = false;
	private Funcionario funcionarioAtual = null;
	private ControlleProntuario prontuario = new ControlleProntuario();
	private Farmacia farmacia = new Farmacia();
	private BancoDeOrgaos banco = new BancoDeOrgaos();
	private ControlleProcedimentos procedimento = new ControlleProcedimentos();

	/**
	 * Metodo que tem a funcao de liberar o sistema para os usuarios. Primeiro
	 * acesso feito apenas pelo diretor;
	 * 
	 * @param chave
	 *            Chave que abre o sistema;
	 * @param nome
	 *            Nome do Usuario;
	 * @param dataNascimento
	 *            Data de Nascimento do Usuario;
	 * @return Retorna a matricula do usuario;
	 * @throws Exception
	 *             Se a chave estiver incorreta ir� lancar um exception;
	 */
	public String liberaSistema(String chave, String nome, String dataNascimento) throws Exception {
		if (liberacao) {
			throw new Exception(" Sistema liberado anteriormente.");
		}
		if (!(chave.equalsIgnoreCase("c041ebf8"))) {
			throw new Exception(" Chave invalida.");
		} else {
			liberacao = true;
			Funcionario diretor = factory.cadastraFuncionario(nome, "Diretor Geral", dataNascimento);
			funcionarios.put(diretor.getMatricula(), diretor);
			return diretor.getMatricula();
		}

	}

	/**
	 * Metodo que realiza login dos usuarios;
	 * 
	 * @param matricula
	 *            Recebe a matricula dos usuario;
	 * @return Retorna boolean;
	 */
	public String login(String matricula, String senha) throws Exception {
		if (funcionarioAtual != null) {
			throw new Exception("Um funcionario ainda esta logado: " + funcionarioAtual.getNome() + ".");
		}

		if (senha.length() < 8 || senha.length() > 12) {
			throw new Exception("Senha incorreta.");
		}

		Funcionario funcionario = funcionarios.get(matricula);

		if ((funcionario == null)) {
			throw new Exception("Funcionario nao cadastrado.");
		}
		if (funcionario.getSenha().equalsIgnoreCase(senha)) {
			funcionarioAtual = funcionario;
			return funcionario.getMatricula();
		}

		throw new Exception("Senha incorreta.");

	}

	/**
	 * Metodo que tem a funcao de cadastrar um funcionario a partir do cargo por
	 * ele exercido;
	 * 
	 * @param nome
	 *            Nome do funcionario;
	 * @param cargo
	 *            Cargo que o usuario exerce;
	 * @param dataNascimento
	 *            Data de nascimento do usuario;
	 * @return Retorna adicionando um funcionario a lista de funcionarios;
	 */
	public String cadastraFuncionario(String nome, String cargo, String dataNascimento) throws Exception {
		if (!(funcionarioAtual.verificaFuncao(Funcoes.CADASTRAR))) {
			throw new Exception(
					"O funcionario " + funcionarioAtual.getNome() + " nao tem permissao para cadastrar funcionarios.");

		}
		String[] data = dataNascimento.split("/");
		if (Integer.parseInt(data[0]) > 31 || Integer.parseInt(data[1]) > 12) {
			throw new Exception("Data invalida.");
		}
		Funcionario funcionario = factory.cadastraFuncionario(nome, cargo, dataNascimento);
		funcionarios.put(funcionario.getMatricula(), funcionario);
		return funcionario.getMatricula();
	}

	/**
	 * Metodo que tem a funcao de gerar a matricula automaticamente de um
	 * usuario;
	 * 
	 * @param cargo
	 *            Cargo excercido pelo usuario;
	 * @return Retorna a matricula gerada;
	 */
	public String getInfoFuncionario(String matricula, String atributo) throws Exception {
		String string = "";
		if (matricula.length() < 7) {
			throw new Exception("A matricula nao segue o padrao.");
		}

		if (atributo.equalsIgnoreCase("senha"))
			throw new Exception("A senha do funcionario eh protegida.");

		Funcionario funcionario = funcionarios.get(matricula);
		if (funcionario == null) {
			throw new Exception("Funcionario nao cadastrado.");
		}

		if (atributo.equalsIgnoreCase("Nome")) {
			string += funcionario.getNome();
		}
		if (atributo.equalsIgnoreCase("Cargo")) {
			string += funcionario.getCargo();
		}
		if (atributo.equalsIgnoreCase("Data")) {
			string += funcionario.getDatanascimento();
		}

		return string;

	}

	/**
	 * Metodo que altera a senha do usuario, verificando primeiramente se a
	 * senha � igual a anterior e caso seja libera o sistema para alterar a
	 * senha;
	 * 
	 * @param senha
	 *            Antiga senha do usuario;
	 * @param matricula
	 *            Matricula do usuario;
	 * @param novaSenha
	 *            Nova senha digitada pelo usuario;
	 * @throws Exception
	 *             Lanca excecao por causa do metodo verificaFuncionario;
	 */
	public boolean atualizaSenha(String senha, String novaSenha) throws Exception {
		if (funcionarioAtual.getSenha().equalsIgnoreCase(senha)) {

			if (novaSenha.length() < 8 || novaSenha.length() > 12) {
				throw new Exception("A nova senha deve ter entre 8 - 12 caracteres alfanumericos.");
			}

			funcionarioAtual.setSenha(novaSenha);
			return true;

		}

		throw new Exception("Senha invalida.");
	}

	/**
	 * Metodo que permite que o usuario altere o seu nome;
	 * 
	 * @param novoNome
	 *            Novo nome do usuario;
	 * @param matricula
	 *            Matricula do usuario;
	 */
	public void alteraNome(String novoNome, String matricula) throws Exception {
		Funcionario funcionario = funcionarios.get(matricula);
		funcionario.setNome(novoNome);
	}

	/**
	 * Metodo que altera a data de nascimento do usuario;
	 * 
	 * @param data
	 *            Data de nascimento;
	 * @param matricula
	 *            Matricula do usuario;
	 */
	public void alteraData(String data, String matricula) throws Exception {
		Funcionario funcionario = funcionarios.get(matricula);
		DateTimeFormatter formatador = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate date = LocalDate.parse(data, formatador);
		funcionario.setDatanascimento(date);
	}

	/**
	 * Metodo que exclui funcionarios, apenas o diretor pode excluir um
	 * funcionario, por isso precisa conferir se a senha digitada e a mesma
	 * colocada pelo diretor anteriormente;
	 * 
	 * @param matricula
	 *            Matricula do usuario;
	 * @param senhaDiretor
	 *            Senha do diretor;
	 */
	public boolean excluiFuncionario(String matricula, String senhaDiretor) throws Exception {

		if (!(this.funcionarioAtual.verificaFuncao(Funcoes.EXCLUIFUNCIONARIO))) {
			throw new Exception("O funcionario " + this.funcionarioAtual.getNome()
					+ " nao tem permissao para excluir funcionarios.");
		}
		if (!(matricula.matches("^[0-9]*$"))) {
			throw new Exception("A matricula nao segue o padrao.");
		}
		Funcionario funcionario = funcionarios.get(matricula);

		if (funcionario == null) {
			throw new Exception("Funcionario nao cadastrado.");
		}
		if (this.funcionarioAtual.getSenha().equalsIgnoreCase(senhaDiretor)) {
			funcionarios.remove(funcionario.getMatricula());
			return true;
		}

		throw new Exception("Senha invalida.");
	}

	/**
	 * Metodo que verifica se a nova senha colocada pelo usuario e valida;
	 * 
	 * @param senha
	 *            Nova senha que sera utilizada;
	 * @return Retorna um boolean
	 * @throws Exception
	 *             Lanca excecao caso a senha seja menor que 8 caracteres e
	 *             maior que 12;
	 */
	public boolean verificaSenha(String senha) throws Exception {
		if (senha.length() < 8 || senha.length() > 12) {
			throw new SenhaIncorretaException();
		}
		return true;
	}

	/**
	 * Metodo que verifica se o novo nome escolhido pelo usuario e valido;
	 * 
	 * @param nome
	 *            Nome do usuario;
	 * @return Retorna um boolean;
	 * @throws Exception
	 *             Lanca excecao caso o nome tenha mais de 12 caracteres;
	 */
	public boolean verificaNome(String nome) throws Exception {
		if (nome.length() > 16) {
			throw new TamanhoNomeIncorretoException();
		}
		return true;
	}

	/**
	 * Metodo que fecha o sistema caso todos os funcionarios ja tenham realizado
	 * o logout;
	 * 
	 * @throws Exception
	 *             Lanca excecao caso ainda exista um funcionario logado;
	 */
	public void fechaSistema() throws Exception {
		if (funcionarioAtual != null) {
			throw new FechaSistemaException(funcionarioAtual.getNome());
		}
	}

	/**
	 * Metodo que realiza logout no funcionario;
	 * 
	 * @throws Exception
	 *             Lanca excecao caso nao seja possivel realizar o logout;
	 */
	public void logout() throws Exception {
		if (funcionarioAtual != null) {
			funcionarioAtual = null;
		}

		else {
			throw new LogoutIncorretoException();
		}
	}

	/**
	 * Metodo que atualiza informacoes do funcionario;
	 * 
	 * @param atributo
	 *            Atributo que sera modificado; novoValor Atualizacao da
	 *            informacao antiga;
	 * @throws Exception
	 *             Lanca excecao caso o nome do funcionario seja vazio;
	 */
	public void atualizaInfoFuncionario(String atributo, String novoValor) throws Exception {

		switch (atributo.toLowerCase()) {

		case "nome":
			if (novoValor.isEmpty())
				throw new Exception("Erro ao atualizar funcionario. Nome do funcionario nao pode ser vazio.");

			funcionarioAtual.setNome(novoValor);
			break;

		case "data":

			verificaData(novoValor);
			DateTimeFormatter formatador = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate data = LocalDate.parse(novoValor, formatador);
			this.funcionarioAtual.setDatanascimento(data);
		}
	}

	/**
	 * Metodo que atualiza informacoes do funcionario;
	 * 
	 * @param matricula
	 *            Matricula necessaria para encontrar o funcionario; atributo
	 *            Atributo que sera modificado; novoValor Atualizacao da
	 *            informacao antiga;
	 * @throws Exception
	 *             Lanca excecao caso o nome do funcionario seja vazio;
	 */
	public void atualizaInfoFuncionario(String matricula, String atributo, String novoValor) throws Exception {

		Funcionario funcionario = funcionarios.get(matricula);

		switch (atributo.toUpperCase()) {

		case "NOME":

			if (novoValor.isEmpty())
				throw new AtualizaIncorretoException("Nome do funcionario nao pode ser vazio.");

			funcionario.setNome(novoValor);
			break;

		case "DATA":
			verificaData(novoValor);
			DateTimeFormatter formatador = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate data = LocalDate.parse(novoValor, formatador);
			funcionario.setDatanascimento(data);
		}
	}

	/**
	 * Metodo que verifica a data de nascimento;
	 * 
	 * @param dataNascimento
	 *            Data de nascimento no formato de String;
	 * @throws Exception
	 *             Lanca excecao caso a data seja invalida;
	 */
	private void verificaData(String dataNascimento) throws Exception {
		try {
			// parse nao aceita datas de dia e mes invalidas
			// relancando entao, propria exception
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			@SuppressWarnings("unused")
			LocalDate data = LocalDate.parse(dataNascimento, formatter);

		} catch (Exception e) {
			throw new AtualizaIncorretoException("Data invalida.");
		}

	}

	/**
	 * Metodo que cadastra pacientes no sistema;
	 * 
	 * @param nome
	 *            Nome do paciente; dataNascimento Data de nascimento do
	 *            paciente; peso Massa do paciente dada em quilogramas; sexo
	 *            Sexo biol�gico do paciente (Masculino/Feminino); genero Genero
	 *            do paciente; tipoSanguineo Tipo de sangue do paciente
	 *            (A+,A-,B+,B-,O+,O-,AB+ ou AB-);
	 * 
	 * @return Retorna uma string;
	 * 
	 * @throws Exception
	 *             Lanca excecao caso ocorra erro ao cadastrar o paciente;
	 */
	public String cadastraPaciente(String nome, String dataNacimento, double peso, String sexo, String genero,
			String tipoSanguineo) throws Exception {
		if (!(this.funcionarioAtual.verificaFuncao(Funcoes.CADASTRAPACIENTE))) {
			throw new CadastraPacienteIncorretoException(this.funcionarioAtual.getNome());
		}
		return this.prontuario.criarPaciente(nome, dataNacimento, peso, sexo, genero, tipoSanguineo);

	}

	/**
	 * Metodo que busca informacoes do paciente que estao em prontuario.
	 * 
	 * @param nome
	 *            Nome do paciente.
	 * @param atributo
	 *            Atributo do paciente.
	 * @return Retorna o nome do paciente.
	 * @throws Exception
	 */
	public String getInfoPaciente(String nome, String atributo) throws Exception {
		return this.prontuario.getInfoPaciente(nome, atributo);

	}

	/**
	 * Metodo que busca prontuario na classe prontuario.
	 * 
	 * @param posicao
	 *            Recebe um inteiro posicao.
	 * @return Retorna uma posicao de prontuario.
	 * @throws Exception
	 */
	public String getProntuario(int posicao) throws Exception {
		return this.prontuario.getProntuario(posicao);
	}

	/**
	 * Metodo que cadastra medicamentos.
	 * 
	 * @param nome
	 *            Nome do remedio.
	 * @param tipo
	 *            Tipo do remedio.
	 * @param preco
	 *            Preco do remedio.
	 * @param quantidade
	 *            Quantidade do remedio.
	 * @param categorias
	 *            Categorias.
	 * @return Retorna um medicamento.
	 * @throws Exception
	 */
	public String cadastraMedicamento(String nome, String tipo, double preco, int quantidade, String categorias)
			throws Exception {
		if (!(this.funcionarioAtual.verificaFuncao(Funcoes.CADASTRARMEDICAMENTOS))) {
			throw new CadastraMedicamentoIncorretoException(this.funcionarioAtual.getNome());
		}
		return this.farmacia.criaMedicamento(nome, tipo, preco, quantidade, categorias);
	}

	/**
	 * Metodo que busca informacoes do medicamento.
	 * 
	 * @param atributo
	 *            Atributo
	 * @param medica
	 *            Nome do medicamento.
	 * @return Retorna as informacoes.
	 * @throws Exception
	 */
	public String getInfoMedicamento(String atributo, String medica) throws Exception {
		return this.farmacia.getInfoMedicamento(atributo, medica);
	}

	/**
	 * Metodo que atualiza medicamentos.
	 * 
	 * @param nome
	 *            Nome do medicamento.
	 * @param atributo
	 *            Atributo.
	 * @param novovalor
	 *            Novo valor do medicamento.
	 * @throws Exception
	 */
	public void atualizaMedicamento(String nome, String atributo, String novovalor) throws Exception {
		this.farmacia.atualizaMedicamento(nome, atributo, novovalor);
	}

	/**
	 * Metodo que busca medicamento por categoria.
	 * 
	 * @param categoria
	 *            Categoria do medicamento.
	 * @return Retorna o nome do medicamento.
	 * @throws Exception
	 */
	public String buscaPorCategoria(String categoria) throws Exception {
		ArrayList<Medicamento> nova = this.farmacia.buscaPorCategoria(categoria);
		String saida = "";

		for (Medicamento novo : nova) {
			saida += novo.getNome();
		}

		return saida.substring(0, saida.length() - 2);

	}

	/**
	 * Metodo que busca o estoque de farmacia.
	 * 
	 * @param ordenacao
	 *            Ordenacao
	 * @return Retorna nome de medicamentos.
	 * @throws Exception
	 */
	public String getEstoqueFarmacia(String ordenacao) throws Exception {
		String saida = "";
		if (ordenacao.equalsIgnoreCase("preco")) {
			ArrayList<Medicamento> novo = this.farmacia.verificaRemediosPorPreco();
			for (Medicamento nova : novo) {
				saida += nova.getNome() + ",";
			}
			return saida.substring(0, saida.length() - 1);
		}

		if (ordenacao.equalsIgnoreCase("alfabetica")) {
			ArrayList<Medicamento> novo = this.farmacia.ordenaPorNome();
			for (Medicamento nova : novo) {
				saida += nova.getNome() + ",";
			}

			return saida.substring(0, saida.length() - 1);
		}

		throw new ConsultaMedicamentoIncorretoException("Tipo de ordenacao invalida.");

	}

	/**
	 * Metodo que consulta medicamento por nome.
	 * 
	 * @param nome
	 *            Nome do medicamento.
	 * @return Retorna o nome do medicamento.
	 * @throws Exception
	 */
	public String consultaMedNome(String nome) throws Exception {
		return this.farmacia.buscaPorNome(nome);
	}

	/**
	 * Metodo que consulta medicamento por categoria.
	 * 
	 * @param categoria
	 *            Categoria do medicamento.
	 * @return Retorna os medicamentos dessa categoria.
	 * @throws Exception
	 */
	public String consultaMedCategoria(String categoria) throws Exception {
		ArrayList<Medicamento> novo = this.farmacia.buscaPorCategoria(categoria);
		String saida = "";

		for (Medicamento nova : novo) {
			saida += nova.getNome() + ",";
		}
		return saida.substring(0, saida.length() - 1);
	}

	/**
	 * Metodo que cadastra Orgaos.
	 * 
	 * @param nome
	 *            Nome do orgao.
	 * @param tipoSanguineo
	 *            Tipo sanguineo do Orgao.
	 * @throws Exception
	 */
	public void cadastraOrgao(String nome, String tipoSanguineo) throws Exception {

		this.banco.cadastraOrgao(nome, tipoSanguineo);
	}

	/**
	 * Metodo que busca orgao pelo tipo sanguineo.
	 * 
	 * @param tipoSanguineo
	 *            Tipo sanguineo.
	 * @return Retorna o orgao.
	 * @throws Exception
	 */
	public String buscaOrgPorSangue(String tipoSanguineo) throws Exception {
		return this.banco.buscarOrgaoTipoSanguineo(tipoSanguineo);
	}

	/**
	 * Metodo que busca orgao pelo nome.
	 * 
	 * @param nome
	 *            Nome do orgao.
	 * @return Retorna o orgao.
	 * @throws Exception
	 */
	public String buscaOrgPorNome(String nome) throws Exception {
		return this.banco.bucarOrgaoPeloNome(nome);
	}

	/**
	 * Metodo que simplesmente busca o orgao.
	 * 
	 * @param nome
	 *            Nome do orgao.
	 * @param tipoSanguineo
	 *            Tipo sanguineo do orgao.
	 * @return Retorna o orgao.
	 * @throws Exception
	 */
	public String buscaOrgao(String nome, String tipoSanguineo) throws Exception {
		return this.banco.buscarOrgaoNomeTipoSang(nome, tipoSanguineo);
	}

	/**
	 * Metodo que retira orgao.
	 * 
	 * @param nome
	 *            Nome do orgao.
	 * @param tipoSanguineo
	 *            Tipo sanguineo do orgao.
	 * @throws Exception
	 */
	public void retiraOrgao(String nome, String tipoSanguineo) throws Exception {
		this.banco.remove(nome, tipoSanguineo);
	}

	/**
	 * Metodo que busca a quantidade de orgaos.
	 * 
	 * @param nome
	 *            Nome do orgao.
	 * @return Retorna a quantidade de orgaos.
	 * @throws Exception
	 */
	public String qtdOrgaos(String nome) throws Exception {
		return this.banco.quantidadeDeOrgao(nome);
	}

	/**
	 * Meotodo que retorna o total de orgaos disponiveis.
	 * 
	 * @return Retorna a quantidade de orgaos disponiveis.
	 */
	public String totalOrgaosDisponiveis() {
		return this.banco.quantidadeTotalDeOrgaosDisponiveis();
	}

	/**
	 * Metodo que busca o ID do paciente.
	 * 
	 * @param nome
	 *            Nome do paciente.
	 * @return Retorna o ID do paciente.
	 */
	public String getIdPaciente(String nome) {
		return this.prontuario.getIdPaciente(nome);
	}

	/**
	 * Metodo que realiza o procedimento a ele designado, algum tipo de
	 * cirurgia.
	 * 
	 * @param procedimento
	 *            Procedimento.
	 * @param nome
	 *            Nome do paciente.
	 * @param medicamentos
	 *            Medicamento.
	 * @throws Exception
	 */
	public void realizaProcedimento(String procedimento, String nome, String medicamentos) throws Exception {
		verificadorProcedimentos(nome);
		this.farmacia.verificaMedicamentos(medicamentos);
		Prontuario novo = this.prontuario.verificaProntuario(nome);
		Double valor = farmacia.calculaMedicamento(medicamentos);
		String nomeMedico = this.funcionarioAtual.getNome();
		LocalDate data = LocalDate.now();
		this.procedimento.procedimentos(novo, procedimento, valor, nomeMedico, data);
	}

	/**
	 * Sobrecarga de metodo em que realiza procedimento.
	 * 
	 * @param procedimento
	 *            Procedimento.
	 * @param nome
	 *            Nome do paciente.
	 * @param orgao
	 *            Orgao.
	 * @param medicamentos
	 *            Medicamento
	 * @throws Exception
	 */
	public void realizaProcedimento(String procedimento, String nome, String orgao, String medicamentos)
			throws Exception {
		verificadorProcedimentos(nome);
		if (!(procedimento.equalsIgnoreCase("Transplante de orgaos"))) {
			throw new Exception(" Procedimento invalido.");
		}

		if (orgao.trim().isEmpty()) {
			throw new Exception(" Nome do orgao nao pode ser vazio.");
		}
		this.farmacia.verificaMedicamentos(medicamentos);

		Double valormedicamento = farmacia.calculaMedicamento(medicamentos);

		Prontuario prontuario = this.prontuario.verificaProntuario(nome);

		this.banco.buscaOrgaosCompativel(orgao, prontuario.getPaciente().getTipoSanguineo());

		String nomeMedico = this.funcionarioAtual.getNome();
		LocalDate data = LocalDate.now();

		this.procedimento.trasnplantedeOrgaos(prontuario, valormedicamento, nomeMedico, data, orgao);
	}

	/**
	 * Metodo que retorna o total de procedimentos.
	 * 
	 * @param nome
	 *            Nome do procedimento.
	 * @return Retorna o procedimento.
	 */
	public String getTotalProcedimento(String nome) {
		return this.prontuario.getTotalProcedimento(nome);
	}

	/**
	 * Metodo que retorna a quantidade gasta pelo paciente.
	 * 
	 * @param id
	 *            ID do paciente.
	 * @return Retorna a quantidade de gastos.
	 */
	public String getGastosPaciente(String id) {
		return this.prontuario.getGastosPaciente(id);
	}

	/**
	 * Metodo que busca a quantidade de pontos fidelidade o paciente possui.
	 * 
	 * @param id
	 * @return
	 */
	public String getPontosFidelidade(String id) {
		return this.prontuario.getPontosFidelidade(id);
	}

	/**
	 * Metodo que realiza procedimento.
	 * 
	 * @param procedimento
	 *            Procedimento.
	 * @param id
	 *            ID do paciente.
	 * @throws Exception
	 */
	public void realizaProcedimento(String procedimento, String id) throws Exception {
		verificadorProcedimentos(id);
		String nomeMedico = this.funcionarioAtual.getNome();
		LocalDate data = LocalDate.now();
		Prontuario prontuario = this.prontuario.verificaProntuario(id);
		this.procedimento.procedimentos(prontuario, procedimento, 0.0, nomeMedico, data);

	}

	/**
	 * Metodo que verifica os procedimentos.
	 * 
	 * @param id
	 *            ID do paciente.
	 * @throws Exception
	 */
	private void verificadorProcedimentos(String id) throws Exception {
		if (!(this.funcionarioAtual.verificaFuncao(Funcoes.REALIZARPROCEDIMENTOS))) {
			throw new Exception(" O funcionario " + this.funcionarioAtual.getNome()
					+ " nao tem permissao para realizar procedimentos.");
		}
		if (id.trim().isEmpty()) {
			throw new Exception(" ID do paciente nao pode ser vazio.");
		}
	}

	public void salvaFicha(String nomeArquivo, String fichaPaciente) throws IOException {
		BufferedWriter arquivoPaciente = new BufferedWriter(new FileWriter(nomeArquivo));
		arquivoPaciente.write(fichaPaciente);
	}

	public String exportaFichaPaciente(String idPaciente) throws IOException {
		String saida = "";
		Prontuario prontuario = this.prontuario.verificaProntuario(idPaciente);
		Paciente paciente = prontuario.getPaciente();
		saida += paciente.toString() + "\n" + prontuario.fichaPaciente();
		String nomeArquivo = "fichas_pacientes/" + paciente.getNome() + "_" + paciente.getDataDeNascimento() + ".txt";

		salvaFicha(nomeArquivo, saida);

		return saida;

	}

}
