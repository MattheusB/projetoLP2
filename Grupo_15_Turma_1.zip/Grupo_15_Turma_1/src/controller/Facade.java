package controller;

import easyaccept.EasyAccept;

public class Facade {

	public static void main(String[] args) {
		args = new String[] {"controller.Facade", "test/usecase_1.txt", "test/usecase_2.txt", "test/usecase_3.txt", "test/usecase_4.txt" }; //separe cada script de teste por virgula.
		EasyAccept.main(args);
	}
	public void iniciaSistema(){

	}
	Controller controller = new Controller();

	public String liberaSistema(String chave, String nome, String dataNascimento) throws Exception {
		return controller.liberaSistema(chave, nome, dataNascimento);
	}

	public String login(String matricula, String senha) throws Exception {
		return controller.login(matricula, senha);
	}

	public String cadastraFuncionario(String nome, String cargo, String dataNascimento) throws Exception {
		return controller.cadastraFuncionario(nome, cargo, dataNascimento);
	}
	
	public String getInfoFuncionario(String matricula, String atributo) throws Exception{
		return controller.getInfoFuncionario(matricula, atributo);
	}
	public void logout() throws Exception{
		controller.logout();
	}
	
	public void fechaSistema() throws Exception{
		controller.fechaSistema();
	}

	// Metodo altera senha que primeiramente verifica a matricula e se for igual a matricula do usuario
	// que est� usando o sistema ele ter� acesso a parte de alterar senha;
	public void atualizaSenha(String senha, String novaSenha) throws Exception{
		controller.atualizaSenha(senha, novaSenha);	
	}

	// Metodo que altera o nome;
	public void alteraNome(String novoNome, String matricula) throws Exception {
		controller.alteraNome(novoNome, matricula);
	}

	// Metodo que altera a data de nascimento;
	public void alteraData(String data, String matricula) throws Exception {
		controller.alteraData(data, matricula);
	}

	// Metodo que Exclui funcionario;
	// Como j� foi dito acima, "funcionarios" precisa de uma parte de brito;
	public void excluiFuncionario(String matricula, String senhaDiretor) throws Exception {
		controller.excluiFuncionario(matricula, senhaDiretor);
	}

	// Metodo que verifica se a nova senha que o usuario ir� criar est� v�lida;
	public boolean verificaSenha(String senha) throws Exception{
		return controller.verificaSenha(senha);
	}

	// Metodo que verifica se o novo nome que o usuario ir� criar est� v�lida;
	public boolean verificaNome(String nome)throws Exception{
		return controller.verificaNome(nome);
	}
	
	public void atualizaInfoFuncionario(String atributo, String novoValor) throws Exception {
		controller.atualizaInfoFuncionario(atributo, novoValor);
	}

}
