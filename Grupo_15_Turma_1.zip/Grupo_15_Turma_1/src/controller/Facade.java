package controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import easyaccept.EasyAccept;

public class Facade {

	public static void main(String[] args) {
		args = new String[] { "controller.Facade", "test/usecase_1.txt", "test/usecase_2.txt", "test/usecase_3.txt",
				"test/usecase_4.txt", "test/usecase_5.txt", "test/usecase_6.txt", "test/usecase_7.txt" };// separe
		EasyAccept.main(args);
	}

	Controller controller = new Controller();
	
	/**
	 * Metodo que tem a funcao de liberar o sistema para os usuarios. Primeiro
	 * acesso feito apenas pelo diretor;
	 * 
	 * @param chave
	 *            Chave que abre o sistema;
	 * @param nome
	 *            Nome do Usuario;
	 * @param dataNascimento
	 *            Data de Nascimento do Usuario;
	 * @return Retorna a matricula do usuario;
	 * @throws Exception
	 *             Se a chave estiver incorreta ir� lancar um exception;
	 */
	public String liberaSistema(String chave, String nome, String dataNascimento) throws Exception {
		try {
			return controller.liberaSistema(chave, nome, dataNascimento);
		} catch (Exception e) {
			throw new Exception("Erro ao liberar o sistema." + e.getMessage());
		}
	}
	
	/**
	 * Metodo que realiza login dos usuarios;
	 * 
	 * @param matricula
	 *            Recebe a matricula dos usuario;
	 * @return Retorna boolean;
	 */
	public String login(String matricula, String senha) throws Exception {
		try {
			return controller.login(matricula, senha);
		} catch (Exception e) {
			throw new Exception("Nao foi possivel realizar o login. " + e.getMessage());
		}
	}
	
	/**
	 * Metodo que tem a funcao de cadastrar um funcionario a partir do cargo por
	 * ele exercido;
	 * 
	 * @param nome
	 *            Nome do funcionario;
	 * @param cargo
	 *            Cargo que o usuario exerce;
	 * @param dataNascimento
	 *            Data de nascimento do usuario;
	 * @return Retorna adicionando um funcionario a lista de funcionarios;
	 */
	public String cadastraFuncionario(String nome, String cargo, String dataNascimento) throws Exception {
		try {
			return controller.cadastraFuncionario(nome, cargo, dataNascimento);
		} catch (Exception e) {
			throw new Exception("Erro no cadastro de funcionario. " + e.getMessage());
		}
	}
	
	/**
	 * Metodo que tem a funcao de gerar a matricula automaticamente de um
	 * usuario;
	 * 
	 * @param cargo
	 *            Cargo excercido pelo usuario;
	 * @return Retorna a matricula gerada;
	 */
	public String getInfoFuncionario(String matricula, String atributo) throws Exception {
		try {
			return controller.getInfoFuncionario(matricula, atributo);
		} catch (Exception e) {
			throw new Exception("Erro na consulta de funcionario. " + e.getMessage());
		}
	}
	
	/**
	 * Metodo que realiza logout no funcionario;
	 * 
	 * @throws Exception
	 *             Lanca excecao caso nao seja possivel realizar o logout;
	 */
	public void logout() throws Exception {
		try {
			controller.logout();
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
	/**
	 * Metodo que fecha o sistema caso todos os funcionarios ja tenham realizado
	 * o logout;
	 * 
	 * @throws Exception
	 *             Lanca excecao caso ainda exista um funcionario logado;
	 */
	public void fechaSistema() throws Exception {
		controller.fechaSistema();
		try {
			File arquivo = new File("system_data.dat");
			FileOutputStream fos = new FileOutputStream(arquivo);
			BufferedOutputStream bos = new BufferedOutputStream(fos);
			ObjectOutputStream obs = new ObjectOutputStream(bos);

			obs.writeObject(controller);
			obs.close();
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
	/**
	 * Metodo que cadastra pacientes no sistema;
	 * 
	 * @param nome
	 *            Nome do paciente; dataNascimento Data de nascimento do
	 *            paciente; peso Massa do paciente dada em quilogramas; sexo
	 *            Sexo biol�gico do paciente (Masculino/Feminino); genero Genero
	 *            do paciente; tipoSanguineo Tipo de sangue do paciente
	 *            (A+,A-,B+,B-,O+,O-,AB+ ou AB-);
	 * 
	 * @return Retorna uma string;
	 * 
	 * @throws Exception
	 *             Lanca excecao caso ocorra erro ao cadastrar o paciente;
	 */
	public String cadastraPaciente(String nome, String data, double peso, String sexo, String genero,
			String tipoSanguineo) throws Exception {
		try {
			return controller.cadastraPaciente(nome, data, peso, sexo, genero, tipoSanguineo);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
	/**
	 * Metodo que busca informacoes do paciente que estao em prontuario.
	 * 
	 * @param nome
	 *            Nome do paciente.
	 * @param atributo
	 *            Atributo do paciente.
	 * @return Retorna o nome do paciente.
	 * @throws Exception
	 */
	public String getInfoPaciente(String nome, String atributo) throws Exception {
		try {
			return controller.getInfoPaciente(nome, atributo);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
	/**
	 * Metodo que busca prontuario na classe prontuario.
	 * 
	 * @param posicao
	 *            Recebe um inteiro posicao.
	 * @return Retorna uma posicao de prontuario.
	 * @throws Exception
	 */
	public String getProntuario(int posicao) throws Exception {
		try {
			return controller.getProntuario(posicao);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
	/**
	 * Metodo que altera a senha do usuario, verificando primeiramente se a
	 * senha � igual a anterior e caso seja libera o sistema para alterar a
	 * senha;
	 * 
	 * @param senha
	 *            Antiga senha do usuario;
	 * @param matricula
	 *            Matricula do usuario;
	 * @param novaSenha
	 *            Nova senha digitada pelo usuario;
	 * @throws Exception
	 *             Lanca excecao por causa do metodo verificaFuncionario;
	 */
	public void atualizaSenha(String senha, String novaSenha) throws Exception {
		try {
			controller.atualizaSenha(senha, novaSenha);
		} catch (Exception e) {
			throw new Exception("Erro ao atualizar funcionario. " + e.getMessage());
		}
	}

	/**
	 * Metodo que permite que o usuario altere o seu nome;
	 * 
	 * @param novoNome
	 *            Novo nome do usuario;
	 * @param matricula
	 *            Matricula do usuario;
	 */
	public void alteraNome(String novoNome, String matricula) throws Exception {
		try {
			controller.alteraNome(novoNome, matricula);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	/**
	 * Metodo que altera a data de nascimento do usuario;
	 * 
	 * @param data
	 *            Data de nascimento;
	 * @param matricula
	 *            Matricula do usuario;
	 */
	public void alteraData(String data, String matricula) throws Exception {
		try {
			controller.alteraData(data, matricula);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	/**
	 * Metodo que exclui funcionarios, apenas o diretor pode excluir um
	 * funcionario, por isso precisa conferir se a senha digitada e a mesma
	 * colocada pelo diretor anteriormente;
	 * 
	 * @param matricula
	 *            Matricula do usuario;
	 * @param senhaDiretor
	 *            Senha do diretor;
	 */
	public void excluiFuncionario(String matricula, String senhaDiretor) throws Exception {
		try {
			controller.excluiFuncionario(matricula, senhaDiretor);
		} catch (Exception e) {
			throw new Exception("Erro ao excluir funcionario. " + e.getMessage());
		}
	}

	/**
	 * Metodo que verifica se a nova senha colocada pelo usuario e valida;
	 * 
	 * @param senha
	 *            Nova senha que sera utilizada;
	 * @return Retorna um boolean
	 * @throws Exception
	 *             Lanca excecao caso a senha seja menor que 8 caracteres e
	 *             maior que 12;
	 */
	public boolean verificaSenha(String senha) throws Exception {
		try {
			return controller.verificaSenha(senha);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	/**
	 * Metodo que verifica se o novo nome escolhido pelo usuario e valido;
	 * 
	 * @param nome
	 *            Nome do usuario;
	 * @return Retorna um boolean;
	 * @throws Exception
	 *             Lanca excecao caso o nome tenha mais de 12 caracteres;
	 */
	public boolean verificaNome(String nome) throws Exception {
		try {
			return controller.verificaNome(nome);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
	/**
	 * Metodo que atualiza informacoes do funcionario;
	 * 
	 * @param atributo
	 *            Atributo que sera modificado; novoValor Atualizacao da
	 *            informacao antiga;
	 * @throws Exception
	 *             Lanca excecao caso o nome do funcionario seja vazio;
	 */
	public void atualizaInfoFuncionario(String atributo, String novoValor) throws Exception {
		try {
			controller.atualizaInfoFuncionario(atributo, novoValor);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public void atualizaInfoFuncionario(String matricula, String atributo, String novoValor) throws Exception {
		try {
			controller.atualizaInfoFuncionario(matricula, atributo, novoValor);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
	/**
	 * Metodo que cadastra medicamentos.
	 * 
	 * @param nome
	 *            Nome do remedio.
	 * @param tipo
	 *            Tipo do remedio.
	 * @param preco
	 *            Preco do remedio.
	 * @param quantidade
	 *            Quantidade do remedio.
	 * @param categorias
	 *            Categorias.
	 * @return Retorna um medicamento.
	 * @throws Exception
	 */
	public String cadastraMedicamento(String nome, String tipo, double preco, int quantidade, String categorias)
			throws Exception {
		try {
			return this.controller.cadastraMedicamento(nome, tipo, preco, quantidade, categorias);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
	/**
	 * Metodo que busca informacoes do medicamento.
	 * 
	 * @param atributo
	 *            Atributo
	 * @param medica
	 *            Nome do medicamento.
	 * @return Retorna as informacoes.
	 * @throws Exception
	 */
	public String getInfoMedicamento(String atributo, String medica) throws Exception {
		try {
			return this.controller.getInfoMedicamento(atributo, medica);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
	/**
	 * Metodo que atualiza medicamentos.
	 * 
	 * @param nome
	 *            Nome do medicamento.
	 * @param atributo
	 *            Atributo.
	 * @param novovalor
	 *            Novo valor do medicamento.
	 * @throws Exception
	 */
	public void atualizaMedicamento(String nome, String atributo, String novovalor) throws Exception {
		try {
			this.controller.atualizaMedicamento(nome, atributo, novovalor);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
	/**
	 * Metodo que busca medicamento por categoria.
	 * 
	 * @param categoria
	 *            Categoria do medicamento.
	 * @return Retorna o nome do medicamento.
	 * @throws Exception
	 */
	public String buscaPorCategoria(String categoria) throws Exception {
		try {
			return this.controller.buscaPorCategoria(categoria);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
	/**
	 * Metodo que busca o estoque de farmacia.
	 * 
	 * @param ordenacao
	 *            Ordenacao
	 * @return Retorna nome de medicamentos.
	 * @throws Exception
	 */
	public String getEstoqueFarmacia(String ordenacao) throws Exception {
		try {
			return this.controller.getEstoqueFarmacia(ordenacao);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
	/**
	 * Metodo que consulta medicamento por nome.
	 * 
	 * @param nome
	 *            Nome do medicamento.
	 * @return Retorna o nome do medicamento.
	 * @throws Exception
	 */
	public String consultaMedNome(String nome) throws Exception {
		try {
			return this.controller.consultaMedNome(nome);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
	/**
	 * Metodo que consulta medicamento por categoria.
	 * 
	 * @param categoria
	 *            Categoria do medicamento.
	 * @return Retorna os medicamentos dessa categoria.
	 * @throws Exception
	 */
	public String consultaMedCategoria(String categoria) throws Exception {
		try {
			return this.controller.consultaMedCategoria(categoria);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
	/**
	 * Metodo que cadastra Orgaos.
	 * 
	 * @param nome
	 *            Nome do orgao.
	 * @param tipoSanguineo
	 *            Tipo sanguineo do Orgao.
	 * @throws Exception
	 */
	public void cadastraOrgao(String nome, String tipoSanguineo) throws Exception {
		try {
			this.controller.cadastraOrgao(nome, tipoSanguineo);
		} catch (Exception e) {
			throw new Exception("O banco de orgaos apresentou um erro." + e.getMessage());
		}

	}
	
	/**
	 * Metodo que busca orgao pelo tipo sanguineo.
	 * 
	 * @param tipoSanguineo
	 *            Tipo sanguineo.
	 * @return Retorna o orgao.
	 * @throws Exception
	 */
	public String buscaOrgPorSangue(String tipoSanguineo) throws Exception {
		try {
			return this.controller.buscaOrgPorSangue(tipoSanguineo);
		} catch (Exception e) {
			throw new Exception("O banco de orgaos apresentou um erro." + e.getMessage());

		}
	}
	
	/**
	 * Metodo que busca orgao pelo nome.
	 * 
	 * @param nome
	 *            Nome do orgao.
	 * @return Retorna o orgao.
	 * @throws Exception
	 */
	public String buscaOrgPorNome(String nome) throws Exception {
		try {
			return this.controller.buscaOrgPorNome(nome);

		} catch (Exception e) {
			throw new Exception("O banco de orgaos apresentou um erro." + e.getMessage());

		}
	}
	

	/**
	 * Metodo que simplesmente busca o orgao.
	 * 
	 * @param nome
	 *            Nome do orgao.
	 * @param tipoSanguineo
	 *            Tipo sanguineo do orgao.
	 * @return Retorna o orgao.
	 * @throws Exception
	 */
	public String buscaOrgao(String nome, String tipoSanguineo) throws Exception {
		try {
			return this.controller.buscaOrgao(nome, tipoSanguineo);
		} catch (Exception e) {
			throw new Exception("O banco de orgaos apresentou um erro." + e.getMessage());
		}
	}
	
	/**
	 * Metodo que retira orgao.
	 * 
	 * @param nome
	 *            Nome do orgao.
	 * @param tipoSanguineo
	 *            Tipo sanguineo do orgao.
	 * @throws Exception
	 */
	public void retiraOrgao(String nome, String tipoSanguineo) throws Exception {
		try {
			this.controller.retiraOrgao(nome, tipoSanguineo);
		} catch (Exception e) {
			throw new Exception("Erro na retirada de orgaos." + e.getMessage());
		}
	}
	
	/**
	 * Metodo que busca a quantidade de orgaos.
	 * 
	 * @param nome
	 *            Nome do orgao.
	 * @return Retorna a quantidade de orgaos.
	 * @throws Exception
	 */
	public String qtdOrgaos(String nome) throws Exception {
		try {
			return this.controller.qtdOrgaos(nome);

		} catch (Exception e) {
			throw new Exception("O banco de orgaos apresentou um erro." + e.getMessage());
		}
	}
	
	/**
	 * Meotodo que retorna o total de orgaos disponiveis.
	 * 
	 * @return Retorna a quantidade de orgaos disponiveis.
	 */
	public String totalOrgaosDisponiveis() throws Exception {
		try {
			return this.controller.totalOrgaosDisponiveis();
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}	
	
	/**
	 * Metodo que busca o ID do paciente.
	 * 
	 * @param nome
	 *            Nome do paciente.
	 * @return Retorna o ID do paciente.
	 */
	public String getPacienteID(String nome) throws Exception {
		try {
			return this.controller.getIdPaciente(nome);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
	/**
	 * Metodo que realiza o procedimento a ele designado, algum tipo de
	 * cirurgia.
	 * 
	 * @param procedimento
	 *            Procedimento.
	 * @param nome
	 *            Nome do paciente.
	 * @param medicamentos
	 *            Medicamento.
	 * @throws Exception
	 */
	public void realizaProcedimento(String procedimento, String nome, String medicamentos) throws Exception {
		try {
			this.controller.realizaProcedimento(procedimento, nome, medicamentos);
		} catch (Exception e) {
			throw new Exception("Erro na realizacao de procedimentos." + e.getMessage());
		}
	}
	
	/**
	 * Sobrecarga de metodo em que realiza procedimento.
	 * 
	 * @param procedimento
	 *            Procedimento.
	 * @param nome
	 *            Nome do paciente.
	 * @param orgao
	 *            Orgao.
	 * @param medicamentos
	 *            Medicamento
	 * @throws Exception
	 */
	public void realizaProcedimento(String procedimento, String nome, String orgao, String medicamentos)
			throws Exception {
		try {

			this.controller.realizaProcedimento(procedimento, nome, orgao, medicamentos);
		} catch (Exception e) {
			throw new Exception("Erro na realizacao de procedimentos." + e.getMessage());
		}
	}
	
	/**
	 * Metodo que retorna o total de procedimentos.
	 * 
	 * @param nome
	 *            Nome do procedimento.
	 * @return Retorna o procedimento.
	 */
	public String getTotalProcedimento(String nome) throws Exception {
		try {
			return this.controller.getTotalProcedimento(nome);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
	/**
	 * Metodo que retorna a quantidade gasta pelo paciente.
	 * 
	 * @param id
	 *            ID do paciente.
	 * @return Retorna a quantidade de gastos.
	 */
	public String getGastosPaciente(String id) throws Exception {
		try {
			return this.controller.getGastosPaciente(id);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
	/**
	 * Metodo que busca a quantidade de pontos fidelidade o paciente possui.
	 * 
	 * @param id
	 * @return
	 */
	public String getPontosFidelidade(String id) throws Exception {
		try {
			return this.controller.getPontosFidelidade(id);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
	/**
	 * Metodo que realiza procedimento.
	 * 
	 * @param procedimento
	 *            Procedimento.
	 * @param id
	 *            ID do paciente.
	 * @throws Exception
	 */
	public void realizaProcedimento(String procedimento, String id) throws Exception {
		try {
			this.controller.realizaProcedimento(procedimento, id);
		} catch (Exception e) {
			throw new Exception("Erro na realizacao de procedimentos." + e.getMessage());
		}

	}
	
	/**
	 * Metodo que tem a funcao de armazenar em aquivo as informacoes de um paciente especifico.
	 * @param nomeArquivo Nome do arquivo que ser� salvo.
	 * @param fichaPaciente Recebe a ficha do paciente.
	 * @throws IOException 
	 */
	public String exportaFichaPaciente(String idPaciente) {
		try {
			return controller.exportaFichaPaciente(idPaciente);
		} catch (Exception e) {
			return null;
		}
	}

	public void iniciaSistema() {
		try {
			File arquivo = new File("system_data.dat");
			if (!arquivo.exists()) {
				arquivo.createNewFile();
			}

			FileInputStream file = new FileInputStream(arquivo);
			BufferedInputStream buffer = new BufferedInputStream(file);
			ObjectInputStream objeto = new ObjectInputStream(buffer);

			controller = (Controller) objeto.readObject();
			objeto.close();
		} catch (Exception e) {
		}
	}

}
