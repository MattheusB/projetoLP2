package controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import easyaccept.EasyAccept;

public class Facade {

	public static void main(String[] args) {
		args = new String[] { "controller.Facade", "test/usecase_1.txt", "test/usecase_2.txt", "test/usecase_3.txt",
				"test/usecase_4.txt", "test/usecase_5.txt", "test/usecase_6.txt", "test/usecase_7.txt" };// separe
		EasyAccept.main(args);
	}

	Controller controller = new Controller();

	public String liberaSistema(String chave, String nome, String dataNascimento) throws Exception {
		try {
			return controller.liberaSistema(chave, nome, dataNascimento);
		} catch (Exception e) {
			throw new Exception("Erro ao liberar o sistema." + e.getMessage());
		}
	}

	public String login(String matricula, String senha) throws Exception {
		try {
			return controller.login(matricula, senha);
		} catch (Exception e) {
			throw new Exception("Nao foi possivel realizar o login. " + e.getMessage());
		}
	}

	public String cadastraFuncionario(String nome, String cargo, String dataNascimento) throws Exception {
		try {
			return controller.cadastraFuncionario(nome, cargo, dataNascimento);
		} catch (Exception e) {
			throw new Exception("Erro no cadastro de funcionario. " + e.getMessage());
		}
	}

	public String getInfoFuncionario(String matricula, String atributo) throws Exception {
		try {
			return controller.getInfoFuncionario(matricula, atributo);
		} catch (Exception e) {
			throw new Exception("Erro na consulta de funcionario. " + e.getMessage());
		}
	}

	public void logout() throws Exception {
		try {
			controller.logout();
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public void fechaSistema() throws Exception {
		controller.fechaSistema();
		try {
			File arquivo = new File("system_data.dat");
			FileOutputStream fos = new FileOutputStream(arquivo);
			BufferedOutputStream bos = new BufferedOutputStream(fos);
			ObjectOutputStream obs = new ObjectOutputStream(bos);

			obs.writeObject(controller);
			obs.close();
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public String cadastraPaciente(String nome, String data, double peso, String sexo, String genero,
			String tipoSanguineo) throws Exception {
		try {
			return controller.cadastraPaciente(nome, data, peso, sexo, genero, tipoSanguineo);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public String getInfoPaciente(String nome, String atributo) throws Exception {
		try {
			return controller.getInfoPaciente(nome, atributo);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public String getProntuario(int posicao) throws Exception {
		try {
			return controller.getProntuario(posicao);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	// Metodo altera senha que primeiramente verifica a matricula e se for igual
	// a matricula do usuario
	// que est� usando o sistema ele ter� acesso a parte de alterar senha;
	public void atualizaSenha(String senha, String novaSenha) throws Exception {
		try {
			controller.atualizaSenha(senha, novaSenha);
		} catch (Exception e) {
			throw new Exception("Erro ao atualizar funcionario. " + e.getMessage());
		}
	}

	// Metodo que altera o nome;
	public void alteraNome(String novoNome, String matricula) throws Exception {
		try {
			controller.alteraNome(novoNome, matricula);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	// Metodo que altera a data de nascimento;
	public void alteraData(String data, String matricula) throws Exception {
		try {
			controller.alteraData(data, matricula);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	// Metodo que Exclui funcionario;
	// Como j� foi dito acima, "funcionarios" precisa de uma parte de brito;
	public void excluiFuncionario(String matricula, String senhaDiretor) throws Exception {
		try {
			controller.excluiFuncionario(matricula, senhaDiretor);
		} catch (Exception e) {
			throw new Exception("Erro ao excluir funcionario. " + e.getMessage());
		}
	}

	// Metodo que verifica se a nova senha que o usuario ir� criar est�
	// v�lida;
	public boolean verificaSenha(String senha) throws Exception {
		try {
			return controller.verificaSenha(senha);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	// Metodo que verifica se o novo nome que o usuario ir� criar est�
	// v�lida;
	public boolean verificaNome(String nome) throws Exception {
		try {
			return controller.verificaNome(nome);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public void atualizaInfoFuncionario(String atributo, String novoValor) throws Exception {
		try {
			controller.atualizaInfoFuncionario(atributo, novoValor);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public void atualizaInfoFuncionario(String matricula, String atributo, String novoValor) throws Exception {
		try {
			controller.atualizaInfoFuncionario(matricula, atributo, novoValor);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public String cadastraMedicamento(String nome, String tipo, double preco, int quantidade, String categorias)
			throws Exception {
		try {
			return this.controller.cadastraMedicamento(nome, tipo, preco, quantidade, categorias);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public String getInfoMedicamento(String atributo, String medica) throws Exception {
		try {
			return this.controller.getInfoMedicamento(atributo, medica);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public void atualizaMedicamento(String nome, String atributo, String novovalor) throws Exception {
		try {
			this.controller.atualizaMedicamento(nome, atributo, novovalor);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public String buscaPorCategoria(String categoria) throws Exception {
		try {
			return this.controller.buscaPorCategoria(categoria);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public String getEstoqueFarmacia(String ordenacao) throws Exception {
		try {
			return this.controller.getEstoqueFarmacia(ordenacao);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public String consultaMedNome(String nome) throws Exception {
		try {
			return this.controller.consultaMedNome(nome);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public String consultaMedCategoria(String categoria) throws Exception {
		try {
			return this.controller.consultaMedCategoria(categoria);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public void cadastraOrgao(String nome, String tipoSanguineo) throws Exception {
		try {
			this.controller.cadastraOrgao(nome, tipoSanguineo);
		} catch (Exception e) {
			throw new Exception("O banco de orgaos apresentou um erro." + e.getMessage());
		}

	}

	public String buscaOrgPorSangue(String tipoSanguineo) throws Exception {
		try {
			return this.controller.buscaOrgPorSangue(tipoSanguineo);
		} catch (Exception e) {
			throw new Exception("O banco de orgaos apresentou um erro." + e.getMessage());

		}
	}

	public String buscaOrgPorNome(String nome) throws Exception {
		try {
			return this.controller.buscaOrgPorNome(nome);

		} catch (Exception e) {
			throw new Exception("O banco de orgaos apresentou um erro." + e.getMessage());

		}
	}

	public String buscaOrgao(String nome, String tipoSanguineo) throws Exception {
		try {
			return this.controller.buscaOrgao(nome, tipoSanguineo);
		} catch (Exception e) {
			throw new Exception("O banco de orgaos apresentou um erro." + e.getMessage());
		}
	}

	public void retiraOrgao(String nome, String tipoSanguineo) throws Exception {
		try {
			this.controller.retiraOrgao(nome, tipoSanguineo);
		} catch (Exception e) {
			throw new Exception("Erro na retirada de orgaos." + e.getMessage());
		}
	}

	public String qtdOrgaos(String nome) throws Exception {
		try {
			return this.controller.qtdOrgaos(nome);

		} catch (Exception e) {
			throw new Exception("O banco de orgaos apresentou um erro." + e.getMessage());
		}
	}

	public String totalOrgaosDisponiveis() throws Exception {
		try {
			return this.controller.totalOrgaosDisponiveis();
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public String getPacienteID(String nome) throws Exception {
		try {
			return this.controller.getIdPaciente(nome);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public void realizaProcedimento(String procedimento, String nome, String medicamentos) throws Exception {
		try {
			this.controller.realizaProcedimento(procedimento, nome, medicamentos);
		} catch (Exception e) {
			throw new Exception("Erro na realizacao de procedimentos." + e.getMessage());
		}
	}

	public void realizaProcedimento(String procedimento, String nome, String orgao, String medicamentos)
			throws Exception {
		try {

			this.controller.realizaProcedimento(procedimento, nome, orgao, medicamentos);
		} catch (Exception e) {
			throw new Exception("Erro na realizacao de procedimentos." + e.getMessage());
		}
	}

	public String getTotalProcedimento(String nome) throws Exception {
		try {
			return this.controller.getTotalProcedimento(nome);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public String getGastosPaciente(String id) throws Exception {
		try {
			return this.controller.getGastosPaciente(id);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public String getPontosFidelidade(String id) throws Exception {
		try {
			return this.controller.getPontosFidelidade(id);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	public void realizaProcedimento(String procedimento, String id) throws Exception {
		try {
			this.controller.realizaProcedimento(procedimento, id);
		} catch (Exception e) {
			throw new Exception("Erro na realizacao de procedimentos." + e.getMessage());
		}

	}

	public String exportaFichaPaciente(String idPaciente) {
		try {
			return controller.exportaFichaPaciente(idPaciente);
		} catch (Exception e) {
			return null;
		}
	}

	public void iniciaSistema() {
		try {
			File arquivo = new File("system_data.dat");
			if (!arquivo.exists()) {
				arquivo.createNewFile();
			}

			FileInputStream file = new FileInputStream(arquivo);
			BufferedInputStream buffer = new BufferedInputStream(file);
			ObjectInputStream objeto = new ObjectInputStream(buffer);

			controller = (Controller) objeto.readObject();
			objeto.close();
		} catch (Exception e) {
		}
	}

}
