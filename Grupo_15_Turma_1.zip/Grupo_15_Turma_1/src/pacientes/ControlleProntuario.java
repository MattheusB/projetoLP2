package pacientes;

import java.util.ArrayList;
import java.util.Collections;
import java.util.UUID;

public class ControlleProntuario {
	private ArrayList<Paciente> prontuarios;
	private int qntdpacientes = 0;
	
	public ControlleProntuario(){
		prontuarios  = new ArrayList<Paciente>();
	}
	
	public void criarPaciente(String nome, String dataDeNacimento, double peso,String sexo,String genero,String tipoSanguineo)throws Exception{
		this.qntdpacientes += 1;
		UUID id = UUID.randomUUID();
		Paciente novo = new Paciente(nome, dataDeNacimento, peso, tipoSanguineo, sexo, genero,id);
		
		prontuarios.add(novo);
		Collections.sort(prontuarios);
	}
	
	private Paciente verificaPaciente(String nome){
		for(Paciente novo : prontuarios){
			if(novo.getNome().equalsIgnoreCase(nome)){
				return novo;
			}
		}
		
		return null;
	}
	
	public Object getInfoPaciente(String nome ,String atributo){
		Paciente paciente = verificaPaciente(nome);
		if(atributo.equalsIgnoreCase("Nome")){
			return paciente.getNome();
		}
		
		if(atributo.equalsIgnoreCase("Data")){
			return paciente.getDataDeNascimento();
		}
		
		if(atributo.equalsIgnoreCase("TipoSanguineo")){
			return paciente.getTipoSanguineo();
		}
		
		if(atributo.equalsIgnoreCase("Sexo")){
			return paciente.getNome();
		}
		
		if(atributo.equalsIgnoreCase("Peso")){
			return paciente.getPeso();
		}
		
		if(atributo.equalsIgnoreCase("Genero")){
			return paciente.getGenero();
		}
		
		return null;
	}
	
	public Paciente getProntuario(int posicao)throws Exception{
		if(posicao > prontuarios.size()-1){
			throw new Exception("Erro ao consultar prontuario. Nao ha prontuarios suficientes (max = "+prontuarios.size()+").");
		}
		if(posicao < 0){
			throw new Exception("Erro ao consultar prontuario. Indice do prontuario nao pode ser negativo.");
			
		}
		return prontuarios.get(posicao);
	}

	public int getQntdpacientes() {
		return qntdpacientes;
	}

	public void setQntdpacientes(int qntdpacientes) {
		this.qntdpacientes = qntdpacientes;
	}

}
