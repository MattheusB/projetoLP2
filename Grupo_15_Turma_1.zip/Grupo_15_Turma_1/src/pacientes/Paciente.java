package pacientes;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

public class Paciente implements Comparable<Paciente>{
	
	private String nome;
	private LocalDate dataDeNascimento;
	private double peso;
	private String tipoSanguineo;
	private String sexo;
	private String genero;
	private UUID id;
	
	
	public Paciente(String nome, String dataNacimento, double peso, String tipoSanguineo, String sexo, String genero, UUID id)throws Exception{
		if(nome.equals("") || nome == null){
			throw new Exception("Nao foi possivel cadastrar o paciente. Nome do paciente nao pode ser vazio.");
		}
		String[] data = dataNacimento.split("/");
		if(Integer.parseInt(data[0]) > 31 || Integer.parseInt(data[1]) > 12){
			throw new Exception("Nao foi possivel cadastrar o paciente. Data invalida.");
		}
		if(peso < 0){
			throw new Exception("Nao foi possivel cadastrar o paciente. Peso do paciente nao pode ser negativo.");
		}
		if(tipoSanguineo != "A+" || tipoSanguineo != "A-" || tipoSanguineo != "O+" || tipoSanguineo != "O-" || tipoSanguineo != "B+" ||
				tipoSanguineo != "B-" || tipoSanguineo != "AB+" || tipoSanguineo != "AB-" ){
			throw new Exception("Nao foi possivel cadastrar o paciente. Tipo sanguineo invalido.");
		}
		String datas = dataNacimento;
		DateTimeFormatter formatador = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate dataa= LocalDate.parse(datas, formatador);
		
		this.nome = nome;
		this.dataDeNascimento = dataa;
		this.peso = peso;
		this.tipoSanguineo = tipoSanguineo;
		this.sexo = sexo;
		this.genero = genero;
		this.id = id;
		Prontuario novoprontuario = new Prontuario();
	}
	
	public String toString(){
		return "Nome: " + this.nome + "\nData de Nascimento: " + this.dataDeNascimento + "\nPeso: " + this.peso 
				+ "\nTipo Sanguineo: " + this.tipoSanguineo + "\nSexo: " + this.sexo + "\nGenero: " + this.genero + "\nID: " + this.id;
	}


	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}


	public LocalDate getDataDeNascimento() {
		return dataDeNascimento;
	}


	public void setDataDeNascimento(LocalDate dataDeNascimento) {
		this.dataDeNascimento = dataDeNascimento;
	}


	public double getPeso() {
		return peso;
	}


	public void setPeso(double peso) {
		this.peso = peso;
	}


	public String getTipoSanguineo() {
		return tipoSanguineo;
	}


	public void setTipoSanguineo(String tipoSanguineo) {
		this.tipoSanguineo = tipoSanguineo;
	}


	public String getSexo() {
		return sexo;
	}


	public void setSexo(String sexo) {
		this.sexo = sexo;
	}


	public String getGenero() {
		return genero;
	}


	public void setGenero(String genero) {
		this.genero = genero;
	}


	public UUID getId() {
		return id;
	}


	public void setId(UUID id) {
		this.id = id;
	}





	@Override
	public int compareTo(Paciente novo) {
		
		return this.nome.compareTo(novo.getNome());
	}

}
