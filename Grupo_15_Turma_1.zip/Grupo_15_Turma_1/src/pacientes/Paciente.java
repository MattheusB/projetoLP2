package pacientes;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

import java.util.UUID;

import cartaofidelidade.CartaoFidelidade;
import cartaofidelidade.CartaoMaster;
import cartaofidelidade.CartaoPadrao;
import cartaofidelidade.CartaoVip;

/**
 * Classe que tem a funcao de criar pacientes.
 */
public class Paciente implements Serializable {
	private static final long serialVersionUID = 7535244871804465593L;
	private String nome;
	private LocalDate dataDeNascimento;
	private double peso;
	private String tipoSanguineo;
	private String sexo;
	private String genero;
	private UUID id;
	private int idade;
	private double valorprocedimentos;
	private CartaoFidelidade cartao;
	private int pontos;

	/**
	 * Metodo que cria tem a funcao de criar pacientes passando as variaveis
	 * abaixo.
	 * 
	 * @param nome
	 *            Nome do paciente.
	 * @param dataNacimento
	 *            Data de nascimento do paciente.
	 * @param peso
	 *            Massa do paciente.
	 * @param sexo
	 *            Sexo do paciente.
	 * @param genero
	 *            Genero do paciente.
	 * @param tipoSanguineo
	 *            Tipo sanguineo do paciente.
	 * @param id
	 *            ID do paciente.
	 * @throws Exception
	 */
	public Paciente(String nome, String dataNacimento, double peso, String sexo, String genero, String tipoSanguineo,
			UUID id) throws Exception {
		if (nome.trim().isEmpty() || nome == null) {
			throw new Exception("Nao foi possivel cadastrar o paciente. Nome do paciente nao pode ser vazio.");
		}
		verificaData(dataNacimento);
		if (peso < 0) {
			throw new Exception("Nao foi possivel cadastrar o paciente. Peso do paciente nao pode ser negativo.");
		}

		if (!(verificaTipoSanguineo(tipoSanguineo))) {
			throw new Exception("Nao foi possivel cadastrar o paciente. Tipo sanguineo invalido.");
		}

		String datas = dataNacimento;
		DateTimeFormatter formatador = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate dataa = LocalDate.parse(datas, formatador);
		LocalDate hoje = LocalDate.now();
		long diferencaEmAnos = ChronoUnit.YEARS.between(dataa, hoje);
		this.nome = nome;
		this.dataDeNascimento = dataa;
		this.peso = peso;
		this.tipoSanguineo = tipoSanguineo;
		this.sexo = sexo;
		this.genero = genero;
		this.id = id;
		this.idade = (int) diferencaEmAnos;
		this.setValorprocedimentos(0);
		this.cartao = new CartaoPadrao();
		this.pontos = 0;

	}

	/**
	 * Metodo que tem a funcao de alterar o genero do paciente.
	 * 
	 * @return retorna verdade apos alterar o genero.
	 */
	public boolean alteraGenero() {
		if (this.getGenero().equalsIgnoreCase("masculino")) {
			this.setGenero("feminino");
			return true;
		}
		this.setGenero("masculino");
		return true;

	}

	public String toString() {
		return "Paciente: " + this.getNome() + "\n" + "Peso: " + this.getPeso() + " kg Tipo Sangu�neo: "
				+ this.tipoSanguineo + "\n" + "Sexo: " + this.sexo + " Genero: " + this.genero + "\n"
				+ "Gasto total: R$ " + this.valorprocedimentos + " Pontos acumulados: " + this.pontos;

	}

	/**
	 * Metodo que da desconto a um procedimento.
	 * 
	 * @param valor
	 *            Recebe o valor como paramentro.
	 */
	public void descontoServico(double valor) {
		Double valoor = this.cartao.descontoservico(valor) + this.getValorprocedimentos();

		this.setValorprocedimentos(valoor);
	}

	/**
	 * Metodo que da um bonus ao paciente a partir da quantidade de pontos que
	 * ele possui.
	 * 
	 * @param bonus
	 *            Inteiro bonus.
	 */
	public void ceditobonus(int bonus) {
		// this.cartao.creditobonus(bonus)
		int valor = bonus + this.getPontos();

		this.setPontos(valor);
		verificaPontos();

	}

	/**
	 * Metodo que tem a funcao de verificar a quantidade de pontos que o
	 * paciente possui.
	 */
	private void verificaPontos() {
		if (this.getPontos() >= 150 && this.getPontos() <= 350) {
			this.cartao = new CartaoMaster();
		}

		if (this.getPontos() > 350) {
			this.cartao = new CartaoVip();
		}
	}

	/**
	 * Metodo que verifica a data de nascimento do paciente.
	 * 
	 * @param dataNascimento
	 *            Data de nascimento.
	 * @throws Exception
	 */
	private void verificaData(String dataNascimento) throws Exception {
		try {
			// parse nao aceita datas de dia e mes invalidas
			// relancando entao, propria exception
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			@SuppressWarnings("unused")
			LocalDate data = LocalDate.parse(dataNascimento, formatter);

		} catch (Exception e) {
			throw new Exception("Nao foi possivel cadastrar o paciente. Data invalida.");

		}

	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dataDeNascimento == null) ? 0 : dataDeNascimento.hashCode());
		result = prime * result + ((genero == null) ? 0 : genero.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((nome == null) ? 0 : nome.hashCode());
		long temp;
		temp = Double.doubleToLongBits(peso);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((sexo == null) ? 0 : sexo.hashCode());
		result = prime * result + ((tipoSanguineo == null) ? 0 : tipoSanguineo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Paciente other = (Paciente) obj;
		if (dataDeNascimento == null) {
			if (other.dataDeNascimento != null)
				return false;
		} else if (!dataDeNascimento.equals(other.dataDeNascimento))
			return false;
		if (genero == null) {
			if (other.genero != null)
				return false;
		} else if (!genero.equals(other.genero))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (nome == null) {
			if (other.nome != null)
				return false;
		} else if (!nome.equals(other.nome))
			return false;
		if (Double.doubleToLongBits(peso) != Double.doubleToLongBits(other.peso))
			return false;
		if (sexo == null) {
			if (other.sexo != null)
				return false;
		} else if (!sexo.equals(other.sexo))
			return false;
		if (tipoSanguineo == null) {
			if (other.tipoSanguineo != null)
				return false;
		} else if (!tipoSanguineo.equals(other.tipoSanguineo))
			return false;
		return true;
	}

	/**
	 * Metodo que verifica do tipo sanguineo.
	 * 
	 * @param tipo
	 *            Recebe o tipo sanguineo.
	 * @return Retorna verdade se obtiver o mesmo tipo.
	 */
	private boolean verificaTipoSanguineo(String tipo) {
		String[] tipos = { "A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-" };

		for (String s : tipos) {
			if (s.equals(tipo))
				return true;
		}
		return false;
	}

	public int getPontos() {
		return pontos;
	}

	public void setPontos(int ponto) {
		this.pontos = ponto;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public LocalDate getDataDeNascimento() {
		return dataDeNascimento;
	}

	public void setDataDeNascimento(LocalDate dataDeNascimento) {
		this.dataDeNascimento = dataDeNascimento;
	}

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		this.peso = peso;
	}

	public String getTipoSanguineo() {
		return tipoSanguineo;
	}

	public void setTipoSanguineo(String tipoSanguineo) {
		this.tipoSanguineo = tipoSanguineo;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	public String getGenero() {
		return genero;
	}

	public void setGenero(String genero) {
		this.genero = genero;
	}

	public UUID getId() {
		return id;
	}

	public void setId(UUID id) {
		this.id = id;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}

	public double getValorprocedimentos() {
		return valorprocedimentos;
	}

	public void setValorprocedimentos(double valorprocedimentos) {
		this.valorprocedimentos = valorprocedimentos;
	}

}
