package funcionario;
/**
 * Enum "Funcoes"
 * 
 * Existem cinco funcoes dos funcionarios organizadas pelo Enum: Exclui funcionario, Cadastrar, Alterar,
 * Cadastrar paciente e Cadastrar medicamentos.
 */
public enum Funcoes {
	EXCLUIFUNCIONARIO,CADASTRAR,ALTERAR,CADASTRAPACIENTE,CADASTRARMEDICAMENTOS,CADASTRARORGAOS,REALIZARPROCEDIMENTOS	
}
