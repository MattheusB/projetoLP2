package funcionario;

import java.time.LocalDate;
import java.util.LinkedList;

public class Funcionario {
	private String nome;
	private LinkedList<Funcoes> funcoes;
	private String senha;
	private String cargo;
	private LocalDate dataNascimento;
	private String matricula;
	
	public Funcionario (String nome, LocalDate dataNascimento, String cargo, String matricula, String senha, LinkedList<Funcoes> funcoes) throws Exception{
		this.nome = nome;
		this.dataNascimento = dataNascimento;
		this.cargo = cargo;
		this.matricula = matricula;
		this.senha = senha;
		this.funcoes = funcoes;
	}
	
	public boolean verificaFuncao(Funcoes funcao){
		return funcoes.contains(funcao);
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public LocalDate getDatanascimento() {
		return dataNascimento;
	}

	public void setDatanascimento(LocalDate dataNascimento) {
		this.dataNascimento = dataNascimento;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public String getCargo() {
		return this.cargo;
	}
	
	public void setCargo(String novoCargo){
		this.cargo = novoCargo;
	}
}