package testes;

import static org.junit.Assert.fail;

import org.junit.Test;

import controller.Controller;

import static org.junit.Assert.assertEquals;

public class TestesController {

	@Test
	public void testController() {
		try {
			/**
			 * Testes do Caso 1
			 */

			// Cria��o da Facade
			Controller controller = new Controller();

			// Libera Sistema
			String matricula = controller.liberaSistema("c041ebf8", "Victor", "03/10/1997");

			// Login
			String diretor = controller.login(matricula, "19971201");

			// GetInfoFuncionario do diretor
			assertEquals(controller.getInfoFuncionario(matricula, "Nome"), "Victor");
			assertEquals(controller.getInfoFuncionario(matricula, "Cargo"), "Diretor Geral");
			assertEquals(controller.getInfoFuncionario(matricula, "Data"), "1997-10-03");

			// Cadastra Funcionario
			String medico1 = controller.cadastraFuncionario("Vinicius", "medico", "05/04/1998");
			String medico2 = controller.cadastraFuncionario("Gerson", "medico", "27/12/1992");
			String tecnico1 = controller.cadastraFuncionario("Gabriel", "tecnico administrativo", "17/05/1997");
			String tecnico2 = controller.cadastraFuncionario("Mattheus", "tecnico administrativo", "12/09/1998");

			// Exceptions de Funcionario
			try {
				controller.cadastraFuncionario("", "medico", "05/04/1998");
				fail();
			} catch (Exception e) {
				assertEquals("Nome do funcionario nao pode ser vazio.", e.getMessage());
			}

			try {
				controller.cadastraFuncionario("Vinicius", "medico", "35/17/3780");
				fail();
			} catch (Exception e) {
				assertEquals("Data invalida.", e.getMessage());
			}

			try {
				controller.cadastraFuncionario("Vinicius", "", "05/04/1998");
				fail();
			} catch (Exception e) {
				assertEquals("Nome do cargo nao pode ser vazio.", e.getMessage());
			}

			try {
				controller.cadastraFuncionario("Vinicius", "secretario", "05/04/1998");
				fail();
			} catch (Exception e) {
				assertEquals("Cargo invalido.", e.getMessage());
			}

			// GetInfoFuncionario
			assertEquals(controller.getInfoFuncionario(medico1, "Nome"), "Vinicius");
			assertEquals(controller.getInfoFuncionario(medico1, "Cargo"), "medico");
			assertEquals(controller.getInfoFuncionario(medico1, "Data"), "1998-04-05");
			assertEquals(controller.getInfoFuncionario(medico2, "Nome"), "Gerson");
			assertEquals(controller.getInfoFuncionario(medico2, "Cargo"), "medico");
			assertEquals(controller.getInfoFuncionario(medico2, "Data"), "1992-12-27");
			assertEquals(controller.getInfoFuncionario(tecnico1, "Nome"), "Gabriel");
			assertEquals(controller.getInfoFuncionario(tecnico1, "Cargo"), "tecnico administrativo");
			assertEquals(controller.getInfoFuncionario(tecnico1, "Data"), "1997-05-17");
			assertEquals(controller.getInfoFuncionario(tecnico2, "Nome"), "Mattheus");
			assertEquals(controller.getInfoFuncionario(tecnico2, "Cargo"), "tecnico administrativo");
			assertEquals(controller.getInfoFuncionario(tecnico2, "Data"), "1998-09-12");

			// Exceptions de GetInfoFuncionario

			try {
				controller.getInfoFuncionario(medico1, "Senha");
				fail();
			} catch (Exception e) {
				assertEquals("A senha do funcionario eh protegida.", e.getMessage());
			}

			try {
				controller.getInfoFuncionario(medico2, "Senha");
				fail();
			} catch (Exception e) {
				assertEquals("A senha do funcionario eh protegida.", e.getMessage());
			}

			try {
				controller.getInfoFuncionario(tecnico1, "Senha");
				fail();
			} catch (Exception e) {
				assertEquals("A senha do funcionario eh protegida.", e.getMessage());
			}

			try {
				controller.getInfoFuncionario(tecnico2, "Senha");
				fail();
			} catch (Exception e) {
				assertEquals("A senha do funcionario eh protegida.", e.getMessage());
			}

			// Logout e Fecha Sistema

			try {
				controller.fechaSistema();
				fail();
			} catch (Exception e) {
				assertEquals("Nao foi possivel fechar o sistema. Um funcionario ainda esta logado: Victor.",
						e.getMessage());
			}

			controller.logout();
			controller.fechaSistema();

			/**
			 * Testes do Caso 2
			 */

			// Excluir Funcionario

			controller.excluiFuncionario("12016002", "19971201");

			// Exceptions de Excluir Funcionario

			try {
				controller.excluiFuncionario("12016999", "19971201");
				fail();
			} catch (Exception e) {
				assertEquals("Erro ao excluir funcionario. Funcionario nao cadastrado.", e.getMessage());
			}

			try {
				controller.excluiFuncionario("djeneogc", "19971201");
				fail();
			} catch (Exception e) {
				assertEquals("Erro ao excluir funcionario. A matricula nao segue o padrao.", e.getMessage());
			}

			try {
				controller.excluiFuncionario("12016003", "fneifejff");
				fail();
			} catch (Exception e) {
				assertEquals("Erro ao excluir funcionario. Senha invalida.", e.getMessage());
			}

			// Modificacao de Funcionarios

			controller.atualizaInfoFuncionario("12016003", "Nome", "Fabio");
			controller.atualizaInfoFuncionario("12016003", "Data", "12/12/2001");
			assertEquals(controller.getInfoFuncionario("12016003", "Nome"), "Fabio");
			assertEquals(controller.getInfoFuncionario("12016003", "Data"), "12-12-2001");

			// Exceptions da Modificacao de Funcionarios

			try {
				controller.atualizaInfoFuncionario("12016003", "Data", "35/27/4006");
				fail();
			} catch (Exception e) {
				assertEquals("Erro ao atualizar funcionario. Data invalida.", e.getMessage());
			}

			try {
				controller.atualizaInfoFuncionario("12016003", "Nome", "");
				fail();
			} catch (Exception e) {
				assertEquals("Erro ao atualizar funcionario. Nome do funcionario nao pode ser vazio.", e.getMessage());
			}

			/**
			 * Testes do Caso 3
			 */

			// Cadastro de Pacientes

			controller.cadastraPaciente("Jean", "10/03/1974", 78.00, "masculino", "feminino", "O+");
			controller.cadastraPaciente("Jair", "21/03/1955", 81.00, "masculino", "masculino", "AB+");
			controller.cadastraPaciente("Rebecca", "30/06/2000", 58.00, "feminino", "feminino", "A+");

			assertEquals(controller.getInfoPaciente("Jean", "Nome"), "Jean");
			assertEquals(controller.getInfoPaciente("Jean", "Data"), "10-03-1974");
			assertEquals(controller.getInfoPaciente("Jean", "Peso"), 78.00);
			assertEquals(controller.getInfoPaciente("Jean", "Sexo"), "masculino");
			assertEquals(controller.getInfoPaciente("Jean", "Genero"), "feminino");
			assertEquals(controller.getInfoPaciente("Jean", "TipoSanguineo"), "O+");

			// Exceptions do Cadastro de Pacientes

			try {
				controller.cadastraPaciente("", "10/03/1974", 78.00, "masculino", "feminino", "O+");
				fail();
			} catch (Exception e) {
				assertEquals("Nao foi possivel cadastrar o paciente. Nome do paciente nao pode ser vazio.",
						e.getMessage());
			}

			try {
				controller.cadastraPaciente("Jean", "10/03/1974", 78.00, "masculino", "feminino", "M-");
				fail();
			} catch (Exception e) {
				assertEquals("Nao foi possivel cadastrar o paciente. Tipo sanguineo invalido.", e.getMessage());
			}

			try {
				controller.cadastraPaciente("Jean", "10/03/1974", -5.00, "masculino", "feminino", "O+");
				fail();
			} catch (Exception e) {
				assertEquals("Nao foi possivel cadastrar o paciente. Peso do paciente nao pode ser negativo.",
						e.getMessage());
			}

			try {
				controller.cadastraPaciente("Jean", "42/13/3089", 78.00, "masculino", "feminino", "O+");
				fail();
			} catch (Exception e) {
				assertEquals("Nao foi possivel cadastrar o paciente. Data invalida.", e.getMessage());
			}

			try {
				controller.cadastraPaciente("Jean", "10/03/1974", 78.00, "masculino", "feminino", "O+");
				fail();
			} catch (Exception e) {
				assertEquals("Nao foi possivel cadastrar o paciente. Paciente ja cadastrado.", e.getMessage());
			}

			/**
			 * Testes do Caso 4
			 */

			// Cadastro de Medicamentos

			controller.cadastraMedicamento("Histamin", "referencia", 35.00, 52, "antialergico");
			controller.cadastraMedicamento("Morfina", "generico", 98.00, 35, "analgesico");
			controller.cadastraMedicamento("Penicilina", "referencia", 76.00, 135, "antibiotico");

			assertEquals(controller.getInfoMedicamento("tipo", "Morfina"), "generico");
			assertEquals(controller.getInfoMedicamento("preco", "Morfina"), 98.00);
			assertEquals(controller.getInfoMedicamento("quantidade", "Morfina"), 35);
			assertEquals(controller.getInfoMedicamento("categorias", "Morfina"), "analgesico");

			// Exceptions do Cadastro de Medicamentos

			try {
				controller.cadastraMedicamento("", "referencia", 35.00, 52, "antialergico");
				fail();
			} catch (Exception e) {
				assertEquals("Erro no cadastro de medicamento. Nome do medicamento nao pode ser vazio.",
						e.getMessage());
			}

			try {
				controller.cadastraMedicamento("Histamin", "referencia", -8.00, 52, "antialergico");
				fail();
			} catch (Exception e) {
				assertEquals("Erro no cadastro de medicamento. Preco do medicamento nao pode ser negativo.",
						e.getMessage());
			}

			try {
				controller.cadastraMedicamento("Histamin", "referencia", 35.00, -52, "antialergico");
				fail();
			} catch (Exception e) {
				assertEquals("Erro no cadastro de medicamento. Quantidade do medicamento nao pode ser negativo.",
						e.getMessage());
			}

			// Atualiza Medicamento

			controller.atualizaMedicamento("Histamin", "preco", "40.00");
			controller.atualizaMedicamento("Histamin", "quantidade", "65");

			try {
				controller.atualizaMedicamento("Histamin", "nome", "Nefienfein");
				fail();
			} catch (Exception e) {
				assertEquals("Erro ao atualizar medicamento. Nome do medicamento nao pode ser alterado.",
						e.getMessage());
			}

			try {
				controller.atualizaMedicamento("Histamin", "tipo", "generico");
				fail();
			} catch (Exception e) {
				assertEquals("Erro ao atualizar medicamento. Tipo do medicamento nao pode ser alterado.",
						e.getMessage());
			}

			try {
				controller.atualizaMedicamento("Viagra", "preco", "50.00");
				fail();
			} catch (Exception e) {
				assertEquals("Erro ao atualizar medicamento. Medicamento nao cadastrado.", e.getMessage());
			}

			// Busca de medicamentos por categoria

			assertEquals(controller.consultaMedCategoria("antialergico"), "Histamin");
			assertEquals(controller.consultaMedCategoria("antibiotico"), "Penicilina");

			// Exceptions da busca de medicamentos por categoria

			try {
				controller.consultaMedCategoria("antiinflamatorio");
				fail();
			} catch (Exception e) {
				assertEquals("Erro na consulta de medicamentos. Nao ha remedios cadastrados nessa categoria.",
						e.getMessage());
			}

			try {
				controller.consultaMedCategoria("antiacaro");
				fail();
			} catch (Exception e) {
				assertEquals("Erro na consulta de medicamentos. Categoria invalida.", e.getMessage());
			}

			// Busca de medicamentos por nome

			assertEquals(
					"Medicamento de Refer�ncia: Histamin - Preco: R$ 40,00 - Disponivel: 65 - Categorias: antialergico",
					controller.consultaMedNome("Histamin"));

			// Exceptions da busca de medicamentos por nome

			try {
				controller.consultaMedNome("Dorflex");
				fail();
			} catch (Exception e) {
				assertEquals("Erro na consulta de medicamentos. Medicamento nao cadastrado.", e.getMessage());
			}

			// Busca por todos os medicamentos

			assertEquals("Histamin,Morfina,Penicilina", controller.getEstoqueFarmacia("alfabetica"));
			assertEquals("Histamin,Penicilina,Morfina", controller.getEstoqueFarmacia("preco"));

			// Exceptions da busca por todos os medicamentos

			try {
				controller.getEstoqueFarmacia("quantidade");
				fail();
			} catch (Exception e) {
				assertEquals("Erro na consulta de medicamentos. Tipo de ordenacao invalida.", e.getMessage());
			}

		} catch (Exception e) {
			fail();
		}
	}

}