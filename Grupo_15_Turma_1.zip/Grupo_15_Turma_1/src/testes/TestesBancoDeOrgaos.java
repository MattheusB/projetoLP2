package testes;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.time.LocalDate;

import bancodeorgaos.*;

import org.junit.Test;

import bancodeorgaos.Orgao;

public class TestesBancoDeOrgaos {

	@Test
	public void bancoDeOrgaosTest() throws Exception {
		
		BancoDeOrgaos banco = new BancoDeOrgaos();
		
		// Adicionando orgaos
		
		banco.cadastraOrgao("Coracao", "O+");
		banco.cadastraOrgao("Baco", "A+");
		
		// Buscando orgaos
		
		banco.buscarOrgaoTipoSanguineo("A+");
		banco.buscarOrgaoNomeTipoSang("Baco", "A+");
		banco.bucarOrgaoPeloNome("Coracao");
		
		try {
			banco.buscaOrgaosCompativel("O+", "Coracao");
			fail();
		} catch (Exception e) {
			assertEquals(" Banco nao possui o orgao especificado.",
					e.getMessage());
		}
		
		
		// Calculando a quantidade de orgaos

		banco.quantidadeDeOrgao("Coracao");
		banco.quantidadeTotalDeOrgaosDisponiveis();
		banco.quantidaOrgao("Baco");
		
		// Removendo um orgao
		
		banco.remove("Coracao", "O+");
		banco.remove("Baco", "A+");
	}

}