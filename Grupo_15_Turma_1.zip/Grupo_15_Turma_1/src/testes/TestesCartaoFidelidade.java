package testes;

import static org.junit.Assert.*;

import cartaofidelidade.*;

import org.junit.Test;

public class TestesCartaoFidelidade {

	@Test
	public void cartaoTest() throws Exception {
		
		CartaoFidelidade cartao;
		
		// Criando cartoes
		
		CartaoMaster cartao1 = new CartaoMaster();
		CartaoVip cartao2 = new CartaoVip();
		CartaoPadrao cartao3 = new CartaoPadrao();
		
		// Verificando se os cartoes sao diferentes
		
		assertNotEquals(cartao1, cartao2);
		assertNotEquals(cartao1, cartao3);
		assertNotEquals(cartao2, cartao3);
		
		// Calculando o desconto do servico
		
		double valor1 = cartao1.descontoservico(50.00);
		assertEquals(42.50, valor1, 0);
		
		double valor2 = cartao2.descontoservico(50.00);
		assertEquals(35.00, valor2, 0);
		
		double valor3 = cartao3.descontoservico(50.00);
		assertEquals(50.00, valor3, 0);
		
		// Calculando o credito bonus
		
		int pontos1 = cartao1.creditobonus(100);
		assertEquals(105, pontos1);
		
		int pontos2 = cartao2.creditobonus(100);
		assertEquals(110, pontos2);
		
		int pontos3 = cartao3.creditobonus(100);
		assertEquals(100, pontos3);
	}

}