package testes;

import java.time.LocalDate;

import procedimentos.ControlleProcedimentos;
import pacientes.*;

import org.junit.Test;

import bancodeorgaos.Orgao;

public class TestesProcedimentos {

	@Test
	public void procedimentoTest() throws Exception {
		
		ControlleProcedimentos procedimento = new ControlleProcedimentos();
		Prontuario prontuario1 = new Prontuario("Jean", "10/03/1974", 78.00, "masculino", "feminino", "O+", null);
		Prontuario prontuario2 = new Prontuario("Gerson", "12/04/1995", 86.00, "masculino", "masculino", "A+", null);
		LocalDate data1 = LocalDate.parse("2016-05-24");
		LocalDate data2 = LocalDate.parse("2016-04-16");
		Orgao orgao = new Orgao("Coracao", "O+");
		
		// Realizar o Procedimento
		
		procedimento.procedimentos(prontuario1, "Consulta clinica", 200.00, "Dr. Rey", data1);
		procedimento.procedimentos(prontuario1, "Cirurgia bariatrica", 8600.00, "Dr. Rey", data1);
		procedimento.procedimentos(prontuario1, "Redesignacao sexual", 2400.00, "Dr. Rey", data1);
		
		// Realizar um Transplante de Orgaos
		
		procedimento.trasnplantedeOrgaos(prontuario2, 450.00, "Dr. Paulo", data2, "Coracao");
		procedimento.trasnplantedeOrgaos(prontuario2, 350.00, "Dr. Paulo", data2, "Figado");
		procedimento.trasnplantedeOrgaos(prontuario2, 350.00, "Dr. Paulo", data2, "Baco");

		
	}

}
