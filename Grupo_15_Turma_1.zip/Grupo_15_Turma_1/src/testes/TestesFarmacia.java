package testes;

import static org.junit.Assert.*;

import org.junit.Test;

import farmacia.*;

public class TestesFarmacia {

	@Test
	public void farmaciaTest() throws Exception {
		
		Farmacia farmacia = new Farmacia();
		
		// Cadastro de Medicamentos
		
		farmacia.criaMedicamento("Histamin", "referencia", 35.00, 52, "antialergico");
		farmacia.criaMedicamento("Morfina", "generico", 98.00, 35, "analgesico");
		farmacia.criaMedicamento("Penicilina", "referencia", 76.00, 135, "antibiotico");
		
		assertEquals(farmacia.getInfoMedicamento("tipo", "Morfina"), "generico");
		assertEquals(farmacia.getInfoMedicamento("preco", "Morfina"), 98.00);
		assertEquals(farmacia.getInfoMedicamento("quantidade", "Morfina"), 35);
		assertEquals(farmacia.getInfoMedicamento("categorias", "Morfina"), "analgesico");

		// Exceptions do Cadastro de Medicamentos
		
		try {
			farmacia.criaMedicamento("", "referencia", 35.00, 52, "antialergico");
			fail(); 
		} catch (Exception e) {
			assertEquals("Erro no cadastro de medicamento. Nome do medicamento nao pode ser vazio.",
					e.getMessage());
		}
		
		try {
			farmacia.criaMedicamento("Histamin", "referencia", -8.00, 52, "antialergico");
			fail(); 
		} catch (Exception e) {
			assertEquals("Erro no cadastro de medicamento. Preco do medicamento nao pode ser negativo.",
					e.getMessage());
		}
		
		try {
			farmacia.criaMedicamento("Histamin", "referencia", 35.00, -52, "antialergico");
			fail(); 
		} catch (Exception e) {
			assertEquals("Erro no cadastro de medicamento. Quantidade do medicamento nao pode ser negativo.",
					e.getMessage());
		}
		
		// Atualiza Medicamento
		
		farmacia.atualizaMedicamento("Histamin", "preco", "40.00");
		farmacia.atualizaMedicamento("Histamin", "quantidade", "65");
		
		try {
			farmacia.atualizaMedicamento("Histamin", "nome", "Nefienfein");
			fail(); 
		} catch (Exception e) {
			assertEquals("Erro ao atualizar medicamento. Nome do medicamento nao pode ser alterado.",
					e.getMessage());
		}
		
		try {
			farmacia.atualizaMedicamento("Histamin", "tipo", "generico");
			fail(); 
		} catch (Exception e) {
			assertEquals("Erro ao atualizar medicamento. Tipo do medicamento nao pode ser alterado.",
					e.getMessage());
		}
		
		try {
			farmacia.atualizaMedicamento("Viagra", "preco", "50.00");
			fail(); 
		} catch (Exception e) {
			assertEquals("Erro ao atualizar medicamento. Medicamento nao cadastrado.",
					e.getMessage());
		}

		// Busca de medicamentos por categoria
		
		assertEquals(farmacia.buscaPorCategoria("antialergico"), "Histamin");
		assertEquals(farmacia.buscaPorCategoria("antibiotico"), "Penicilina");

		// Exceptions da busca de medicamentos por categoria

		try {
			farmacia.buscaPorCategoria("antiinflamatorio");
			fail(); 
		} catch (Exception e) {
			assertEquals("Erro na consulta de medicamentos. Nao ha remedios cadastrados nessa categoria.",
					e.getMessage());
		}
		
		try {
			farmacia.buscaPorCategoria("antiacaro");
			fail(); 
		} catch (Exception e) {
			assertEquals("Erro na consulta de medicamentos. Categoria invalida.",
					e.getMessage());
		}
		
		// Busca de medicamentos por nome
		
		assertEquals("Medicamento de Refer�ncia: Histamin - Preco: R$ 40,00 - Disponivel: 65 - Categorias: antialergico", farmacia.buscaPorNome("Histamin"));
		
		// Exceptions da busca de medicamentos por nome
		
		try {
			farmacia.buscaPorNome("Dorflex");
			fail(); 
		} catch (Exception e) {
			assertEquals("Erro na consulta de medicamentos. Medicamento nao cadastrado.",
					e.getMessage());
		}
	}

}
