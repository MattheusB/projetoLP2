package testes;

import static org.junit.Assert.fail;

import org.junit.Test;

import controller.Facade;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

public class TestesFacade {
	@Test
	public void testFacade() {
		try {
			/**
			 * Testes do Caso 1
			 */

			// Cria��o da Facade
			Facade facada = new Facade();

			// Libera Sistema
			String matricula = facada.liberaSistema("c041ebf8", "Victor", "03/10/1997");

			// Login
			String diretor = facada.login(matricula, "19971201");

			// GetInfoFuncionario do diretor
			assertEquals(facada.getInfoFuncionario(matricula, "Nome"), "Victor");
			assertEquals(facada.getInfoFuncionario(matricula, "Cargo"), "Diretor Geral");
			assertEquals(facada.getInfoFuncionario(matricula, "Data"), "1997-10-03");

			// Cadastra Funcionario
			String medico1 = facada.cadastraFuncionario("Vinicius", "medico", "05/04/1998");
			String medico2 = facada.cadastraFuncionario("Gerson", "medico", "27/12/1992");
			String tecnico1 = facada.cadastraFuncionario("Gabriel", "tecnico administrativo", "17/05/1997");
			String tecnico2 = facada.cadastraFuncionario("Mattheus", "tecnico administrativo", "12/09/1998");

			// Exceptions de Funcionario
			try {
				facada.cadastraFuncionario("", "medico", "05/04/1998");
				fail();
			} catch (Exception e) {
				assertEquals("Erro no cadastro de funcionario. Nome do funcionario nao pode ser vazio.",
						e.getMessage());
			}

			try {
				facada.cadastraFuncionario("Vinicius", "medico", "35/17/3780");
				fail();
			} catch (Exception e) {
				assertEquals("Erro no cadastro de funcionario. Data invalida.", e.getMessage());
			}

			try {
				facada.cadastraFuncionario("Vinicius", "", "05/04/1998");
				fail();
			} catch (Exception e) {
				assertEquals("Erro no cadastro de funcionario. Nome do cargo nao pode ser vazio.", e.getMessage());
			}

			try {
				facada.cadastraFuncionario("Vinicius", "secretario", "05/04/1998");
				fail();
			} catch (Exception e) {
				assertEquals("Erro no cadastro de funcionario. Cargo invalido.", e.getMessage());
			}

			// GetInfoFuncionario
			assertEquals(facada.getInfoFuncionario(medico1, "Nome"), "Vinicius");
			assertEquals(facada.getInfoFuncionario(medico1, "Cargo"), "medico");
			assertEquals(facada.getInfoFuncionario(medico1, "Data"), "1998-04-05");
			assertEquals(facada.getInfoFuncionario(medico2, "Nome"), "Gerson");
			assertEquals(facada.getInfoFuncionario(medico2, "Cargo"), "medico");
			assertEquals(facada.getInfoFuncionario(medico2, "Data"), "1992-12-27");
			assertEquals(facada.getInfoFuncionario(tecnico1, "Nome"), "Gabriel");
			assertEquals(facada.getInfoFuncionario(tecnico1, "Cargo"), "tecnico administrativo");
			assertEquals(facada.getInfoFuncionario(tecnico1, "Data"), "1997-05-17");
			assertEquals(facada.getInfoFuncionario(tecnico2, "Nome"), "Mattheus");
			assertEquals(facada.getInfoFuncionario(tecnico2, "Cargo"), "tecnico administrativo");
			assertEquals(facada.getInfoFuncionario(tecnico2, "Data"), "1998-09-12");

			// Exceptions de GetInfoFuncionario

			try {
				facada.getInfoFuncionario(medico1, "Senha");
				fail();
			} catch (Exception e) {
				assertEquals("Erro na consulta de funcionario. A senha do funcionario eh protegida.", e.getMessage());
			}

			try {
				facada.getInfoFuncionario(medico2, "Senha");
				fail();
			} catch (Exception e) {
				assertEquals("Erro na consulta de funcionario. A senha do funcionario eh protegida.", e.getMessage());
			}

			try {
				facada.getInfoFuncionario(tecnico1, "Senha");
				fail();
			} catch (Exception e) {
				assertEquals("Erro na consulta de funcionario. A senha do funcionario eh protegida.", e.getMessage());
			}

			try {
				facada.getInfoFuncionario(tecnico2, "Senha");
				fail();
			} catch (Exception e) {
				assertEquals("Erro na consulta de funcionario. A senha do funcionario eh protegida.", e.getMessage());
			}

			// Logout e Fecha Sistema

			try {
				facada.fechaSistema();
				fail();
			} catch (Exception e) {
				assertEquals("Nao foi possivel fechar o sistema. Um funcionario ainda esta logado: Victor.",
						e.getMessage());
			}

			facada.logout();
			facada.fechaSistema();

			/**
			 * Testes do Caso 2
			 */

			// Excluir Funcionario

			facada.excluiFuncionario("12016002", "19971201");

			// Exceptions de Excluir Funcionario

			try {
				facada.excluiFuncionario("12016999", "19971201");
				fail();
			} catch (Exception e) {
				assertEquals("Erro ao excluir funcionario. Funcionario nao cadastrado.", e.getMessage());
			}

			try {
				facada.excluiFuncionario("djeneogc", "19971201");
				fail();
			} catch (Exception e) {
				assertEquals("Erro ao excluir funcionario. A matricula nao segue o padrao.", e.getMessage());
			}

			try {
				facada.excluiFuncionario("12016003", "fneifejff");
				fail();
			} catch (Exception e) {
				assertEquals("Erro ao excluir funcionario. Senha invalida.", e.getMessage());
			}

			// Modificacao de Funcionarios

			facada.atualizaInfoFuncionario("12016003", "Nome", "Fabio");
			facada.atualizaInfoFuncionario("12016003", "Data", "12/12/2001");
			assertEquals(facada.getInfoFuncionario("12016003", "Nome"), "Fabio");
			assertEquals(facada.getInfoFuncionario("12016003", "Data"), "12-12-2001");

			// Exceptions da Modificacao de Funcionarios

			try {
				facada.atualizaInfoFuncionario("12016003", "Data", "35/27/4006");
				fail();
			} catch (Exception e) {
				assertEquals("Erro ao atualizar funcionario. Data invalida.", e.getMessage());
			}

			try {
				facada.atualizaInfoFuncionario("12016003", "Nome", "");
				fail();
			} catch (Exception e) {
				assertEquals("Erro ao atualizar funcionario. Nome do funcionario nao pode ser vazio.", e.getMessage());
			}

			/**
			 * Testes do Caso 3
			 */

			// Cadastro de Pacientes

			facada.cadastraPaciente("Jean", "10/03/1974", 78.00, "masculino", "feminino", "O+");
			facada.cadastraPaciente("Jair", "21/03/1955", 81.00, "masculino", "masculino", "AB+");
			facada.cadastraPaciente("Rebecca", "30/06/2000", 58.00, "feminino", "feminino", "A+");

			assertEquals(facada.getInfoPaciente("Jean", "Nome"), "Jean");
			assertEquals(facada.getInfoPaciente("Jean", "Data"), "10-03-1974");
			assertEquals(facada.getInfoPaciente("Jean", "Peso"), 78.00);
			assertEquals(facada.getInfoPaciente("Jean", "Sexo"), "masculino");
			assertEquals(facada.getInfoPaciente("Jean", "Genero"), "feminino");
			assertEquals(facada.getInfoPaciente("Jean", "TipoSanguineo"), "O+");

			// Exceptions do Cadastro de Pacientes

			try {
				facada.cadastraPaciente("", "10/03/1974", 78.00, "masculino", "feminino", "O+");
				fail();
			} catch (Exception e) {
				assertEquals("Nao foi possivel cadastrar o paciente. Nome do paciente nao pode ser vazio.",
						e.getMessage());
			}

			try {
				facada.cadastraPaciente("Jean", "10/03/1974", 78.00, "masculino", "feminino", "M-");
				fail();
			} catch (Exception e) {
				assertEquals("Nao foi possivel cadastrar o paciente. Tipo sanguineo invalido.", e.getMessage());
			}

			try {
				facada.cadastraPaciente("Jean", "10/03/1974", -5.00, "masculino", "feminino", "O+");
				fail();
			} catch (Exception e) {
				assertEquals("Nao foi possivel cadastrar o paciente. Peso do paciente nao pode ser negativo.",
						e.getMessage());
			}

			try {
				facada.cadastraPaciente("Jean", "42/13/3089", 78.00, "masculino", "feminino", "O+");
				fail();
			} catch (Exception e) {
				assertEquals("Nao foi possivel cadastrar o paciente. Data invalida.", e.getMessage());
			}

			try {
				facada.cadastraPaciente("Jean", "10/03/1974", 78.00, "masculino", "feminino", "O+");
				fail();
			} catch (Exception e) {
				assertEquals("Nao foi possivel cadastrar o paciente. Paciente ja cadastrado.", e.getMessage());
			}

			/**
			 * Testes do Caso 4
			 */

			// Cadastro de Medicamentos

			facada.cadastraMedicamento("Histamin", "referencia", 35.00, 52, "antialergico");
			facada.cadastraMedicamento("Morfina", "generico", 98.00, 35, "analgesico");
			facada.cadastraMedicamento("Penicilina", "referencia", 76.00, 135, "antibiotico");

			assertEquals(facada.getInfoMedicamento("tipo", "Morfina"), "generico");
			assertEquals(facada.getInfoMedicamento("preco", "Morfina"), 98.00);
			assertEquals(facada.getInfoMedicamento("quantidade", "Morfina"), 35);
			assertEquals(facada.getInfoMedicamento("categorias", "Morfina"), "analgesico");

			// Exceptions do Cadastro de Medicamentos

			try {
				facada.cadastraMedicamento("", "referencia", 35.00, 52, "antialergico");
				fail();
			} catch (Exception e) {
				assertEquals("Erro no cadastro de medicamento. Nome do medicamento nao pode ser vazio.",
						e.getMessage());
			}

			try {
				facada.cadastraMedicamento("Histamin", "referencia", -8.00, 52, "antialergico");
				fail();
			} catch (Exception e) {
				assertEquals("Erro no cadastro de medicamento. Preco do medicamento nao pode ser negativo.",
						e.getMessage());
			}

			try {
				facada.cadastraMedicamento("Histamin", "referencia", 35.00, -52, "antialergico");
				fail();
			} catch (Exception e) {
				assertEquals("Erro no cadastro de medicamento. Quantidade do medicamento nao pode ser negativo.",
						e.getMessage());
			}

			// Atualiza Medicamento

			facada.atualizaMedicamento("Histamin", "preco", "40.00");
			facada.atualizaMedicamento("Histamin", "quantidade", "65");

			try {
				facada.atualizaMedicamento("Histamin", "nome", "Nefienfein");
				fail();
			} catch (Exception e) {
				assertEquals("Erro ao atualizar medicamento. Nome do medicamento nao pode ser alterado.",
						e.getMessage());
			}

			try {
				facada.atualizaMedicamento("Histamin", "tipo", "generico");
				fail();
			} catch (Exception e) {
				assertEquals("Erro ao atualizar medicamento. Tipo do medicamento nao pode ser alterado.",
						e.getMessage());
			}

			try {
				facada.atualizaMedicamento("Viagra", "preco", "50.00");
				fail();
			} catch (Exception e) {
				assertEquals("Erro ao atualizar medicamento. Medicamento nao cadastrado.", e.getMessage());
			}

			// Busca de medicamentos por categoria

			assertEquals(facada.consultaMedCategoria("antialergico"), "Histamin");
			assertEquals(facada.consultaMedCategoria("antibiotico"), "Penicilina");

			// Exceptions da busca de medicamentos por categoria

			try {
				facada.consultaMedCategoria("antiinflamatorio");
				fail();
			} catch (Exception e) {
				assertEquals("Erro na consulta de medicamentos. Nao ha remedios cadastrados nessa categoria.",
						e.getMessage());
			}

			try {
				facada.consultaMedCategoria("antiacaro");
				fail();
			} catch (Exception e) {
				assertEquals("Erro na consulta de medicamentos. Categoria invalida.", e.getMessage());
			}

			// Busca de medicamentos por nome

			assertEquals(
					"Medicamento de Refer�ncia: Histamin - Preco: R$ 40,00 - Disponivel: 65 - Categorias: antialergico",
					facada.consultaMedNome("Histamin"));

			// Exceptions da busca de medicamentos por nome

			try {
				facada.consultaMedNome("Dorflex");
				fail();
			} catch (Exception e) {
				assertEquals("Erro na consulta de medicamentos. Medicamento nao cadastrado.", e.getMessage());
			}

			// Busca por todos os medicamentos

			assertEquals("Histamin,Morfina,Penicilina", facada.getEstoqueFarmacia("alfabetica"));
			assertEquals("Histamin,Penicilina,Morfina", facada.getEstoqueFarmacia("preco"));

			// Exceptions da busca por todos os medicamentos

			try {
				facada.getEstoqueFarmacia("quantidade");
				fail();
			} catch (Exception e) {
				assertEquals("Erro na consulta de medicamentos. Tipo de ordenacao invalida.", e.getMessage());
			}

		} catch (Exception e) {
			fail();
		}
	}

}