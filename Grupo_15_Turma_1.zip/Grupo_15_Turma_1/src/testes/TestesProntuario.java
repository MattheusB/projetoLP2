package testes;

import static org.junit.Assert.*;
import pacientes.ControlleProntuario;

import org.junit.Test;

public class TestesProntuario {

	@Test
	public void prontuarioTest() throws Exception {
		
		ControlleProntuario prontuario = new ControlleProntuario();
		
		// Cadastro de Pacientes
		
		prontuario.criarPaciente("Jean", "10/03/1974", 78.00, "masculino", "feminino", "O+");
		prontuario.criarPaciente("Jair", "21/03/1955", 81.00, "masculino", "masculino", "AB+");
		prontuario.criarPaciente("Rebecca", "30/06/2000", 58.00, "feminino", "feminino", "A+");
		
		assertEquals(prontuario.getInfoPaciente("Jean", "Nome"), "Jean");
		assertEquals(prontuario.getInfoPaciente("Jean", "Data"), "10-03-1974");
		assertEquals(prontuario.getInfoPaciente("Jean", "Peso"), 78.00);
		assertEquals(prontuario.getInfoPaciente("Jean", "Sexo"), "masculino");
		assertEquals(prontuario.getInfoPaciente("Jean", "Genero"), "feminino");
		assertEquals(prontuario.getInfoPaciente("Jean", "TipoSanguineo"), "O+");
		
		// Exceptions do Cadastro de Pacientes
		
		try {
			prontuario.criarPaciente("", "10/03/1974", 78.00, "masculino", "feminino", "O+");
			fail(); 
		} catch (Exception e) {
			assertEquals("Nao foi possivel cadastrar o paciente. Nome do paciente nao pode ser vazio.",
					e.getMessage());
		}
		
		try {
			prontuario.criarPaciente("Jean", "10/03/1974", 78.00, "masculino", "feminino", "M-");
			fail(); 
		} catch (Exception e) {
			assertEquals("Nao foi possivel cadastrar o paciente. Tipo sanguineo invalido.",
					e.getMessage());
		}
		
		try {
			prontuario.criarPaciente("Jean", "10/03/1974", -5.00, "masculino", "feminino", "O+");
			fail(); 
		} catch (Exception e) {
			assertEquals("Nao foi possivel cadastrar o paciente. Peso do paciente nao pode ser negativo.",
					e.getMessage());
		}
		
		try {
			prontuario.criarPaciente("Jean", "42/13/3089", 78.00, "masculino", "feminino", "O+");
			fail(); 
		} catch (Exception e) {
			assertEquals("Nao foi possivel cadastrar o paciente. Data invalida.",
					e.getMessage());
		}
		
		try {
			prontuario.criarPaciente("Jean", "10/03/1974", 78.00, "masculino", "feminino", "O+");
			fail(); 
		} catch (Exception e) {
			assertEquals("Nao foi possivel cadastrar o paciente. Paciente ja cadastrado.",
					e.getMessage());
		}
		
	}

}
