package exceptions;

/**
 * Excecao "Fecha Sistema"
 * A exception eh chamada quando ocorre uma tentativa de fechar sistema quando um determinado funcionario 
 * ainda esta logado. Nao eh possivel fechar o sistema ate que todos os funcionarios desloguem.
 */

public class FechaSistemaException extends Exception {
	public FechaSistemaException(String mensagem) {
		super("Nao foi possivel fechar o sistema. Um funcionario ainda esta logado: " + mensagem + ".");
	}

	public FechaSistemaException() {
		super("Nao foi possivel fechar o sistema. Um funcionario ainda esta logado.");
	}

}
