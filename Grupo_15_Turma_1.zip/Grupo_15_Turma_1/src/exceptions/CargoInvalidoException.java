package exceptions;

public class CargoInvalidoException extends Exception{
	public CargoInvalidoException(String mensagem){
		super("Erro no cadastro de funcionario." + mensagem);
	}
	
	public CargoInvalidoException(){
		super("Erro no cadastro de funcionario. Nome do cargo nao pode ser vazio.");
	}

}
