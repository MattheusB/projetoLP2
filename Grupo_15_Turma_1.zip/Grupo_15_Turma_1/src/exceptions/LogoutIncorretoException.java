package exceptions;

/**
 * Excecao "Login Incorreto"
 * A exception eh chamada quando nao foi possivel realizar um logout (sa�da) do funcionario.
 */

public class LogoutIncorretoException extends Exception{
	public LogoutIncorretoException(String mensagem){
		super("Nao foi possivel realizar o logout. " + mensagem);
	}
	
	public LogoutIncorretoException(){
		super("Nao foi possivel realizar o logout. Nao ha um funcionario logado.");
	}
}
