package exceptions;

/**
 * Excecao "Cadastra Medicamento Incorreto"
 * A exception eh chamada quando ocorre um erro ao cadastrar medicamento pelo fato do funcionario nao 
 * ter permissoes de criar medicamentos (tecnico administrativo).
 */

public class CadastraMedicamentoIncorretoException extends Exception {
	public CadastraMedicamentoIncorretoException(String mensagem) {
		super("Erro no cadastro de medicamento. O funcionario " + mensagem
				+ " nao tem permissao para cadastrar medicamentos.");
	}

	public CadastraMedicamentoIncorretoException() {
		super("Erro no cadastro de medicamento.");
	}
}
