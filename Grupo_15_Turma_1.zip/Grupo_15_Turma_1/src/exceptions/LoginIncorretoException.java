package exceptions;

public class LoginIncorretoException extends Exception{
	public LoginIncorretoException(String mensagem){
		super("Nao foi possivel realizar o login. " + mensagem);
	}
	
	public LoginIncorretoException(){
		super("Nao foi possivel realizar o login.");
	}

}
