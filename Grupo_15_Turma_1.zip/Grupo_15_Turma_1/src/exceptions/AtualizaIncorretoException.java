package exceptions;

/**
 * Excecao "Atualiza Funcionario Incorreto"
 * A exception eh chamada quando ocorre um erro ao atualizar as informacoes de um funcionario.
 */

public class AtualizaIncorretoException extends Exception {
	public AtualizaIncorretoException(String mensagem) {
		super("Erro ao atualizar funcionario. " + mensagem);
	}

	public AtualizaIncorretoException() {
		super("Erro ao atualizar funcionario.");
	}
}

