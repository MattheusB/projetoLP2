package exceptions;

/**
 * Excecao "Consulta Medicamento"
 * A exception eh chamada quando ocorre um erro na ordenacao escolhida para consultar os medicamentos.
 */

public class ConsultaMedicamentoIncorretoException extends Exception{
	public ConsultaMedicamentoIncorretoException(String mensagem){
		super("Erro na consulta de medicamentos. " + mensagem);
	}
	
	public ConsultaMedicamentoIncorretoException(){
		super("Erro na consulta de medicamentos.");
	}
}
