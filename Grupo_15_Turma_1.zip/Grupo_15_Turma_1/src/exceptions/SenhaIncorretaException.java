package exceptions;

/**
 * Excecao "Nome Invalido"
 * A exception eh chamada quando h� uma tentativa de cadastro do funcionario com uma senha sem estar
 * de acordo com as especifica��es (8 - 12 caracteres).
 */

public class SenhaIncorretaException extends Exception{
	public SenhaIncorretaException(String mensagem){
		super("Tamanho da senha deve estar entre " + mensagem);
	}
	
	public SenhaIncorretaException(){
		super("Tamanho da senha deve estar entre 8 - 12 caracteres.");
	}

}
