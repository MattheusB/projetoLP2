package exceptions;

public class ConsultaIncorretaException extends Exception {

	public ConsultaIncorretaException(String mensagem) {
		super("Erro na consulta de funcionario. " + mensagem);
	}

	public ConsultaIncorretaException() {
		super("Erro na consulta de funcionario.");
	}

}
