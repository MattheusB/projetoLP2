package exceptions;

/**
 * Excecao "Tamanho do Nome Incorreto"
 * A exception eh chamada quando h� uma tentativa de cadastro do funcionario com um nome sem estar
 * de acordo com as especifica��es (maximo de 16 caracteres).
 */

public class TamanhoNomeIncorretoException extends Exception{
	public TamanhoNomeIncorretoException(String mensagem){
		super("Tamanho maximo e 16 caracteres.");
	}
	
	public TamanhoNomeIncorretoException(){
		super("Tamanho maximo e ");
	}

}
