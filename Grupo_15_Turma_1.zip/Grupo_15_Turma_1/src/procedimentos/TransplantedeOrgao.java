package procedimentos;

import pacientes.Prontuario;

/**
 * Classe que tem por objetivo transplantar um orgao.
 */
public class TransplantedeOrgao extends Procedimentos {

	@Override
	public void realizaCirurgia(Prontuario prontuario, double valormedicamento) {
		this.setPontos(160);
		this.setValor(12500);
		this.setPaciente(prontuario.getPaciente());

		prontuario.addProcedimento(Procedimento.TRANSPLANTEDEORGAOS);
		this.getNovo().descontoServico(this.getValor() + valormedicamento);
		this.getNovo().ceditobonus(this.getPontos());

	}

}
