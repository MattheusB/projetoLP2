package procedimentos;

import java.time.LocalDate;

import pacientes.Paciente;

/**
 * Classe que tem por objetivo transplantar um orgao.
 */
public class TransplantedeOrgao extends Procedimentos {
	private static final long serialVersionUID = 6041911250662086464L;
	private String orgao;

	public TransplantedeOrgao(Paciente paciente, double valormedicamento, String nomeMedico, LocalDate data,
			String orgao) {
		super(12500, paciente, 160, nomeMedico, data);
		this.orgao = orgao;
		realizaCirurgia(valormedicamento);
	}

	@Override
	public void realizaCirurgia(double valormedicamento) {

		this.getPaciente().descontoServico(this.getValor() + valormedicamento);
		this.getPaciente().ceditobonus(this.getPontos());

	}

	public String getOrgao() {
		return orgao;
	}

	public String toString() {
		return "--> Transplante de Orgaos:\n" + "....... " + "Data: " + this.getData() + " Medico: "
				+ this.getNomeMedico() + "\n" + "....... " + "Orgao transplantado: " + this.orgao;
	}

}
