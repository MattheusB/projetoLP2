package procedimentos;

/**
 * ENUM que tem por objetivo enumerar os procedimentos.
 */
public enum Procedimento {
	CONSULTACLINICA,CIRUGIABARIATRICA,REDESIGUINACAOSEXUAL,TRANSPLANTEDEORGAOS;

}
