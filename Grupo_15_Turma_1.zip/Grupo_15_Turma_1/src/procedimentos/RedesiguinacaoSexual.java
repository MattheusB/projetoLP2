package procedimentos;

import pacientes.Prontuario;

/**
 * Classe que tem por objetivo mudar o sexo do paciente.
 */

public class RedesiguinacaoSexual extends Procedimentos {

	@Override
	public void realizaCirurgia(Prontuario prontuario, double valormedicamento) {
		this.setPontos(130);
		this.setValor(9300);
		this.setPaciente(prontuario.getPaciente());
		this.getNovo().alteraGenero();
		prontuario.addProcedimento(Procedimento.REDESIGUINACAOSEXUAL);
		this.getNovo().descontoServico(this.getValor() + valormedicamento);
		this.getNovo().ceditobonus(this.getPontos());

	}

}
