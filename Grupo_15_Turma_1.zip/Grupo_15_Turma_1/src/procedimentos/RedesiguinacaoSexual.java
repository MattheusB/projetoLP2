package procedimentos;

import java.time.LocalDate;

import pacientes.Paciente;

/**
 * Classe que tem por objetivo mudar o sexo do paciente.
 */

public class RedesiguinacaoSexual extends Procedimentos {
	private static final long serialVersionUID = -3505405197745035181L;

	public RedesiguinacaoSexual(Paciente paciente, double valormedicamento, String nomeMedico, LocalDate data) {
		super(9300, paciente, 130, nomeMedico, data);
		realizaCirurgia(valormedicamento);
	}

	@Override
	public void realizaCirurgia(double valormedicamento) {

		this.getPaciente().alteraGenero();

		this.getPaciente().descontoServico(this.getValor() + valormedicamento);
		this.getPaciente().ceditobonus(this.getPontos());

	}

	public String toString() {
		return "--> Redesignacao sexual:\n" + "....... " + "Data: " + this.getData() + " Medico: "
				+ this.getNomeMedico();
	}

}
