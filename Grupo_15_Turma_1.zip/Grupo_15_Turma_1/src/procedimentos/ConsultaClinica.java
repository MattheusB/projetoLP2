package procedimentos;

import pacientes.Prontuario;

/**
 * Classe que tem por objetivo realizar uma consulta clinica.
 */
public class ConsultaClinica extends Procedimentos {

	public ConsultaClinica() {
	}

	@Override
	public void realizaCirurgia(Prontuario prontuario, double valormedicamento) {
		this.setPontos(50);
		this.setValor(350);
		this.setPaciente(prontuario.getPaciente());

		prontuario.addProcedimento(Procedimento.CONSULTACLINICA);
		this.getNovo().descontoServico(this.getValor() + valormedicamento);
		this.getNovo().ceditobonus(this.getPontos());

	}
}
