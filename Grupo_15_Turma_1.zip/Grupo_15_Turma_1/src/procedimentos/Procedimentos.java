package procedimentos;


import pacientes.Paciente;
import pacientes.Prontuario;
/**
 * Classe que tem por funcao principal realizar cirurgia.
 */

public class Procedimentos {
	private double valor;
	private Paciente novo;
	private int pontos;
	
	public void realizaCirurgia(Prontuario prontuario,double valormedicamento){
		this.valor = 0;
		this.pontos = 0;
	}
	
	public void setValor(double valor){
		this.valor = valor;
	}
	
	public double getValor(){
		return this.valor;
	}
	
	public void setPontos(int pontos){
		this.pontos = pontos;
	}
	
	public int getPontos(){
		return this.pontos;
	}
	
	public Paciente getNovo(){
		return this.novo;
	}
	
	public void setPaciente(Paciente paciente){
		this.novo = paciente;
	}
}
