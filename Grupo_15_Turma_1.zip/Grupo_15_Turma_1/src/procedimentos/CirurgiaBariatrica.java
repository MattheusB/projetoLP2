package procedimentos;

import pacientes.Prontuario;

/**
 * Classe que tem por objetivo realizar uma cirurgia Bariatrica.
 */
public class CirurgiaBariatrica extends Procedimentos {
	public CirurgiaBariatrica() {
	}

	@Override
	public void realizaCirurgia(Prontuario prontuario, double valormedicamento) {
		this.setPontos(100);
		this.setValor(7600);
		this.setPaciente(prontuario.getPaciente());
		Double novopeso = this.getNovo().getPeso();

		novopeso -= novopeso * 0.10;
		this.getNovo().setPeso(novopeso);
		prontuario.addProcedimento(Procedimento.CIRUGIABARIATRICA);
		this.getNovo().descontoServico(this.getValor() + valormedicamento);
		this.getNovo().ceditobonus(this.getPontos());

	}

}
