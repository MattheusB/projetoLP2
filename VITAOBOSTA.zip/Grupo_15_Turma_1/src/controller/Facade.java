package controller;

import java.util.UUID;

import easyaccept.EasyAccept;
import pacientes.Paciente;
import pacientes.Prontuario;

public class Facade {

	public static void main(String[] args) {
		args = new String[] {"controller.Facade", "test/usecase_1.txt","test/usecase_2.txt","test/usecase_3.txt","test/usecase_4.txt","test/usecase_5.txt","test/usecase_6.txt","test/usecase_7.txt"}; //separe cada script de teste por virgula.
		EasyAccept.main(args);
	}
	public void iniciaSistema(){

	}
	Controller controller = new Controller();

	public String liberaSistema(String chave, String nome, String dataNascimento) throws Exception {
		return controller.liberaSistema(chave, nome, dataNascimento);
	}

	public String login(String matricula, String senha) throws Exception {
		return controller.login(matricula, senha);
	}

	public String cadastraFuncionario(String nome, String cargo, String dataNascimento) throws Exception {
		return controller.cadastraFuncionario(nome, cargo, dataNascimento);
	}
	
	public String getInfoFuncionario(String matricula, String atributo) throws Exception{
		return controller.getInfoFuncionario(matricula, atributo);
	}
	public void logout() throws Exception{
		controller.logout();
	}
	
	public void fechaSistema() throws Exception{
		controller.fechaSistema();
	}
	
	public String cadastraPaciente(String nome, String data, double peso,String sexo, String genero,String tipoSanguineo)throws Exception{
		return controller.cadastraPaciente(nome, data, peso, sexo, genero, tipoSanguineo);
	}
	
	public String getInfoPaciente(String nome, String atributo)throws Exception{
		return controller.getInfoPaciente(nome, atributo);
	}
	
	public String getProntuario(int posicao)throws Exception{
		return controller.getProntuario(posicao);
	}

	// Metodo altera senha que primeiramente verifica a matricula e se for igual a matricula do usuario
	// que est� usando o sistema ele ter� acesso a parte de alterar senha;
	public void atualizaSenha(String senha, String novaSenha) throws Exception{
		controller.atualizaSenha(senha, novaSenha);	
	}

	// Metodo que altera o nome;
	public void alteraNome(String novoNome, String matricula) throws Exception {
		controller.alteraNome(novoNome, matricula);
	}

	// Metodo que altera a data de nascimento;
	public void alteraData(String data, String matricula) throws Exception {
		controller.alteraData(data, matricula);
	}

	// Metodo que Exclui funcionario;
	// Como j� foi dito acima, "funcionarios" precisa de uma parte de brito;
	public void excluiFuncionario(String matricula, String senhaDiretor) throws Exception {
		controller.excluiFuncionario(matricula, senhaDiretor);
	}

	// Metodo que verifica se a nova senha que o usuario ir� criar est� v�lida;
	public boolean verificaSenha(String senha) throws Exception{
		return controller.verificaSenha(senha);
	}

	// Metodo que verifica se o novo nome que o usuario ir� criar est� v�lida;
	public boolean verificaNome(String nome)throws Exception{
		return controller.verificaNome(nome);
	}
	
	public void atualizaInfoFuncionario(String atributo, String novoValor) throws Exception {
		controller.atualizaInfoFuncionario(atributo, novoValor);
	}
	
	public void atualizaInfoFuncionario(String matricula,String atributo, String novoValor) throws Exception {
		controller.atualizaInfoFuncionario(matricula,atributo, novoValor);
	}
	
	public String cadastraMedicamento(String nome,String tipo, double preco, int quantidade, String categorias)throws Exception{
		return this.controller.cadastraMedicamento(nome, tipo, preco, quantidade, categorias);
	}
	
	public String getInfoMedicamento(String atributo,String medica)throws Exception{
		return this.controller.getInfoMedicamento(atributo, medica);
	}
	
	public void atualizaMedicamento (String nome, String atributo, String novovalor) throws Exception{
		this.controller.atualizaMedicamento(nome, atributo, novovalor);
	}
	
	public String buscaPorCategoria(String categoria)throws Exception {
		return this.controller.buscaPorCategoria(categoria);
	}
	
	public String getEstoqueFarmacia(String ordenacao) throws Exception{
		return this.controller.getEstoqueFarmacia(ordenacao);
	}
	
	public String consultaMedNome(String nome)throws Exception{
		return this.controller.consultaMedNome(nome);
	}
	
	public String consultaMedCategoria(String categoria)throws Exception{
		return this.controller.consultaMedCategoria(categoria);
	}
	
	public void  cadastraOrgao(String nome, String tipoSanguineo) throws Exception{
		try{
			this.controller.cadastraOrgao(nome, tipoSanguineo);
		}catch(Exception e){
			throw new Exception("O banco de orgaos apresentou um erro." + e.getMessage());
		}
		
	}
	
	public String buscaOrgPorSangue(String tipoSanguineo)throws Exception{
		try{
			return this.controller.buscaOrgPorSangue(tipoSanguineo);
		}catch(Exception e){
			throw new Exception("O banco de orgaos apresentou um erro."+e.getMessage());
			
		}
	}
	
	public String buscaOrgPorNome(String nome) throws Exception{
		try{
			return this.controller.buscaOrgPorNome(nome);
			
		}catch(Exception e){
			throw new Exception("O banco de orgaos apresentou um erro." + e.getMessage());
			
		}
	}
	
	public String buscaOrgao(String nome,String tipoSanguineo) throws Exception{
		try{
			return this.controller.buscaOrgao(nome, tipoSanguineo);
		}catch(Exception e){
			throw new Exception("O banco de orgaos apresentou um erro." + e.getMessage());
		}
	}
	
	public void retiraOrgao(String nome,String tipoSanguineo) throws Exception{
		try{
			this.controller.retiraOrgao(nome, tipoSanguineo);
		}catch(Exception e){
			throw new Exception("Erro na retirada de orgaos." + e.getMessage());
		}
	}
	
	public String qtdOrgaos(String nome)throws Exception{
		try{
			return this.controller.qtdOrgaos(nome);
			
		}catch(Exception e){
			throw new Exception("O banco de orgaos apresentou um erro." + e.getMessage());
		}
	}
	
	public String totalOrgaosDisponiveis(){
		return this.controller.totalOrgaosDisponiveis();
	}
	
	public String getPacienteID(String nome)throws Exception{
		try{
			return this.controller.getIdPaciente(nome);
		}catch(Exception e){
			throw new Exception(e.getMessage());
		}
	}
	
	public void realizaProcedimento(String procedimento,String nome,String medicamentos)throws Exception{
		try{
			this.controller.realizaProcedimento(procedimento, nome, medicamentos);
		}catch(Exception e){
			throw new Exception("Erro na realizacao de procedimentos." + e.getMessage());
		}
	}
	
	public void realizaProcedimento(String procedimento,String nome,String orgao,String medicamentos)throws Exception{
		try{
			
			this.controller.realizaProcedimento(procedimento, nome,orgao, medicamentos);
		}catch(Exception e){
			throw new Exception("Erro na realizacao de procedimentos." + e.getMessage());
		}
	}
	
	public String getTotalProcedimento(String nome){
		return this.controller.getTotalProcedimento(nome);
	}
	
	public String getGastosPaciente(String id){
		return this.controller.getGastosPaciente(id);
	}
	
	public String getPontosFidelidade(String id){
		return this.controller.getPontosFidelidade(id);
	}
	
	public void realizaProcedimento(String procedimento,String id)throws Exception{
		try{
			this.controller.realizaProcedimento(procedimento,id);
		}catch(Exception e){
			throw new Exception("Erro na realizacao de procedimentos." + e.getMessage());
		}
		
	}
	

	
	

}
