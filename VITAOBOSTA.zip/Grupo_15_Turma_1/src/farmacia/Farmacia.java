package farmacia;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
/**
 * Classe "Farmacia"
 * 
 * A classe Farm�cia ser� respons�vel por organizar, criar e armazenar medicamentos num estoque.
 * Ser� ela que conter� os diversos m�todos do sistema.
 */

public class Farmacia {
	private ArrayList<Medicamento> estoque;
	private FactoryMedicamento fabrica;
	public Farmacia() {
		this.fabrica = new FactoryMedicamento();
		this.estoque = new ArrayList<Medicamento>();
	}
	
	/**
	 * Metodo que cria medicamento;
	 * @param nome Nome do medicamento;
	 * @param preco Preco do medicamento;
	 * @param quantidade Quantidade do medicamento; 
	 */

	public String criaMedicamento (String nome,String tipo, double preco, int quantidade, String categoria)throws Exception {
		
		Medicamento medicamento = null;
		String[] categoriaa = categoria.split(",");
		LinkedList<Categoria> categorias = new LinkedList<Categoria>();
		for(int i = 0; i < categoriaa.length; i++){
			
			Categoria nova = verificaCategoria(categoriaa[i]);
			
			categorias.add(nova);
		}
		
		
		medicamento = fabrica.criaMedicamento(nome,tipo, preco, quantidade,  categorias);
		
		estoque.add(medicamento);
		
		
		
		return medicamento.getNome();
	}
	
	/**
	 * Metodo que adiciona categoria ao medicamento;
	 * @param nome Nome do medicamento;
	 * @param categoria Categoria do medicamento;
	 * @throws Exception 
	 */

	public void adicionaCategoria (String nome, String categoria) throws Exception {
		Medicamento novo = verificaMedicamento(nome);
		Categoria categorias = verificaCategoria(categoria);
		novo.addCategoria(categorias);
	}
	
	/**
	 * Metodo que tem a funcao de alterar o preco do medicamento;
	 * @param nome Nome do medicamento;
	 * @param preco Preco do medicamento;
	 * @throws Exception
	 */
	public void alteraPreco(String nome,double preco)throws Exception{
		Medicamento medicamento = verificaMedicamento(nome);
		medicamento.alterPreco(preco);
	}
	
	/**
	 * Metodo que tem a funcao de buscar um medicamento pelo nome;
	 * @param nome Nome do medicamento;
	 * @return Retorna o medicamento;
	 * @throws Exception
	 */

	public String buscaPorNome(String nome)throws Exception {
		Medicamento novo = verificaMedicamento(nome);
		if(novo == null){
			throw new Exception("Erro na consulta de medicamentos. Medicamento nao cadastrado.");
		}
		return novo.toString();
	}
	
	/**
	 * Metodo que tem a funcao de buscar um remedio por categorias;
	 * @param categoria Categoria
	 * @return Uma lista de medicamentos;
	 * @throws Exception
	 */
	public ArrayList<Medicamento> buscaPorCategoria(String categoria)throws Exception {
		ArrayList<Medicamento> listaMedicamentos = new ArrayList<Medicamento> ();
		Categoria categorias = verificaCategoria(categoria);
		for(Medicamento novomedicamento : estoque){
				if(novomedicamento.verificaCategoria(categorias)){
					listaMedicamentos.add(novomedicamento);
				}
			}
		
		if (listaMedicamentos.size() == 0){
			throw new Exception("Erro na consulta de medicamentos. Nao ha remedios cadastrados nessa categoria.");
		}
		Collections.sort(listaMedicamentos);
		return listaMedicamentos;
		}
	
	public boolean verificaMedicamentos(String medicamento) throws Exception{
		if(medicamento.trim().isEmpty()){
			throw new Exception(" Nome do medicamento nao pode ser vazio.");
		}
		
		String[] medicamentos = medicamento.split(",");
		
		for(int i = 0; i < medicamentos.length; i++){
			
			Medicamento medi = verificaMedicamento(medicamentos[i]);
			
			if(medi == null){
				
				throw new Exception(" Medicamento nao cadastrado.");
			}
		}
		
		return false;
	}
	
	public double calculaMedicamento(String medicamentos) throws Exception{
		double total = 0;
		String[] medicamento = medicamentos.split(",");
		for(int i = 0; i < medicamento.length; i++){
			Medicamento medi = verificaMedicamento(medicamento[i]);
			
			total += medi.getPreco();
			
		}
		
		return total;
		
	}
	
	
	

	public boolean atualizaMedicamento (String nome, String atributo, String novovalor) throws Exception {
		Medicamento novo = verificaMedicamento(nome);
		
		if(novo == null){
			throw new Exception("Erro ao atualizar medicamento. Medicamento nao cadastrado.");
		}
		if (atributo.equalsIgnoreCase("nome")) {
	     
	        throw new Exception("Erro ao atualizar medicamento. Nome do medicamento nao pode ser alterado.");
		}
	       
		if (atributo.equalsIgnoreCase("preco")) {
			if (novovalor.equals(novo.getPreco())) {
				throw new Exception("Erro ao atualizar medicamento. Preco do medicamento nao pode ser alterado.");
			}
			novo.calculaPreco(Double.parseDouble(novovalor));
			
			return true;
		}
		if (atributo.equalsIgnoreCase("quantidade")) {
			if (novovalor.equals(novo.getQuantidade())) {
				throw new Exception("Erro ao atualizar medicamento. Quantidade do medicamento nao pode ser alterada.");
			}
			novo.setQuantidade(Integer.parseInt(novovalor));
			return true;
		}
		if (atributo.equalsIgnoreCase("tipo")) {
			throw new Exception("Erro ao atualizar medicamento. Tipo do medicamento nao pode ser alterado.");
			
			}
		
		return false;
		 
	}
	

	
	public ArrayList<Medicamento> ordenaPorNome () {
		ComparaNome ordena = new ComparaNome();
		Collections.sort(estoque,ordena);
		return estoque;
	}
	
	/**
	 * Metodo que verifica um remedio por nome;
	 * @return Retorna o estoque ordenado;
	 */
	public String verificaRemedioPorNome(String nome)throws Exception{
		Medicamento remedio = verificaMedicamento(nome);
		
		if(remedio == null){
			throw new Exception("Erro na consulta de medicamentos. Medicamento nao cadastrado.");
		}
		return remedio.toString();
	}
	
	/**
	 * Metodo que verifica o medicamento pelo preco;
	 * @return Retorna o estoque ordenado;
	 */
	public ArrayList<Medicamento> verificaRemediosPorPreco () {
		Collections.sort(estoque);
		return estoque;
		
	}
	
	/**
	 * Metodo que verifica os medicamentos;
	 * @param nome Nome do medicamento;
	 * @return Retorna o medicamento se encontrado;
	 * @throws Exception
	 */

	private Medicamento verificaMedicamento(String nome)throws Exception{
		for (Medicamento novomedicamento: estoque) {
			if (novomedicamento.getNome().equalsIgnoreCase(nome)) {
				return novomedicamento;
			}
			}
		return null;
	}
	
	/**
	 * Metodo que verifica a categoria;
	 * @param categoria Categoria;
	 * @return Retorna a categoria;
	 * @throws Exception
	 */
	private Categoria verificaCategoria(String categoria) throws Exception{
		if (categoria.equalsIgnoreCase("Analgesico")) {
			return Categoria.ANALGESICO;
			
		}
		
		if (categoria.equalsIgnoreCase("Antibiotico")) {
			return Categoria.ANTIBIOTICO;
		}
		
		if (categoria.equalsIgnoreCase("Antiemetico")) {
			return Categoria.ANTIEMETICO;
		}
		
		if (categoria.equalsIgnoreCase("Antiinflamatorio")) {
			return Categoria.ANTIINFLAMATORIO;
		}
		
		if (categoria.equalsIgnoreCase("Antitermico")) {
			return Categoria.ANTITERMICO;
		}
		
		if (categoria.equalsIgnoreCase("Hormonal")) {
			return Categoria.HORMONAL;
		}
		
		throw new Exception("Erro na consulta de medicamentos. Categoria invalida.");
	}
	
	public String getInfoMedicamento(String atributo,String medica)throws Exception{
		Medicamento medi = verificaMedicamento(medica);
		if(atributo.equalsIgnoreCase("Tipo")){
			return medi.getTipo();
		}
		
		if(atributo.equalsIgnoreCase("Preco")){
			return String.valueOf(medi.getPreco());
		}
		
		if(atributo.equalsIgnoreCase("Quantidade")){
			return String.valueOf(medi.getQuantidade());
		}
		
		if(atributo.equalsIgnoreCase("categorias")){
			return medi.categoria();
		}
		
		return null;
	}
}