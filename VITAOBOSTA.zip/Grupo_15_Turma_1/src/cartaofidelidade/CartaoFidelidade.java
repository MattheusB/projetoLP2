package cartaofidelidade;

public interface CartaoFidelidade {
	
	double descontoservico(double valor);
	int creditobonus(int pontos);

}
