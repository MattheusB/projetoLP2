package cartaofidelidade;

public class CartaoPadrao implements CartaoFidelidade{

	@Override
	public double descontoservico(double valor) {
		
		return valor;
	}

	@Override
	public int creditobonus(int pontos) {
		
		return pontos;
	}

}
