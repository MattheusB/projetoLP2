package pacientes;

import java.util.ArrayList;
import java.util.UUID;

import procedimentos.Procedimento;

public class Prontuario implements Comparable<Prontuario> {
	private ArrayList<Procedimento> procedimentos;
	private Paciente paciente;
	
	
	public Prontuario(String nome, String dataNacimento, double peso,String sexo, String genero,String tipoSanguineo, UUID id)throws Exception{
		paciente = new Paciente(nome,dataNacimento,peso,sexo,genero,tipoSanguineo,id);
		this.procedimentos = new ArrayList<Procedimento>();
	}
	
	public void addProcedimento(Procedimento novo){
		this.procedimentos.add(novo);
	}
	
	public String getQuantidadeProcedimentos(){
		
		return String.valueOf(procedimentos.size());
	}
	
	public String getInfoPaciente(String atributo){
		
		
		if(atributo.equalsIgnoreCase("Nome")){
			
			return paciente.getNome();
		}
		
		if(atributo.equalsIgnoreCase("Data")){
			
			return String.valueOf(paciente.getDataDeNascimento());
		}
		
		if(atributo.equalsIgnoreCase("TipoSanguineo")){
			
			return paciente.getTipoSanguineo();
		}
		
		if(atributo.equalsIgnoreCase("Sexo")){
			
			return paciente.getSexo();
		}
		
		if(atributo.equalsIgnoreCase("Idade")){
			
			return String.valueOf(paciente.getIdade());
		}
		
		if(atributo.equalsIgnoreCase("Peso")){
			
			return String.valueOf(paciente.getPeso());
		}
		
		if(atributo.equalsIgnoreCase("Genero")){
			
			return paciente.getGenero();
		}
		
		return null;
	}
	
	public Paciente getPaciente(){
		return this.paciente;
	}

	@Override
	public int compareTo(Prontuario novo) {
		
		return this.paciente.getNome().compareTo(novo.getPaciente().getNome());
	}
	

	

}
