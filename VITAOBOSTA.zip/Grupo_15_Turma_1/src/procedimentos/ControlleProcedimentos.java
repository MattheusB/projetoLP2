package procedimentos;

import bancodeorgaos.BancoDeOrgaos;


import pacientes.Paciente;
import pacientes.Prontuario;

public class ControlleProcedimentos {
	
	
	private Paciente novopaciente;


	private BancoDeOrgaos novobanco = new BancoDeOrgaos();

	public void procedimentos(Prontuario prontuario, String procedimento, Double valor) throws Exception {
		
		
		
		this.novopaciente = prontuario.getPaciente();
		Double novovalor = this.novopaciente.getValorprocedimentos() + valor;
		this.novopaciente.setValorprocedimentos(novovalor);
		procedimento(procedimento,prontuario);
	}

	private boolean procedimento(String procedimento, Prontuario novo) throws Exception {

		switch (procedimento) {
		case "Consulta clinica":
			ConsultaClinica nova = new ConsultaClinica();
			nova.realizaCirurgia(novo);
			return true;

		case "Cirurgia bariatrica":
			CirurgiaBariatrica cirurgiabariatrica = new CirurgiaBariatrica();
			cirurgiabariatrica.realizaCirurgia(novo);
			return true;
		case "Redesignacao sexual":
			RedesiguinacaoSexual operacaosexual = new RedesiguinacaoSexual();
			operacaosexual.realizaCirurgia(novo);
			return true;
		default:
			throw new Exception(" Procedimento invalido.");
		}
	}

	public void trasnplantedeOrgaos(Prontuario prontuario,Double valor ) throws Exception {
		
		
		
		Paciente novo = prontuario.getPaciente();
		novo.setValorprocedimentos(novo.getValorprocedimentos() + valor);
		
		
		
		TransplantedeOrgao transplante = new TransplantedeOrgao();
		transplante.realizaCirurgia(prontuario);

	}

}
