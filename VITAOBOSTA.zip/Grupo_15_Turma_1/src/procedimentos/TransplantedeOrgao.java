package procedimentos;

import pacientes.Prontuario;

public class TransplantedeOrgao extends Procedimentos{
	
	
		@Override
		public void realizaCirurgia(Prontuario prontuario){
			this.setPontos(160); 
			this.setValor(12500); 
			this.setPaciente(prontuario.getPaciente());

			
			prontuario.addProcedimento(Procedimento.TRANSPLANTEDEORGAOS);
			this.getNovo().descontoServico(this.getValor());
			this.getNovo().ceditobonus(this.getPontos());
			
		
			
	}

}
