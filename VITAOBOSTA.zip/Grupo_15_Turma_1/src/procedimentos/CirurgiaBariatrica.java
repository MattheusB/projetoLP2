package procedimentos;

import pacientes.Prontuario;

public class CirurgiaBariatrica extends Procedimentos{
	public CirurgiaBariatrica(){}
	
	@Override
	public void realizaCirurgia(Prontuario prontuario){
		this.setPontos(100); 
		this.setValor(7600); 
		this.setPaciente(prontuario.getPaciente());
		Double novopeso = this.getNovo().getPeso();
		
		novopeso -= novopeso * 0.10;
		this.getNovo().setPeso(novopeso);
		prontuario.addProcedimento(Procedimento.CIRUGIABARIATRICA);
		this.getNovo().descontoServico(this.getValor());
		this.getNovo().ceditobonus(this.getPontos());
		
	}

}
